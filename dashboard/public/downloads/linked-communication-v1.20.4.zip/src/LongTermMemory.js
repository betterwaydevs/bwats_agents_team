let defaultsModule;

if (typeof module !== 'undefined' && module.exports && typeof require === 'function') {
  defaultsModule = require('./config/memoryDefaults');
} else if (typeof window !== 'undefined' && window.LinkedCommunicationMemoryDefaults) {
  defaultsModule = window.LinkedCommunicationMemoryDefaults;
}

if (!defaultsModule) {
  const fallbackDefaults = Object.freeze({
    username: '',
    memoryText: '',
    lastImportConnectionDate: null,
    connectionLimit: 20,
    invitationLimit: 5,
  });
  defaultsModule = {
    DEFAULT_MEMORY: fallbackDefaults,
    cloneDefaultMemory() {
      return {
        username: fallbackDefaults.username,
        memoryText: fallbackDefaults.memoryText,
        lastImportConnectionDate: fallbackDefaults.lastImportConnectionDate,
        connectionLimit: fallbackDefaults.connectionLimit,
        invitationLimit: fallbackDefaults.invitationLimit,
      };
    },
  };
}

const { DEFAULT_MEMORY, cloneDefaultMemory } = defaultsModule;

const STORAGE_KEY = 'LongTermMemorySnapshot';

class InMemoryStorage {
  constructor() {
    this.store = new Map();
  }

  async getItem(key) {
    return this.store.has(key) ? this.store.get(key) : null;
  }

  async setItem(key, value) {
    this.store.set(key, value);
  }

  clear() {
    this.store.clear();
  }
}

class LongTermMemory {
  constructor(storage) {
    this.storage = storage ?? this.detectBrowserStorage() ?? new InMemoryStorage();
    this.snapshot = cloneDefaultMemory();
  }

  async load() {
    try {
      const raw = await this.storage.getItem(STORAGE_KEY);
      if (!raw) {
        this.snapshot = cloneDefaultMemory();
        return;
      }

      const parsed = JSON.parse(raw);
      if (this.isValidSnapshot(parsed)) {
        const defaults = cloneDefaultMemory();
        this.snapshot = {
          username: parsed.username,
          memoryText: parsed.memoryText,
          lastImportConnectionDate: parsed.lastImportConnectionDate,
          authToken: parsed.authToken ?? null,
          userId: parsed.userId ?? null,
          tokenValidUntil: parsed.tokenValidUntil ?? null,
          connectionLimit: this.normalizeLimit(parsed.connectionLimit, defaults.connectionLimit, 20),
          invitationLimit: this.normalizeLimit(parsed.invitationLimit, defaults.invitationLimit, 5),
        };
      } else {
        this.snapshot = cloneDefaultMemory();
      }
    } catch {
      this.snapshot = cloneDefaultMemory();
    }
  }

  async save() {
    await this.storage.setItem(STORAGE_KEY, JSON.stringify(this.snapshot));
  }

  getUsername() {
    return this.snapshot.username;
  }

  setUsername(username) {
    if (typeof username === 'string' && username.trim().length > 0) {
      this.snapshot.username = username.trim();
    }
  }

  getAuthToken() {
    return this.snapshot.authToken ?? null;
  }

  setAuthToken(token) {
    if (token === null) {
      this.snapshot.authToken = null;
      return;
    }

    if (typeof token === 'string' && token.trim().length > 0) {
      this.snapshot.authToken = token.trim();
    }
  }

  getUserId() {
    return this.snapshot.userId ?? null;
  }

  setUserId(userId) {
    if (userId === null) {
      this.snapshot.userId = null;
      return;
    }

    if (typeof userId === 'string' && userId.trim().length > 0) {
      this.snapshot.userId = userId.trim();
    }
  }

  getTokenValidUntil() {
    return this.snapshot.tokenValidUntil ?? null;
  }

  setTokenValidUntil(value) {
    if (value === null) {
      this.snapshot.tokenValidUntil = null;
      return;
    }

    if (value instanceof Date) {
      this.snapshot.tokenValidUntil = value.toISOString();
      return;
    }

    if (typeof value === 'string' && value.trim().length > 0) {
      const parsed = new Date(value);
      if (!Number.isNaN(parsed.getTime())) {
        this.snapshot.tokenValidUntil = parsed.toISOString();
      }
    }
  }

  getMemoryText() {
    return this.snapshot.memoryText;
  }

  setMemoryText(memoryText) {
    this.snapshot.memoryText = typeof memoryText === 'string' ? memoryText : this.snapshot.memoryText;
  }

  getLastImportConnectionDate() {
    return this.snapshot.lastImportConnectionDate;
  }

  setLastImportConnectionDate(date) {
    if (date === null) {
      this.snapshot.lastImportConnectionDate = null;
      return;
    }

    if (date instanceof Date) {
      this.snapshot.lastImportConnectionDate = date.toISOString();
      return;
    }

    if (typeof date === 'string' && date.trim().length > 0) {
      const asDate = new Date(date);
      this.snapshot.lastImportConnectionDate = Number.isNaN(asDate.getTime())
        ? this.snapshot.lastImportConnectionDate
        : asDate.toISOString();
    }
  }

  getConnectionLimit() {
    return this.normalizeLimit(this.snapshot.connectionLimit, DEFAULT_MEMORY.connectionLimit, 20);
  }

  setConnectionLimit(limit) {
    const normalized = this.normalizeLimit(limit, DEFAULT_MEMORY.connectionLimit, 20);
    if (Number.isFinite(normalized) && normalized > 0) {
      this.snapshot.connectionLimit = normalized;
    }
  }

  getInvitationLimit() {
    return this.normalizeLimit(this.snapshot.invitationLimit, DEFAULT_MEMORY.invitationLimit, 5);
  }

  setInvitationLimit(limit) {
    const normalized = this.normalizeLimit(limit, DEFAULT_MEMORY.invitationLimit, 5);
    if (Number.isFinite(normalized) && normalized > 0) {
      this.snapshot.invitationLimit = normalized;
    }
  }

  normalizeLimit(value, fallback, hardcodedFallback) {
    const defaultValue = Number.isFinite(fallback) && fallback > 0 ? Math.trunc(fallback) : hardcodedFallback;

    if (value === undefined || value === null) {
      return defaultValue;
    }

    const numeric = Number.parseInt(value, 10);
    if (Number.isFinite(numeric) && numeric > 0) {
      return numeric;
    }

    return defaultValue;
  }

  reset() {
    this.snapshot = cloneDefaultMemory();
  }

  isValidSnapshot(value) {
    if (!value || typeof value !== 'object') {
      return false;
    }

    const candidate = value;
    const usernameOk = typeof candidate.username === 'string';
    const memoryOk = typeof candidate.memoryText === 'string';
    const dateOk = candidate.lastImportConnectionDate === null || typeof candidate.lastImportConnectionDate === 'string';
    const authOk = candidate.authToken === undefined || candidate.authToken === null || typeof candidate.authToken === 'string';
    const userIdOk = candidate.userId === undefined || candidate.userId === null || typeof candidate.userId === 'string';
    const expiryOk = candidate.tokenValidUntil === undefined || candidate.tokenValidUntil === null || typeof candidate.tokenValidUntil === 'string';
    const connectionLimitOk = candidate.connectionLimit === undefined || candidate.connectionLimit === null || typeof candidate.connectionLimit === 'number' || typeof candidate.connectionLimit === 'string';
    const invitationLimitOk = candidate.invitationLimit === undefined || candidate.invitationLimit === null || typeof candidate.invitationLimit === 'number' || typeof candidate.invitationLimit === 'string';
    return usernameOk && memoryOk && dateOk && authOk && userIdOk && expiryOk && connectionLimitOk && invitationLimitOk;
  }

  detectBrowserStorage() {
    if (typeof window !== 'undefined') {
      if (window.localStorage) {
        return {
          getItem: async (key) => window.localStorage.getItem(key),
          setItem: async (key, value) => {
            window.localStorage.setItem(key, value);
          },
        };
      }

      const chromeStorage = window.chrome?.storage?.local;
      if (chromeStorage) {
        return {
          getItem: (key) =>
            new Promise((resolve) => {
              chromeStorage.get([key], (result) => {
                resolve(result?.[key] ?? null);
              });
            }),
          setItem: (key, value) =>
            new Promise((resolve) => {
              chromeStorage.set({ [key]: value }, () => resolve());
            }),
        };
      }
    }

    return null;
  }
}

const memoryModule = {
  LongTermMemory,
  InMemoryStorage,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = memoryModule;
}

if (typeof window !== 'undefined') {
  window.LinkedCommunicationLongTermMemory = memoryModule;
}
