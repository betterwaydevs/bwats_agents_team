const DEFAULT_MEMORY = Object.freeze({
  username: 'testlinkedinuser',
  memoryText: '',
  lastImportConnectionDate: null,
  authToken: null,
  userId: null,
  tokenValidUntil: null,
  connectionLimit: 20,
  invitationLimit: 5,
});

function cloneDefaultMemory() {
  return {
    username: DEFAULT_MEMORY.username,
    memoryText: DEFAULT_MEMORY.memoryText,
    lastImportConnectionDate: DEFAULT_MEMORY.lastImportConnectionDate,
    authToken: DEFAULT_MEMORY.authToken,
    userId: DEFAULT_MEMORY.userId,
    tokenValidUntil: DEFAULT_MEMORY.tokenValidUntil,
    connectionLimit: DEFAULT_MEMORY.connectionLimit,
    invitationLimit: DEFAULT_MEMORY.invitationLimit,
  };
}

const defaultsModule = {
  DEFAULT_MEMORY,
  cloneDefaultMemory,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = defaultsModule;
}

if (typeof window !== 'undefined') {
  window.LinkedCommunicationMemoryDefaults = defaultsModule;
}
