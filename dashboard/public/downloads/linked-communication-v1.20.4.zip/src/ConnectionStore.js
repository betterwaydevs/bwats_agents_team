class ConnectionStore {
  constructor({ capacity = 300 } = {}) {
    this.capacity = this.#normalizeCapacity(capacity);
    this.items = new Map();
    this.order = [];
  }

  setCapacity(newCapacity) {
    this.capacity = this.#normalizeCapacity(newCapacity);
    this.#enforceCapacity();
  }

  add(connection) {
    const normalized = this.#normalizeConnection(connection);
    const key = normalized.Connection_Profile_URL;

    if (this.items.has(key)) {
      this.items.set(key, normalized);
      this.#moveToRecent(key);
      return;
    }

    this.items.set(key, normalized);
    this.order.push(key);
    this.#enforceCapacity();
  }

  addMany(connections) {
    if (!Array.isArray(connections)) {
      throw new Error('Connections must be an array.');
    }

    connections.forEach((connection) => {
      if (!connection) {
        return;
      }

      try {
        this.add(connection);
      } catch (error) {
        // Skip malformed entries silently.
      }
    });
  }

  getById(connectionSlug) {
    const record = this.items.get(connectionSlug);
    return record ? { ...record } : undefined;
  }

  getAll() {
    return this.order
      .map((userId) => this.items.get(userId))
      .filter(Boolean)
      .map((record) => ({ ...record }));
  }

  has(userId) {
    return this.items.has(userId);
  }

  size() {
    return this.items.size;
  }

  clear() {
    this.items.clear();
    this.order = [];
  }

  display() {
    const entries = this.getAll();
    console.group('Linked Communication Connections');
    entries.forEach((connection, index) => {
      console.log(`#${index + 1}`, connection);
    });
    console.log('JSON payload:', entries);
    console.groupEnd();
  }

  #moveToRecent(key) {
    const index = this.order.indexOf(key);
    if (index >= 0) {
      this.order.splice(index, 1);
    }
    this.order.push(key);
  }

  #enforceCapacity() {
    while (this.order.length > this.capacity) {
      const oldest = this.order.shift();
      if (oldest) {
        this.items.delete(oldest);
      }
    }
  }

  #normalizeConnection(connection) {
    if (!connection || typeof connection !== 'object') {
      throw new Error('Connection must be an object.');
    }

    const slug = connection.Connection_Profile_URL;
    if (typeof slug !== 'string' || slug.trim().length === 0) {
      throw new Error('Connection must include a Connection_Profile_URL.');
    }

    return {
      user_id: typeof connection.user_id === 'string' ? connection.user_id.trim() : connection.user_id ?? null,
      First_Name: connection.First_Name ?? '',
      Last_Name: connection.Last_Name ?? '',
      Connection_Profile_URL: slug.trim(),
      Email_Address: connection.Email_Address ?? null,
      Company: connection.Company ?? null,
      Position: connection.Position ?? null,
      Connected_On: connection.Connected_On ?? null,
    };
  }

  #normalizeCapacity(value) {
    if (!Number.isInteger(value)) {
      return 100;
    }

    return Math.max(1, value);
  }

}

const storeExports = {
  ConnectionStore,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = storeExports;
}

if (typeof window !== 'undefined') {
  window.LinkedCommunicationConnectionStore = storeExports;
}
