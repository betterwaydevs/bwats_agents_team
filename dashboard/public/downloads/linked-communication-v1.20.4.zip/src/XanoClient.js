'use strict';

const DEFAULT_BASE_URL = 'https://xano.atlanticsoft.co/api:Ks58d17q';
const DEFAULT_LOGIN_PATH = '/auth/login';
const DEFAULT_ME_PATH = '/auth/me';
const DEFAULT_EXPIRY_SECONDS = 7 * 24 * 60 * 60;

class XanoClient {
  constructor({ baseUrl = DEFAULT_BASE_URL, loginPath = DEFAULT_LOGIN_PATH, mePath = DEFAULT_ME_PATH, fetchImpl } = {}) {
    this.baseUrl = this.#trimTrailingSlash(baseUrl);
    this.loginPath = loginPath;
    this.mePath = mePath;
    this.fetchImpl = this.#resolveFetch(fetchImpl);
  }

  async login({ email, password }) {
    if (typeof email !== 'string' || email.trim().length === 0) {
      throw new Error('Email is required to log in.');
    }

    if (typeof password !== 'string' || password.length === 0) {
      throw new Error('Password is required to log in.');
    }

    const response = await this.fetchImpl(`${this.baseUrl}${this.loginPath}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: email.trim(), password }),
    });

    if (!response.ok) {
      const message = await this.#safeReadError(response);
      throw new Error(`Xano login failed: ${message}`);
    }

    const payload = await this.#safeJson(response);
    const token = payload?.authToken ?? payload?.token ?? payload?.jwt ?? null;

    if (typeof token !== 'string' || token.trim().length === 0) {
      throw new Error('Xano login response did not include an auth token.');
    }

    const expiresInSeconds = this.#extractExpirySeconds(payload);
    const expiresAt = new Date(Date.now() + expiresInSeconds * 1000).toISOString();

    return {
      token: token.trim(),
      expiresAt,
      raw: payload,
    };
  }

  async me(authToken) {
    if (typeof authToken !== 'string' || authToken.trim().length === 0) {
      throw new Error('Auth token is required to fetch current user.');
    }

    const response = await this.fetchImpl(`${this.baseUrl}${this.mePath}`, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        Authorization: authToken.trim(),
      },
    });

    if (!response.ok) {
      const message = await this.#safeReadError(response);
      throw new Error(`Xano me request failed: ${message}`);
    }

    return this.#safeJson(response);
  }

  #resolveFetch(fetchOverride) {
    if (typeof fetchOverride === 'function') {
      return fetchOverride;
    }

    if (typeof window !== 'undefined' && typeof window.fetch === 'function') {
      return window.fetch.bind(window);
    }

    if (typeof globalThis.fetch === 'function') {
      return (...args) => globalThis.fetch(...args);
    }

    throw new Error('XanoClient requires a fetch implementation.');
  }

  #extractExpirySeconds(payload) {
    if (!payload || typeof payload !== 'object') {
      return DEFAULT_EXPIRY_SECONDS;
    }

    const raw = payload.expiresIn ?? payload.expires_in ?? payload.expiry ?? payload.ttl ?? payload.expires;
    if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
      return raw;
    }

    return DEFAULT_EXPIRY_SECONDS;
  }

  async #safeReadError(response) {
    try {
      const data = await response.json();
      if (data && typeof data === 'object') {
        return data.message ?? JSON.stringify(data);
      }
    } catch (error) {
      // Ignore JSON parse errors.
    }

    try {
      return await response.text();
    } catch (error) {
      return `${response.status} ${response.statusText}`;
    }
  }

  async #safeJson(response) {
    try {
      return await response.json();
    } catch (error) {
      throw new Error('Failed to parse JSON response from Xano.');
    }
  }

  #trimTrailingSlash(value) {
    if (typeof value !== 'string') {
      return DEFAULT_BASE_URL;
    }
    return value.endsWith('/') ? value.slice(0, -1) : value;
  }
}

function createMockXanoClient({
  token = 'mock-token',
  userId = 'testlinkedinuser',
  expiresInSeconds = DEFAULT_EXPIRY_SECONDS,
  mePayload = null,
} = {}) {
  return {
    async login() {
      return {
        token,
        expiresAt: new Date(Date.now() + expiresInSeconds * 1000).toISOString(),
        raw: { token },
      };
    },

    async me() {
      if (mePayload) {
        return mePayload;
      }

      return {
        id: userId,
        email: `${userId}@example.com`,
      };
    },
  };
}

module.exports = {
  XanoClient,
  DEFAULT_BASE_URL,
  createMockXanoClient,
};
