"use strict";

let JSDOMInstance;

if (typeof module !== "undefined" && module.exports) {
  ({ JSDOM: JSDOMInstance } = require("jsdom"));
}

let InvitationStoreModule;

const ensureStore = () => {
  if (!InvitationStoreModule) {
    ({ InvitationStore: InvitationStoreModule } = require("./InvitationStore"));
  }

  return InvitationStoreModule;
};

const { parseLinkedInDate } = require("./LinkedInDateParser");

const defaultDomFactory = (html) => {
  if (typeof window !== "undefined" && typeof DOMParser !== "undefined") {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    return {
      window: {
        document: doc,
      },
    };
  }

  if (JSDOMInstance) {
    return new JSDOMInstance(html);
  }

  throw new Error("No DOM factory available for InvitationScraper.");
};

class InvitationScraper {
  constructor(store = null, { domFactory = defaultDomFactory } = {}) {
    const StoreClass = ensureStore();
    if (store && !(store instanceof StoreClass)) {
      throw new Error("InvitationScraper requires an InvitationStore instance.");
    }

    this.store = store ?? new StoreClass();
    this.domFactory = domFactory;
  }

  scrapeFromHtml(html) {
    if (typeof html !== "string" || html.trim().length === 0) {
      return [];
    }

    const dom = this.domFactory(html);
    const document = dom.window.document;

    const cards = this.#findInvitationCards(document);
    const parsed = cards
      .map((card) => this.#parseInvitation(card))
      .filter((invitation) => Boolean(invitation?.Connection_Profile_URL));

    const unique = [];
    const seen = new Set();
    parsed.forEach((invitation) => {
      const slug = invitation.Connection_Profile_URL;
      if (!slug || seen.has(slug)) {
        return;
      }
      seen.add(slug);
      unique.push(invitation);
    });

    this.store.addMany(unique);
    return unique;
  }

  scrapeWithMetadata(html) {
    const records = this.scrapeFromHtml(html);
    return {
      records,
      totalCount: records.length,
    };
  }

  #findInvitationCards(document) {
    const container = document.querySelector("#workspace");
    if (!container) {
      return [];
    }

    const listItems = Array.from(container.querySelectorAll('[role="listitem"]'));

    if (!listItems.length) {
      return [];
    }

    return listItems.filter((item) => {
      const anchor = item.querySelector('a[href*="linkedin.com/in/"]');
      return Boolean(anchor);
    });
  }

  #parseInvitation(card) {
    if (!card) {
      return null;
    }

    // Find all profile anchors and pick the one with text (name link)
    const profileAnchors = Array.from(card.querySelectorAll('a[href*="linkedin.com/in/"]'));
    const nameAnchor = profileAnchors.find(a => {
      const text = a.textContent?.trim() ?? "";
      return text.length > 2 && !text.toLowerCase().includes("message");
    }) || profileAnchors[0];
    
    const profileHref = nameAnchor?.getAttribute("href") ?? "";
    const profileSlug = this.#extractProfileSlug(profileHref);
    if (!profileSlug) {
      return null;
    }

    // Extract name from the name anchor
    const nameText = nameAnchor?.textContent?.trim() ?? "";

    // Get all paragraphs in order
    const paragraphs = Array.from(card.querySelectorAll("p"));
    
    let position = null;
    let invitedOn = null;
    let message = "";

    // Process paragraphs sequentially
    let foundName = false;
    for (const p of paragraphs) {
      const text = p.textContent?.trim() ?? "";
      
      // Skip empty paragraphs
      if (!text) continue;

      // Check if this paragraph contains the profile link (name paragraph)
      if (p.querySelector('a[href*="linkedin.com/in/"]')) {
        foundName = true;
        continue;
      }

      // Check if this is the date paragraph
      if (/^sent \d+|^sent today|^invited on|^invited today/i.test(text)) {
        if (!invitedOn) {
          invitedOn = this.#parseDate(text);
        }
        continue;
      }

      // Check if this contains the message (has nested spans with substantial text)
      const messageSpan = p.querySelector("span[data-testid='expandable-text-box']");
      if (messageSpan) {
        message = messageSpan.textContent?.trim() ?? "";
        continue;
      }

      // If we found the name but not the position yet, this should be the position
      if (foundName && !position && text.length >= 10) {
        const lower = text.toLowerCase();
        if (!lower.includes("withdraw") && !lower.includes("ignore") && !lower.includes("accept")) {
          position = text;
        }
      }
    }

    const { firstName, lastName } = this.#splitName(nameText);

    return {
      First_Name: firstName,
      Last_Name: lastName,
      Position: position,
      Invited_On: invitedOn,
      Connection_Profile_URL: profileSlug,
      Message: message,
      user_id: null,
    };
  }

  #parseDate(rawText) {
    return parseLinkedInDate(rawText);
  }

  #extractProfileSlug(reference) {
    if (!reference) {
      return "";
    }

    let target = reference;
    try {
      const url = new URL(reference, "https://www.linkedin.com");
      target = url.pathname;
    } catch (error) {
      // keep original string when relative
    }

    const match = target.match(/\/in\/([^/?#]+)(?:\/|$)/i);
    if (!match) {
      return "";
    }

    return decodeURIComponent(match[1]);
  }

  #extractName(anchor) {
    if (!anchor) {
      return "";
    }

    let nameText = anchor.textContent ?? "";
    nameText = nameText.replace(/\s+/g, " ").trim();
    
    if (nameText && !nameText.toLowerCase().includes("message") && !nameText.toLowerCase().includes("withdraw")) {
      return nameText;
    }

    const parentParagraph = anchor.closest("p");
    if (parentParagraph) {
      const spans = parentParagraph.querySelectorAll("span");
      for (const span of spans) {
        const text = span.textContent?.trim() ?? "";
        if (text && text.length > 2 && !text.toLowerCase().includes("message") && !text.toLowerCase().includes("sent")) {
          return text.replace(/\s+/g, " ").trim();
        }
      }
    }

    return nameText;
  }

  #extractPosition(card, anchor) {
    if (!card) {
      return null;
    }

    const anchorParagraph = anchor?.closest("p") ?? null;
    const paragraphs = Array.from(card.querySelectorAll("p"));

    const positionParagraph = paragraphs.find((p) => {
      if (p === anchorParagraph) {
        return false;
      }

      const text = p.textContent?.trim() ?? "";
      if (!text) {
        return false;
      }

      if (/^sent on/i.test(text) || /^invited on/i.test(text) || /sent \d+/i.test(text)) {
        return false;
      }

      const lower = text.toLowerCase();
      if ((lower.includes("accept") && lower.includes("ignore")) || 
          (lower.includes("message") && lower.includes("withdraw"))) {
        return false;
      }

      if (text.length < 10) {
        return false;
      }

      return true;
    });

    return positionParagraph?.textContent?.trim() ?? null;
  }

  #extractInvitedOn(card) {
    const inviteParagraph = Array.from(card.querySelectorAll("p")).find((p) =>
      /sent on|invited on/i.test(p.textContent ?? "")
    );

    const rawText = inviteParagraph?.textContent?.trim() ?? "";
    const isoMatch = rawText.match(/\b(\d{4}-\d{2}-\d{2})\b/);
    if (isoMatch) {
      return isoMatch[1];
    }

    const dateMatch = rawText.match(/on\s+(.*)$/i);
    if (!dateMatch) {
      return null;
    }

    const parsed = Date.parse(dateMatch[1]);
    if (Number.isNaN(parsed)) {
      return rawText || null;
    }

    return new Date(parsed).toISOString().slice(0, 10);
  }

  #extractMessage(card) {
    if (!card) {
      return "";
    }

    const paragraphs = Array.from(card.querySelectorAll("p"));
    
    for (const p of paragraphs) {
      const deepSpans = p.querySelectorAll("span span");
      for (const span of deepSpans) {
        const text = span.textContent?.trim() ?? "";
        if (text.length > 20 && !text.toLowerCase().includes("accept") && !text.toLowerCase().includes("ignore")) {
          return text.trim();
        }
      }
    }

    return "";
  }

  #splitName(fullName) {
    if (!fullName) {
      return { firstName: "", lastName: "" };
    }

    const parts = fullName
      .split(" ")
      .map((part) => part.trim())
      .filter(Boolean);

    const count = parts.length;
    if (count === 0) {
      return { firstName: "", lastName: "" };
    }

    if (count === 1) {
      return { firstName: parts[0], lastName: "" };
    }

    if (count === 2) {
      return { firstName: parts[0], lastName: parts[1] };
    }

    if (count === 4) {
      const midpoint = count / 2;
      return {
        firstName: parts.slice(0, midpoint).join(" "),
        lastName: parts.slice(midpoint).join(" "),
      };
    }

    return {
      firstName: parts.slice(0, count - 1).join(" "),
      lastName: parts[count - 1],
    };
  }
}

module.exports = {
  InvitationScraper,
};
