'use strict';

let JSDOMInstance;

if (typeof module !== 'undefined' && module.exports) {
  ({ JSDOM: JSDOMInstance } = require('jsdom'));
}

const { LongTermMemory } = require('./LongTermMemory');
const { parseLinkedInDate } = require('./LinkedInDateParser');

const defaultDomFactory = (html) => {
  if (typeof window !== 'undefined' && typeof DOMParser !== 'undefined') {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    return {
      window: {
        document: doc,
      },
    };
  }

  if (JSDOMInstance) {
    return new JSDOMInstance(html);
  }

  throw new Error('No DOM factory available for ConnectionScraper.');
};

class ConnectionScraper {
  constructor(store, { domFactory = defaultDomFactory, memory = null } = {}) {
    if (!store) {
      throw new Error('ConnectionScraper requires a ConnectionStore instance.');
    }

    this.store = store;
    this.domFactory = domFactory;
    this.memory = memory ?? new LongTermMemory();
  }

  scrapeFromHtml(html) {
    if (typeof html !== 'string' || html.trim().length === 0) {
      return [];
    }

    const dom = this.domFactory(html);
    const document = dom.window.document;

    const connectionElements = this.#findConnectionElements(document);
    const parsed = connectionElements
      .map((element) => this.#parseConnection(element))
      .filter((record) => Boolean(record));

    const uniqueRecords = [];
    const seen = new Set();
    parsed.forEach((record) => {
      if (!record) {
        return;
      }

      const fingerprint = record.Connection_Profile_URL || record.user_id;
      if (!fingerprint || seen.has(fingerprint)) {
        return;
      }

      uniqueRecords.push(record);
      seen.add(fingerprint);
    });

    this.store.addMany(uniqueRecords);
    return uniqueRecords;
  }

  #findConnectionElements(document) {
    const markers = Array.from(document.querySelectorAll('[data-view-name="connections-profile"]'));
    const seen = new Set();
    const cards = [];

    markers.forEach((marker) => {
      const cardRoot = this.#findCardRoot(marker);
      if (cardRoot && !seen.has(cardRoot)) {
        seen.add(cardRoot);
        cards.push(cardRoot);
      }
    });

    return cards;
  }

  #findCardRoot(startElement) {
    let current = startElement;
    let depth = 0;

    while (current && depth < 20) {
      if (current.querySelector?.('[data-view-name="message-button"]')) {
        return current;
      }

      current = current.parentElement ?? current.parentNode ?? null;
      depth += 1;
    }

    return startElement instanceof Node ? startElement : null;
  }

  #parseConnection(cardElement) {
    const messageLink = cardElement.querySelector('[data-view-name="message-button"] a');
    const profileUrn = messageLink?.getAttribute('href') ?? '';

    const candidateAnchors = Array.from(
      cardElement.querySelectorAll('a[href*="linkedin.com/in/"]')
    );

    if (candidateAnchors.length === 0) {
      return null;
    }

    const profileNameLink =
      candidateAnchors.find((anchor) => (anchor.textContent ?? '').trim().length > 0) ??
      candidateAnchors[0];

    const rawProfileReference = profileNameLink?.getAttribute('href') ?? '';
    const profileSource = rawProfileReference || profileUrn;

    const profileSlug = this.#extractProfileSlug(profileSource);
    if (!profileSlug) {
      return null;
    }

    const userId = this.#getOwnerUserId();

    const profileContainer =
      profileNameLink?.closest('p')?.parentElement ?? profileNameLink?.closest('div') ?? cardElement;

    const profileParagraphs = Array.from(profileContainer.querySelectorAll('p'));

    const nameParagraph = profileNameLink?.closest('p') ??
      profileParagraphs.find((p) => p.querySelector('a[href*="linkedin.com/in/"]')) ??
      null;

    const headlineParagraph = profileParagraphs.find((p) => {
      const text = p.textContent?.trim() ?? '';
      if (!text) {
        return false;
      }

      if (/^Connected on/i.test(text)) {
        return false;
      }

      if (p === nameParagraph) {
        return false;
      }

      if (p.querySelector('a[href*="linkedin.com/in/"]')) {
        return false;
      }

      return true;
    });
    const position = headlineParagraph?.textContent?.trim() ?? null;

    const nameText = this.#extractNameText({
      profileNameLink,
      nameParagraph,
      cardElement,
      position,
    });

    if (!nameText) {
      return null;
    }

    const { firstName, lastName } = this.#splitName(nameText);

    if (!firstName && !lastName) {
      return null;
    }

    const connectedOnText = this.#extractConnectedOn(cardElement);
    const connectedOn = this.#parseConnectedOn(connectedOnText);
    const company = this.#extractCompany(position);

    return {
      user_id: userId,
      First_Name: firstName ?? '',
      Last_Name: lastName ?? '',
      Connection_Profile_URL: profileSlug ?? '',
      Connected_On: connectedOn,
      Email_Address: null,
      Company: company,
      Position: position,
    };
  }

  #extractNameText({ profileNameLink, nameParagraph, cardElement, position }) {
    const candidateTexts = [];

    const addText = (value) => {
      if (typeof value !== 'string') {
        return;
      }

      const trimmed = value.trim();
      if (!trimmed) {
        return;
      }

      if (!candidateTexts.includes(trimmed)) {
        candidateTexts.push(trimmed);
      }
    };

    addText(profileNameLink?.textContent ?? '');
    addText(nameParagraph?.textContent ?? '');

    addText(
      cardElement.querySelector('span[aria-hidden="true"]')?.textContent ??
        cardElement.querySelector('span._33e6522e')?.textContent ??
        ''
    );

    addText(cardElement.querySelector('[data-view-name="profile-name"]')?.textContent ?? '');

    const nameElements = Array.from(
      cardElement.querySelectorAll('[data-anonymize="person-name"], [data-view-name="entity-result-title"]')
    );
    nameElements.forEach((element) => addText(element.textContent ?? ''));

    const normalizedPosition = typeof position === 'string' ? this.#normalizeWhiteSpace(position) : '';

    for (const textCandidate of candidateTexts) {
      const normalized = this.#normalizeWhiteSpace(textCandidate);
      const stripped = this.#stripHeadline(normalized, normalizedPosition);

      if (this.#looksLikePersonName(stripped)) {
        return stripped;
      }
    }

    return '';
  }

  #normalizeWhiteSpace(text) {
    return text.replace(/\s+/g, ' ').trim();
  }

  #stripHeadline(text, position) {
    if (!text) {
      return '';
    }

    let result = text;

    if (position) {
      if (result.endsWith(position)) {
        result = result.slice(0, -position.length).trim();
      } else if (result.includes(position)) {
        result = result.replace(position, '').trim();
      }
    }

    const newlineIndex = result.search(/[\r\n]/);
    if (newlineIndex >= 0) {
      result = result.slice(0, newlineIndex).trim();
    }

    const delimiterMatch = result.match(/\s[|•·–—-]+\s/);
    if (delimiterMatch) {
      result = result.slice(0, delimiterMatch.index).trim();
    }

    result = result.replace(/[|•·–—-]+$/g, '').trim();

    const keywordMatch = result.match(/\b(CEO|Founder|Officer|Consultant|Director|President|Manager|Engineer|Developer|Designer|Ambassador|Advisor|Coach|Strategist|Builder|Entrepreneur|Marketing|Growth|Product|Community)\b/i);
    if (keywordMatch && keywordMatch.index > 0) {
      result = result.slice(0, keywordMatch.index).trim();
    }

    return result;
  }

  #looksLikePersonName(text) {
    if (!text) {
      return false;
    }

    if (/\b(message|connect|connected on|view profile)\b/i.test(text)) {
      return false;
    }

    if (/\b(Engineer|Developer|Designer|Founder|CEO|Officer|Consultant|Director|President|Manager|Builder|Professional|Technologist|Ambassador|UX|UI|Product|Marketing|Growth|Owner|Advisor)\b/i.test(text)) {
      return false;
    }

    if (text.length > 120) {
      return false;
    }

    const words = text.split(/\s+/).filter(Boolean);
    if (words.length > 6) {
      return false;
    }

    if (words.length === 0) {
      return false;
    }

    const hasLetter = /[a-zA-ZÀ-ÿ]/.test(text);
    if (!hasLetter) {
      return false;
    }

    const validWordPattern = /^[a-zA-ZÀ-ÿ'’.\-]+$/;
    const validWordCount = words.filter((word) => validWordPattern.test(word)).length;
    if (validWordCount === 0) {
      return false;
    }

    return true;
  }

  #getOwnerUserId() {
    const memoryUserId = this.memory?.getUserId?.();
    if (typeof memoryUserId === 'string' && memoryUserId.trim().length > 0) {
      return memoryUserId.trim();
    }

    const memoryUsername = this.memory?.getUsername?.();
    if (typeof memoryUsername === 'string' && memoryUsername.trim().length > 0) {
      return memoryUsername.trim();
    }

    return null;
  }

  #buildProfileUrl(reference) {
    if (!reference) {
      return '';
    }

    if (/^https?:/i.test(reference)) {
      return reference;
    }

    const match = reference.match(/profileUrn=urn%3Ali%3Afsd_profile%3A([^&]+)/);
    if (!match) {
      return '';
    }

    const encodedId = match[1];
    return `https://www.linkedin.com/in/${encodedId}`;
  }

  #extractProfileSlug(reference) {
    if (!reference) {
      return '';
    }

    let target = reference;
    try {
      const url = new URL(reference, 'https://www.linkedin.com');
      target = url.pathname;
    } catch (error) {
      // Keep original reference when it is a relative URL.
    }

    const match = target.match(/\/in\/([^/?#]+)(?:\/|$)/i);
    if (!match) {
      return '';
    }

    return decodeURIComponent(match[1]);
  }

  #extractCompany() {
    return null;
  }

  #extractConnectedOn(cardElement) {
    if (!cardElement) {
      return null;
    }

    const candidates = Array.from(cardElement.querySelectorAll('p, span, li'))
      .map((node) => node.textContent?.trim() ?? '')
      .filter((text) => /^connected\s+on/i.test(text));

    return candidates[0] ?? null;
  }

  #parseConnectedOn(rawText) {
    if (!rawText) {
      return null;
    }

    return parseLinkedInDate(rawText);
  }

  #splitName(fullName) {
    if (!fullName) {
      return { firstName: '', lastName: '' };
    }

    const parts = fullName
      .split(' ')
      .map((part) => part.trim())
      .filter(Boolean);

    const count = parts.length;
    if (count === 0) {
      return { firstName: '', lastName: '' };
    }

    if (count === 1) {
      return { firstName: parts[0], lastName: '' };
    }

    if (count === 2) {
      return { firstName: parts[0], lastName: parts[1] };
    }

    if (count === 4) {
      const midpoint = count / 2;
      return {
        firstName: parts.slice(0, midpoint).join(' '),
        lastName: parts.slice(midpoint).join(' '),
      };
    }

    return {
      firstName: parts.slice(0, count - 1).join(' '),
      lastName: parts[count - 1],
    };
  }

  #toUnixTimestamp(text) {
    const dateMatch = text.match(/Connected on\s+(.*)/i);
    if (!dateMatch) {
      return null;
    }

    const parsed = Date.parse(dateMatch[1]);
    if (Number.isNaN(parsed)) {
      return null;
    }

    return Math.floor(parsed / 1000);
  }
}

module.exports = {
  ConnectionScraper,
};
