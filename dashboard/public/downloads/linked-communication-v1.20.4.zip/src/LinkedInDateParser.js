'use strict';

const NUMBER_WORD_LOOKUP = {
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fifty: 50,
  sixty: 60,
  seventy: 70,
  eighty: 80,
  ninety: 90,
  hundred: 100,
  thousand: 1000,
  a: 1,
  an: 1,
  single: 1,
  couple: 2,
  double: 2,
  triple: 3,
  few: 3,
};

const SPECIAL_DAY_OFFSETS = {
  yesterday: 1,
  today: 0,
};

const RELATIVE_UNIT_ALIASES = {
  day: 'day',
  days: 'day',
  week: 'week',
  weeks: 'week',
  month: 'month',
  months: 'month',
  year: 'year',
  years: 'year',
};

const STOPWORDS = new Set(['about', 'approximately', 'nearly', 'almost', 'around']);

const TODAY_ISO_CACHE = () => new Date().toISOString().slice(0, 10);

const parseLinkedInDate = (rawText) => {
  const normalized = rawText?.trim() ?? '';
  if (!normalized) {
    return TODAY_ISO_CACHE();
  }

  const lowered = normalized.toLowerCase();

  const isoMatch = normalized.match(/\b(\d{4}-\d{2}-\d{2})\b/);
  if (isoMatch) {
    return isoMatch[1];
  }

  const specialWord = Object.keys(SPECIAL_DAY_OFFSETS).find((key) => lowered.includes(key));
  if (specialWord != null) {
    const offset = SPECIAL_DAY_OFFSETS[specialWord];
    if (offset === 0) {
      return TODAY_ISO_CACHE();
    }
    return shiftRelativeDate(offset, 'day');
  }

  const onMatch = normalized.match(/\bon\s+(.*)$/i);
  if (onMatch) {
    const suffix = onMatch[1].trim();
    const parsed = Date.parse(suffix);
    if (!Number.isNaN(parsed)) {
      return new Date(parsed).toISOString().slice(0, 10);
    }

    const relativeFromSuffix = parseRelativeExpression(suffix);
    if (relativeFromSuffix) {
      return relativeFromSuffix;
    }
  }

  const relativeFromFull = parseRelativeExpression(normalized);
  if (relativeFromFull) {
    return relativeFromFull;
  }

  return TODAY_ISO_CACHE();
};

const parseRelativeExpression = (text) => {
  if (!text) {
    return null;
  }

  const numericMatch = text.match(/(sent|invited|connected|accepted)?\s*(?:on\s+)?(\d+)\s+(day|week|month|year)s?\s+ago/i);
  if (numericMatch) {
    const amount = Number.parseInt(numericMatch[2], 10);
    const unit = numericMatch[3];
    if (Number.isFinite(amount)) {
      return shiftRelativeDate(amount, unit);
    }
  }

  const wordMatch = text.match(/(sent|invited|connected|accepted)?\s*(?:on\s+)?([a-z\-\s]+?)\s+(day|week|month|year)s?\s+ago/i);
  if (wordMatch) {
    const amount = wordToNumber(wordMatch[2]);
    if (Number.isFinite(amount)) {
      return shiftRelativeDate(amount, wordMatch[3]);
    }
  }

  const lastMatch = text.match(/\blast\s+(day|week|month|year)\b/i);
  if (lastMatch) {
    return shiftRelativeDate(1, lastMatch[1]);
  }

  return null;
};

const shiftRelativeDate = (amount, unitRaw) => {
  if (!Number.isFinite(amount) || amount < 0) {
    return TODAY_ISO_CACHE();
  }

  const normalizedUnit = RELATIVE_UNIT_ALIASES[unitRaw?.toLowerCase() ?? ''];
  if (!normalizedUnit) {
    return TODAY_ISO_CACHE();
  }

  const pivot = new Date();

  if (normalizedUnit === 'day') {
    pivot.setDate(pivot.getDate() - amount);
  } else if (normalizedUnit === 'week') {
    pivot.setDate(pivot.getDate() - amount * 7);
  } else if (normalizedUnit === 'month') {
    pivot.setMonth(pivot.getMonth() - amount);
  } else if (normalizedUnit === 'year') {
    pivot.setFullYear(pivot.getFullYear() - amount);
  }

  return pivot.toISOString().slice(0, 10);
};

const wordToNumber = (input) => {
  if (!input) {
    return Number.NaN;
  }

  const cleaned = input
    .toLowerCase()
    .replace(/[,]+/g, ' ')
    .split(/[-\s]+/)
    .filter(Boolean)
    .filter((token) => !STOPWORDS.has(token));

  if (cleaned.length === 0) {
    return Number.NaN;
  }

  let total = 0;

  for (const token of cleaned) {
    if (Object.prototype.hasOwnProperty.call(SPECIAL_DAY_OFFSETS, token)) {
      const offset = SPECIAL_DAY_OFFSETS[token];
      return Number.isFinite(offset) ? offset : Number.NaN;
    }

    const value = NUMBER_WORD_LOOKUP[token];
    if (!Number.isFinite(value)) {
      return Number.NaN;
    }

    total += value;
  }

  return total;
};

module.exports = {
  parseLinkedInDate,
};
