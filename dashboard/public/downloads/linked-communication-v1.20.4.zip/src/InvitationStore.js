class InvitationStore {
  constructor({ capacity = 100 } = {}) {
    this.capacity = this.#normalizeCapacity(capacity);
    this.items = new Map();
    this.order = [];
  }

  setCapacity(newCapacity) {
    this.capacity = this.#normalizeCapacity(newCapacity);
    this.#enforceCapacity();
  }

  add(invitation) {
    const normalized = this.#normalizeInvitation(invitation);
    const key = normalized.Connection_Profile_URL;

    if (this.items.has(key)) {
      this.items.set(key, normalized);
      this.#moveToRecent(key);
      return;
    }

    this.items.set(key, normalized);
    this.order.push(key);
    this.#enforceCapacity();
  }

  addMany(invitations) {
    if (!Array.isArray(invitations)) {
      throw new Error('Invitations must be an array.');
    }

    invitations.forEach((invitation) => {
      if (!invitation) {
        return;
      }

      try {
        this.add(invitation);
      } catch (error) {
        // Ignore malformed entries to keep store resilient.
      }
    });
  }

  getById(invitationSlug) {
    const record = this.items.get(invitationSlug);
    return record ? { ...record } : undefined;
  }

  getAll() {
    return this.order
      .map((slug) => this.items.get(slug))
      .filter(Boolean)
      .map((record) => ({ ...record }));
  }

  has(slug) {
    return this.items.has(slug);
  }

  size() {
    return this.items.size;
  }

  clear() {
    this.items.clear();
    this.order = [];
  }

  display() {
    const entries = this.getAll();
    console.group('Linked Communication Invitations');
    entries.forEach((invitation, index) => {
      console.log(`#${index + 1}`, invitation);
    });
    console.log('JSON payload:', entries);
    console.groupEnd();
  }

  #moveToRecent(key) {
    const index = this.order.indexOf(key);
    if (index >= 0) {
      this.order.splice(index, 1);
    }
    this.order.push(key);
  }

  #enforceCapacity() {
    while (this.order.length > this.capacity) {
      const oldest = this.order.shift();
      if (oldest) {
        this.items.delete(oldest);
      }
    }
  }

  #normalizeInvitation(invitation) {
    if (!invitation || typeof invitation !== 'object') {
      throw new Error('Invitation must be an object.');
    }

    const slug = invitation.Connection_Profile_URL;
    if (typeof slug !== 'string' || slug.trim().length === 0) {
      throw new Error('Invitation must include a Connection_Profile_URL.');
    }

    return {
      First_Name: this.#toString(invitation.First_Name),
      Last_Name: this.#toString(invitation.Last_Name),
      Position: this.#toString(invitation.Position),
      Invited_On: this.#normalizeDate(invitation.Invited_On),
      Connection_Profile_URL: slug.trim(),
      Message: this.#toString(invitation.Message),
      user_id: invitation.user_id ?? null,
    };
  }

  #normalizeDate(value) {
    if (value == null) {
      return null;
    }

    if (value instanceof Date) {
      return Number.isNaN(value.getTime()) ? null : value.toISOString().slice(0, 10);
    }

    if (typeof value === 'number' && Number.isFinite(value)) {
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? null : date.toISOString().slice(0, 10);
    }

    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed) {
        return null;
      }
      const date = new Date(trimmed);
      return Number.isNaN(date.getTime()) ? trimmed : date.toISOString().slice(0, 10);
    }

    return null;
  }

  #toString(value) {
    if (typeof value !== 'string') {
      return value == null ? '' : String(value);
    }
    return value.trim();
  }

  #normalizeCapacity(value) {
    if (!Number.isInteger(value)) {
      return 100;
    }
    return Math.max(1, value);
  }
}

const storeExports = {
  InvitationStore,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = storeExports;
}

if (typeof window !== 'undefined') {
  window.LinkedCommunicationInvitationStore = storeExports;
}
