'use strict';

// Content script that monitors LinkedIn navigation for capture trigger
// Scrolls connections page whenever the connections URL is opened and reports results

(function() {
  const LOG_PREFIX = '[Linked Communication][Content]';
  const URL_CHECK_INTERVAL_MS = 500;
  const DEFAULT_GATE_KEY = 'LinkedCommunication::allowConnectionsCapture';
  const TARGETS = [
    {
      label: 'LinkedIn connections page',
      bypassGate: false,
      gateKey: 'LinkedCommunication::allowConnectionsCapture',
      type: 'connections',
      matches(parsed) {
        return (
          parsed.origin === 'https://www.linkedin.com' &&
          parsed.pathname === '/mynetwork/invite-connect/connections/'
        );
      }
    },
    {
      label: 'Local connections test page',
      bypassGate: true,
      gateKey: 'LinkedCommunication::allowConnectionsCapture',
      type: 'connections',
      matches(parsed) {
        if (parsed.protocol !== 'file:') {
          return false;
        }

        const normalizedPath = decodeURIComponent(parsed.pathname || '')
          .toLowerCase()
          .replace(/\\/g, '/');
        return normalizedPath.endsWith('/connections _ linkedin.html');
      }
    },
    {
      label: 'LinkedIn invitations page',
      bypassGate: false,
      gateKey: 'LinkedCommunication::allowInvitationsCapture',
      type: 'invitations',
      matches(parsed) {
        return (
          parsed.origin === 'https://www.linkedin.com' &&
          parsed.pathname === '/mynetwork/invitation-manager/sent/'
        );
      }
    },
    {
      label: 'Local invitations test page',
      bypassGate: true,
      gateKey: 'LinkedCommunication::allowInvitationsCapture',
      type: 'invitations',
      matches(parsed) {
        if (parsed.protocol !== 'file:') {
          return false;
        }

        const normalizedPath = decodeURIComponent(parsed.pathname || '')
          .toLowerCase()
          .replace(/\\/g, '/');
        return normalizedPath.endsWith('/invitation manager _ linkedin.html');
      }
    }
  ];

  function getGateKey(target) {
    return target?.gateKey ?? DEFAULT_GATE_KEY;
  }

  function clearCaptureGate(gateKey) {
    if (chrome?.storage?.local?.remove) {
      chrome.storage.local.remove(gateKey).catch(() => {});
    }
  }

  async function checkCaptureGate(gateKey) {
    if (!chrome?.storage?.local?.get) {
      return false;
    }

    try {
      const result = await chrome.storage.local.get(gateKey);
      const payload = result?.[gateKey];
      if (!payload || typeof payload !== 'object') {
        return false;
      }

      if (!payload.allow) {
        return false;
      }

      const expiresAt = Number(payload.expiresAt);
      if (Number.isFinite(expiresAt) && expiresAt < Date.now()) {
        return false;
      }

      return true;
    } catch (error) {
      console.warn('[Linked Communication][Content] Failed to read capture gate payload.', error);
      return false;
    }
  }

  async function resolveConnectionLimit() {
    const defaults = window.LinkedCommunicationMemoryDefaults;
    const fallback = Number.isFinite(defaults?.DEFAULT_MEMORY?.connectionLimit)
      ? defaults.DEFAULT_MEMORY.connectionLimit
      : 20;

    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        return fallback;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const limit = memory.getConnectionLimit?.();
      if (Number.isFinite(limit) && limit > 0) {
        return limit;
      }
    } catch (error) {
      logger.warn('resolveConnectionLimit failed, using fallback', error);
    }

    return fallback;
  }

  async function resolveInvitationLimit() {
    const defaults = window.LinkedCommunicationMemoryDefaults;
    const fallback = Number.isFinite(defaults?.DEFAULT_MEMORY?.invitationLimit)
      ? defaults.DEFAULT_MEMORY.invitationLimit
      : 5;

    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        return fallback;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const limit = memory.getInvitationLimit?.();
      if (Number.isFinite(limit) && limit > 0) {
        return limit;
      }
    } catch (error) {
      logger.warn('resolveInvitationLimit failed, using fallback', error);
    }

    return fallback;
  }

  let urlMonitorId = null;
  const captureState = {
    inProgress: false,
    label: null,
    type: 'connections'
  };

  const logger = createLogger(LOG_PREFIX);

  logger.log('Content script loaded on:', window.location.href);

  // Auto-capture disabled - extension now operates in manual-only mode
  // User must click the manual extract button in the popup
  // ensureUrlMonitor();
  // evaluateCurrentLocation(window.location.href);
  logger.log('Manual mode enabled - auto-capture disabled. Use popup buttons to extract.');

  function ensureUrlMonitor() {
    if (urlMonitorId !== null) {
      return;
    }

    let lastUrl = window.location.href;
    urlMonitorId = setInterval(() => {
      const currentUrl = window.location.href;
      if (currentUrl === lastUrl) {
        return;
      }

      lastUrl = currentUrl;
      evaluateCurrentLocation(currentUrl);
    }, URL_CHECK_INTERVAL_MS);

    logger.log(`URL monitor registered (interval=${URL_CHECK_INTERVAL_MS}ms).`);
  }

  function evaluateCurrentLocation(url) {
    const target = resolveCaptureTarget(url);
    if (!target) {
      return;
    }

    if (target.bypassGate) {
      logger.log(`${target.label} detected; bypassing capture gate.`);
      triggerCapture(url, target);
      return;
    }

    const gateKey = getGateKey(target);

    checkCaptureGate(gateKey).then((allowed) => {
      if (!allowed) {
        logger.log('Capture gate missing or expired; skipping auto capture.');
        return;
      }

      clearCaptureGate(gateKey);
      triggerCapture(url, target);
    }).catch((error) => {
      logger.warn('Capture gate evaluation failed; skipping capture.', error);
      return;
    });
  }

  function resolveCaptureTarget(candidate) {
    if (typeof candidate !== 'string' || candidate.length === 0) {
      return null;
    }

    try {
      const parsed = new URL(candidate, window.location.href);

      for (const target of TARGETS) {
        try {
          if (target.matches(parsed)) {
            return {
              label: target.label,
              parsed,
              bypassGate: Boolean(target.bypassGate),
              gateKey: getGateKey(target),
              type: target.type
            };
          }
        } catch (matchError) {
          logger.warn(`Target match evaluation failed for ${target.label}`, matchError);
        }
      }
    } catch (error) {
      logger.warn('Failed to parse URL', candidate, error);
      return null;
    }

    return null;
  }

  function triggerCapture(url, targetInfo) {
    if (captureState.inProgress) {
      logger.log(
        `Capture already in progress for ${captureState.label ?? 'unknown target'}, skipping additional trigger.`
      );
      return;
    }

    captureState.inProgress = true;
    captureState.label = targetInfo?.label ?? null;
    captureState.type = targetInfo?.type ?? 'connections';

    const start = () => {
      logger.log(`Capture target detected (${captureState.label ?? 'unlabeled'}) for`, url);

      initCapture()
        .catch((error) => {
          logger.warn('Capture routine failed', error);
        })
        .finally(() => {
          captureState.inProgress = false;
          captureState.label = null;
          captureState.type = 'connections';
        });
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
      start();
    }
  }

  function initCapture() {
    logger.log('Page loaded, waiting for workspace...');

    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        clearInterval(checkWorkspace);
        const error = new Error('Workspace not found after 10 seconds');
        logger.warn(error.message);
        reject(error);
      }, 10000);

      const checkWorkspace = setInterval(() => {
        const workspace = document.querySelector('#workspace');
        const scrollRoot =
          document.querySelector('#workspace .scaffold-finite-scroll__content') ||
          document.querySelector('#workspace .scaffold-finite-scroll__body') ||
          document.querySelector('#workspace');

        if (workspace && scrollRoot) {
          clearTimeout(timeoutId);
          clearInterval(checkWorkspace);

          if (captureState.type === 'invitations') {
            startScrollAndCaptureInvitations(scrollRoot)
              .then(resolve)
              .catch((error) => {
                logger.warn('startScrollAndCaptureInvitations failed', error);
                reject(error);
              });
          } else {
            startScrollAndCapture(scrollRoot)
              .then(resolve)
              .catch((error) => {
                logger.warn('startScrollAndCapture failed', error);
                reject(error);
              });
          }
        }
      }, 500);
    });
  }

  async function startScrollAndCaptureInvitations(scrollRoot) {
    const targetInvitations = await resolveInvitationLimit();
    const maxScrolls = 50;
    const waitMs = 1000;

    // Extract total count from page
    const totalAvailable = extractTotalInvitationsCount();
    
    // Use the minimum of user target and available on page
    const scrollTarget = totalAvailable 
      ? Math.min(targetInvitations, totalAvailable)
      : targetInvitations;

    logger.log(`Starting invitations scroll routine... (Total available: ${totalAvailable || 'unknown'}, User target: ${targetInvitations}, Scroll target: ${scrollTarget})`);

    // Count invitations within workspace (match InvitationScraper logic)
    const countInvitations = () => {
      const workspaceEl = document.querySelector('#workspace');
      if (!workspaceEl) return 0;
      const items = workspaceEl.querySelectorAll('[role="listitem"]');
      // Filter for items with profile links (actual invitations)
      return Array.from(items).filter(item => 
        item.querySelector('a[href*="linkedin.com/in/"]')
      ).length;
    };

    let scrollCount = 0;
    let invitationCount = countInvitations();
    let previousCount = 0;

    logger.log(`Currently loaded: ${invitationCount} invitation(s) in workspace`);

    // Check if we already have enough invitations loaded
    if (invitationCount >= scrollTarget) {
      logger.log(`Target already met: ${invitationCount} loaded >= ${scrollTarget} target, no scrolling needed`);
      scrollCount = 0; // No scrolls performed
    } else {
      logger.log(`Need ${scrollTarget - invitationCount} more invitations, starting scroll...`);

      let noProgressCount = 0;
      const maxNoProgress = 3; // Allow 3 scrolls with no progress before stopping

      while (scrollCount < maxScrolls) {
        invitationCount = countInvitations();
        
        // Check if scrolling made progress
        if (scrollCount > 0 && invitationCount === previousCount) {
          noProgressCount++;
          logger.log(`No new invitations after scroll ${scrollCount}. No-progress count: ${noProgressCount}/${maxNoProgress}`);
          
          if (noProgressCount >= maxNoProgress) {
            logger.log(`Stopping after ${maxNoProgress} scrolls with no progress. Final count: ${invitationCount} invitations.`);
            break;
          }
        } else {
          noProgressCount = 0; // Reset counter when progress is made
        }
        
        // If we've reached the scroll target, stop
        if (invitationCount >= scrollTarget) {
          logger.log(`Scroll target reached: ${invitationCount} invitations`);
          break;
        }

      previousCount = invitationCount;

      const delta = Math.max(400, scrollRoot?.clientHeight ?? window.innerHeight ?? 800);
      const currentTop = Number.isFinite(window.scrollY)
        ? window.scrollY
        : window.pageYOffset ?? 0;
      const nextTop = currentTop + delta;

      if (typeof window.scrollTo === 'function') {
        try {
          window.scrollTo({ top: nextTop, behavior: 'auto' });
        } catch (error) {
          window.scrollTo(0, nextTop);
        }
      }

      if (scrollRoot) {
        if (typeof scrollRoot.scrollBy === 'function') {
          scrollRoot.scrollBy({ top: delta, behavior: 'auto' });
        } else {
          const nextRootTop = (scrollRoot.scrollTop ?? 0) + delta;
          if (typeof scrollRoot.scrollHeight === 'number') {
            scrollRoot.scrollTop = Math.min(nextRootTop, scrollRoot.scrollHeight);
          } else {
            scrollRoot.scrollTop = nextRootTop;
          }
        }
      }

      scrollCount++;
      logger.log(`Scroll ${scrollCount}: Scrolled ${delta}px. Current invitations: ${invitationCount}`);
      
      await new Promise((resolve) => setTimeout(resolve, waitMs));

      if (scrollCount % 10 === 0) {
        const currentCount = countInvitations();
        logger.log(`Progress: ${scrollCount} scrolls, ${currentCount} invitations`);
      }
      }
    }

    // Get final count after scrolling
    const finalCount = countInvitations();
    logger.log(`Scroll complete: ${scrollCount} scrolls, ${finalCount} invitations loaded`);

    const workspaceForScraping = document.querySelector('#workspace');
    if (!workspaceForScraping) {
      logger.error('Workspace element not found for scraping');
      return;
    }

    const ownerIdRaw = await getUserId();
    if (!ownerIdRaw) {
      logger.error('No user_id available, cannot validate or save invitations');
      return;
    }

    const ownerId = Number.parseInt(ownerIdRaw, 10);
    if (!Number.isFinite(ownerId)) {
      logger.error(`Retrieved user_id "${ownerIdRaw}" is not a valid integer`);
      return;
    }

    const scrapedInvitations = scrapeInvitations({ workspace: workspaceForScraping, ownerId });
    logger.log(`Scraped ${scrapedInvitations.length} invitations`);

    if (scrapedInvitations.length === 0) {
      logger.warn('No invitations scraped, stopping workflow');
      return;
    }

    logger.log(`Processing ${scrapedInvitations.length} invitations for user ${ownerId}`);

    // Validate against Xano to filter out existing invitations
    const newInvitations = await filterExistingInvitations(scrapedInvitations);
    logger.log(`${newInvitations.length} new invitations after validation`);

    if (newInvitations.length > 0) {
      // Save new invitations to Xano sequentially
      await saveInvitationsToXano(newInvitations);
    } else {
      logger.log('All invitations already exist in Xano');
    }
    
    // Always save the extraction timestamp to memory (even if no new invitations)
    await recordInvitationExtractTime();
    logger.log('Invitations capture workflow complete');
  }

  async function startScrollAndCapture(scrollRoot) {
    const targetConnections = await resolveConnectionLimit();
    const maxScrolls = 50;
    const waitMs = 1000;

    let scrollCount = 0;
    let connectionCount = 0;

    logger.log('Starting connections scroll routine...');

    while (scrollCount < maxScrolls && connectionCount < targetConnections) {
      connectionCount = document.querySelectorAll('[data-view-name="connections-list"] [data-view-name="message-button"]').length;

      if (connectionCount >= targetConnections) {
        logger.log(`Target reached: ${connectionCount} connections`);
        break;
      }

      const delta = Math.max(200, scrollRoot?.clientHeight ?? window.innerHeight ?? 600);
      const currentTop = Number.isFinite(window.scrollY)
        ? window.scrollY
        : window.pageYOffset ?? 0;
      const nextTop = currentTop + delta;

      if (typeof window.scrollTo === 'function') {
        try {
          window.scrollTo({ top: nextTop, behavior: 'auto' });
        } catch (error) {
          window.scrollTo(0, nextTop);
        }
      }

      if (scrollRoot) {
        if (typeof scrollRoot.scrollBy === 'function') {
          scrollRoot.scrollBy({ top: delta, behavior: 'auto' });
        } else {
          const nextRootTop = (scrollRoot.scrollTop ?? 0) + delta;
          if (typeof scrollRoot.scrollHeight === 'number') {
            scrollRoot.scrollTop = Math.min(nextRootTop, scrollRoot.scrollHeight);
          } else {
            scrollRoot.scrollTop = nextRootTop;
          }
        }
      }

      scrollCount++;

      if (scrollCount % 10 === 0) {
        logger.log(`Progress: ${scrollCount} scrolls, ${connectionCount} connections`);
      }

      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }

    logger.log(`Scroll complete: ${scrollCount} scrolls, ${connectionCount} connections`);

    const ownerIdRaw = await getUserId();
    if (!ownerIdRaw) {
      logger.error('No user_id available, cannot validate or save connections');
      return;
    }

    const ownerId = Number.parseInt(ownerIdRaw, 10);
    if (!Number.isFinite(ownerId)) {
      logger.error(`Retrieved user_id "${ownerIdRaw}" is not a valid integer`);
      return;
    }

    const scrapedConnections = scrapeConnections({ ownerId });
    logger.log(`Scraped ${scrapedConnections.length} connections`);
    logger.log('🔍 DEBUG CODE ACTIVE - Extension reloaded successfully');

    // Debug: Log sample scraped records
    const jesusSample = scrapedConnections.find(c => c.Connection_Profile_URL === 'jesusdavidprieto');
    if (jesusSample) {
      logger.log('[CHECKPOINT 1 - After Scraping] Jesús Prieto record:', JSON.stringify(jesusSample, null, 2));
    }

    if (scrapedConnections.length === 0) {
      logger.warn('No connections scraped, stopping workflow');
      return;
    }

    logger.log(`Processing ${scrapedConnections.length} connections for user ${ownerId}`);

    // Validate against Xano to filter out existing connections
    const newConnections = await filterExistingConnections(scrapedConnections);
    logger.log(`${newConnections.length} new connections after validation`);

    // Debug: Log sample after filtering
    const jesusAfterFilter = newConnections.find(c => c.Connection_Profile_URL === 'jesusdavidprieto');
    if (jesusAfterFilter) {
      logger.log('[CHECKPOINT 2 - After Filtering] Jesús Prieto record:', JSON.stringify(jesusAfterFilter, null, 2));
    }

    if (newConnections.length === 0) {
      logger.log('All connections already exist in Xano');
      await reportCaptureCompletion({
        totalScraped: scrapedConnections.length,
        totalNewConnections: 0,
      });
      return;
    }

    // Save new connections to Xano sequentially
    await saveConnectionsToXano(newConnections);
    logger.log('Capture workflow complete');

    await reportCaptureCompletion({
      totalScraped: scrapedConnections.length,
      totalNewConnections: newConnections.length,
    });
  }

  async function reportCaptureCompletion({ totalScraped = 0, totalNewConnections = 0 } = {}) {
    const timestamp = Date.now();

    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      const MemoryClass = memoryModule?.LongTermMemory;

      if (MemoryClass) {
        const memory = new MemoryClass();
        await memory.load();
        memory.setLastImportConnectionDate?.(new Date(timestamp));
        await memory.save();
        logger.log('Updated long-term memory with capture timestamp.');
      }
    } catch (error) {
      logger.warn('Failed to update long-term memory after capture.', error);
    }

    if (chrome?.runtime?.sendMessage) {
      try {
        await chrome.runtime.sendMessage({
          type: 'manual-extract-completed',
          payload: {
            timestamp,
            totalNewConnections,
            source: 'content-script',
            totalScraped,
          },
        });
      } catch (error) {
        logger.warn('Failed to notify background of capture completion.', error);
      }
    }
  }

  function scrapeConnections({ ownerId = null } = {}) {
    const toTrimmedText = (text) => (typeof text === 'string' ? text.trim() : '');

    const stripHeadline = (text, position) => {
      if (!text || !position) {
        return text;
      }

      let result = text;

      // Remove the position string if it appears in the text
      if (result.includes(position)) {
        result = result.replace(position, '').trim();
      }

      // Remove newlines and everything after
      const newlineIndex = result.search(/[\r\n]/);
      if (newlineIndex >= 0) {
        result = result.slice(0, newlineIndex).trim();
      }

      // Remove everything after delimiter if found
      const delimiterMatch = result.match(/\s[|•·–—-]+\s/);
      if (delimiterMatch) {
        result = result.slice(0, delimiterMatch.index).trim();
      }

      // Remove trailing delimiters
      result = result.replace(/[|•·–—-]+$/g, '').trim();

      // If result contains job keywords, cut at first occurrence
      const keywordMatch = result.match(/\b(CEO|Founder|Officer|Consultant|Director|President|Manager|Engineer|Developer|Designer|Ambassador|Advisor|Coach|Strategist|Builder|Entrepreneur|Marketing|Growth|Product|Community)\b/i);
      if (keywordMatch && keywordMatch.index > 0) {
        result = result.slice(0, keywordMatch.index).trim();
      }

      return result;
    };

    const extractSlug = (reference) => {
      if (!reference) {
        return '';
      }

      let target = reference;
      try {
        const url = new URL(reference, 'https://www.linkedin.com');
        target = url.pathname;
      } catch (error) {
        // keep relative reference
      }

      const match = target.match(/\/in\/([^/?#]+)(?:\/|$)/i);
      return match ? decodeURIComponent(match[1]) : '';
    };

    const splitName = (fullName) => {
      const parts = (fullName || '')
        .split(' ')
        .map((part) => part.trim())
        .filter(Boolean);

      const count = parts.length;
      if (count === 0) {
        return { firstName: '', lastName: '' };
      }

      if (count === 1) {
        return { firstName: parts[0], lastName: '' };
      }

      if (count === 2) {
        return { firstName: parts[0], lastName: parts[1] };
      }

      if (count === 4) {
        const midpoint = count / 2;
        return {
          firstName: parts.slice(0, midpoint).join(' '),
          lastName: parts.slice(midpoint).join(' '),
        };
      }

      return {
        firstName: parts.slice(0, count - 1).join(' '),
        lastName: parts[count - 1],
      };
    };

    const toPosition = (element) => {
      const candidates = [
        element.querySelector('p[class*="ce3ac449"], p[class*="0dfd3b8b"], span[class*="ce3ac449"]'),
        element.querySelector('p + p'),
      ];

      for (const node of candidates) {
        const value = toTrimmedText(node?.textContent);
        if (value && !/^Connected on/i.test(value)) {
          return value;
        }
      }

      return null;
    };

    const toConnectedOn = (element) => {
      const texts = Array.from(element.querySelectorAll('p, span, li'))
        .map((node) => toTrimmedText(node?.textContent))
        .filter((text) => /^Connected on/i.test(text));
      return texts[0] || null;
    };

    const findCardRoot = (marker) => {
      if (!marker) {
        return null;
      }

      const direct = marker.closest?.('[data-view-name="connections-list"] [componentkey]');
      if (direct?.querySelector?.('[data-view-name="message-button"]')) {
        return direct;
      }

      let current = marker;
      let depth = 0;
      const MAX_DEPTH = 150;
      while (current && depth < MAX_DEPTH) {
        if (current.querySelector?.('[data-view-name="message-button"]')) {
          return current;
        }
        current = current.parentElement ?? current.parentNode ?? null;
        depth += 1;
      }

      return marker;
    };

    const containers = Array.from(document.querySelectorAll('[data-view-name="connections-list"]'));
    if (containers.length === 0) {
      logger.warn('No connections list containers found');
      return [];
    }

    const results = [];
    const seen = new Set();

    containers.forEach((container) => {
      const markers = Array.from(
        container.querySelectorAll('[componentkey][data-view-name="connections-profile"]')
      );

      markers
        .map((marker) => findCardRoot(marker))
        .filter(Boolean)
        .forEach((card) => {
          const messageLink = card.querySelector('[data-view-name="message-button"] a');
          const profileUrn = messageLink?.getAttribute('href') ?? '';

          const profileAnchors = Array.from(card.querySelectorAll('a[href*="linkedin.com/in/"]'));
          if (profileAnchors.length === 0) {
            return;
          }

          const profileNameLink =
            profileAnchors.find((anchor) => toTrimmedText(anchor.textContent).length > 0) || profileAnchors[0];

          const rawReference = profileNameLink?.getAttribute('href') ?? profileUrn;
          const profileSlug = extractSlug(rawReference);
          if (!profileSlug) {
            return;
          }

          const fingerprint = `${ownerId ?? ''}::${profileSlug}`;
          if (seen.has(fingerprint)) {
            return;
          }

          // Debug: Log name element selection for Jesús Prieto and Isabella
          if (profileSlug === 'jesusdavidprieto' || profileSlug?.includes('isabella')) {
            logger.log(`[DEBUG ${profileSlug}] profileNameLink.textContent:`, profileNameLink?.textContent);
            logger.log(`[DEBUG ${profileSlug}] profileNameLink.outerHTML:`, profileNameLink?.outerHTML?.substring(0, 300));
          }

          // Get position first to use for headline stripping
          const position = toPosition(card);

          const fullNameText = (() => {
            const nameCandidates = [
              profileNameLink?.textContent,
              card.querySelector('p[class*="4682befa"], p[class*="1e1ac73c"], h3')?.textContent,
              card.querySelector('a[href*="linkedin.com/in/"] span')?.textContent,
            ];
            
            // Debug: Log candidates for Jesús Prieto and Isabella
            if (profileSlug === 'jesusdavidprieto' || profileSlug?.includes('isabella')) {
              logger.log(`[DEBUG ${profileSlug}] Name candidates:`, nameCandidates.map((t, i) => `[${i}]: "${toTrimmedText(t)}"`));
              logger.log(`[DEBUG ${profileSlug}] Position for stripping:`, position);
            }
            
            const rawText = nameCandidates
              .map((text) => toTrimmedText(text))
              .find((text) => text && !/\bmessage\b/i.test(text) && !/^connected on/i.test(text)) ?? '';
            
            // Strip headline from name if position is present
            if (rawText && position) {
              const strippedText = stripHeadline(rawText, position);
              if (profileSlug === 'jesusdavidprieto' || profileSlug?.includes('isabella')) {
                logger.log(`[DEBUG ${profileSlug}] After stripping:`, strippedText);
              }
              return strippedText;
            }
            
            return rawText;
          })();

          if (!fullNameText) {
            return;
          }

          const { firstName, lastName } = splitName(fullNameText);
          if (!firstName && !lastName) {
            return;
          }

          const connectedOn = toConnectedOn(card);

          results.push({
            user_id: ownerId ?? null,
            First_Name: firstName ?? '',
            Last_Name: lastName ?? '',
            Connection_Profile_URL: profileSlug,
            Email_Address: null,
            Company: null,
            Position: position,
            Connected_On: connectedOn,
          });

          seen.add(fingerprint);
        });
    });

    logger.log(`Scrape produced ${results.length} unique connections`);
    return results;
  }

  async function getUserId() {
    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        logger.warn('LongTermMemory module not available');
        return null;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const userId = memory.getUserId();
      
      if (!userId) {
        logger.warn('No user_id found in LongTermMemory');
        return null;
      }

      return userId;
    } catch (error) {
      logger.error('Failed to retrieve user_id from LongTermMemory:', error);
      return null;
    }
  }

  async function filterExistingConnections(records) {
    if (!Array.isArray(records) || records.length === 0) {
      return Array.isArray(records) ? records : [];
    }

    const payload = records
      .map((record) => {
        if (!record || typeof record !== 'object') {
          return null;
        }

        const userIdRaw = record.user_id ?? record.userId ?? null;
        const slugRaw = record.Connection_Profile_URL ?? record.linkedin_profile ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const slug = typeof slugRaw === 'string' ? slugRaw.trim() : '';

        if (!userId || !slug) {
          return null;
        }

        return {
          user_id: userId,
          linkedin_profile: slug,
        };
      })
      .filter(Boolean);

    if (payload.length === 0) {
      logger.log('Duplicate validation skipped; no payload generated.');
      return records;
    }

    const payloadPreview = payload
      .slice(0, Math.min(3, payload.length))
      .map((entry) => entry.linkedin_profile)
      .join(', ');
    logger.log(
      `Validating ${payload.length} connection(s) with Xano (sample: ${payloadPreview}${
        payload.length > 3 ? '…' : ''
      }).`
    );

    const xanoExports = window.LinkedCommunicationXanoClient;
    const XanoClient = xanoExports?.XanoClient;

    if (!XanoClient) {
      logger.warn('Xano client unavailable; skipping duplicate validation.');
      return records;
    }

    const xanoClient = new XanoClient();

    try {
      const existing = await xanoClient.validateConnections(payload);
      const status = existing?.statusCode ?? existing?.status ?? null;
      if (status) {
        logger.log(`Xano validation HTTP status: ${status}`);
      }
      const existingArray = Array.isArray(existing)
        ? existing
        : Array.isArray(existing?.data)
          ? existing.data
          : [];

      if (existingArray.length === 0) {
        logger.log('Xano reports 0 existing connections.');
        return records;
      }

      const existingPreview = existingArray
        .slice(0, Math.min(3, existingArray.length))
        .map((item) => item.Connection_Profile_URL ?? item.linkedin_profile ?? 'unknown')
        .join(', ');
      logger.log(
        `Xano reports ${existingArray.length} existing connection(s) (sample: ${existingPreview}${
          existingArray.length > 3 ? '…' : ''
        }).`
      );

      const existingSet = new Set();

      existingArray.forEach((item) => {
        if (!item || typeof item !== 'object') {
          return;
        }

        const userIdRaw = item.user_id ?? item.userId ?? null;
        const encodedSlugRaw = item.Connection_Profile_URL ?? item.linkedin_profile ?? null;
        const inputSlugRaw = item.Connection_Profile_URL_Input ?? item.linkedin_profile_input ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const encodedSlug = typeof encodedSlugRaw === 'string' ? encodedSlugRaw.trim() : '';
        const inputSlug = typeof inputSlugRaw === 'string' ? inputSlugRaw.trim() : '';

        if (!userId) {
          return;
        }

        if (encodedSlug) {
          existingSet.add(`${userId}::${encodedSlug}`);
        }

        if (inputSlug) {
          existingSet.add(`${userId}::${inputSlug}`);
        }
      });

      if (existingSet.size === 0) {
        return records;
      }

      const removed = [];
      const kept = [];

      const result = records.filter((record) => {
        const userId = typeof record.user_id === 'number'
          ? String(record.user_id)
          : String(record.user_id ?? '').trim();
        const slug = typeof record.Connection_Profile_URL === 'string'
          ? record.Connection_Profile_URL.trim()
          : '';

        if (!userId || !slug) {
          logger.log('Keeping connection without user/slug for safety:', record);
          return true;
        }

        const fingerprint = `${userId}::${slug}`;
        const isDuplicate = existingSet.has(fingerprint);
        if (isDuplicate) {
          removed.push(fingerprint);
        } else {
          kept.push(fingerprint);
        }

        return !isDuplicate;
      });

      if (removed.length > 0) {
        logger.log(
          `Duplicate fingerprints removed: ${removed
            .slice(0, 3)
            .join(', ')}${removed.length > 3 ? '…' : ''}`
        );
      }

      return result;
    } catch (error) {
      logger.warn('Failed to validate existing connections via Xano.', error);
      return records;
    }
  }

  async function saveConnectionsToXano(connections) {
    if (!Array.isArray(connections) || connections.length === 0) {
      return;
    }

    try {
      const xanoModule = window.LinkedCommunicationXanoClient;
      if (!xanoModule?.XanoClient) {
        logger.error('XanoClient not available, cannot save connections');
        return;
      }

      const xanoClient = new xanoModule.XanoClient();
      const delayMs = 1000;

      logger.log(`Saving ${connections.length} connections to Xano`);

      for (let i = 0; i < connections.length; i++) {
        const conn = connections[i];
        
        // Debug: Log Jesús Prieto record before sending
        if (conn.Connection_Profile_URL === 'jesusdavidprieto') {
          logger.log('[CHECKPOINT 3 - Before Xano] Jesús Prieto record:', JSON.stringify(conn, null, 2));
        }
        
        try {
          await xanoClient.createConnection(conn);
          logger.log(`Saved connection ${i + 1}/${connections.length}: ${conn.Connection_Profile_URL}`);
        } catch (error) {
          logger.error(`Failed to save connection ${conn.Connection_Profile_URL}:`, error);
        }

        if (i < connections.length - 1) {
          await new Promise(resolve => setTimeout(resolve, delayMs));
        }
      }

      logger.log('All connections saved to Xano');
    } catch (error) {
      logger.error('Failed to save connections to Xano:', error);
    }
  }

  function extractTotalInvitationsCount() {
    try {
      // Look for "People (X)" pattern in nav buttons
      const navButtons = document.querySelectorAll('nav button[aria-current="true"]');
      for (const button of navButtons) {
        const text = button.textContent?.trim() || '';
        const match = text.match(/People\s*\((\d+)\)/i);
        if (match) {
          const count = Number.parseInt(match[1], 10);
          if (Number.isFinite(count)) {
            return count;
          }
        }
      }

      // Fallback: look anywhere in the page
      const allText = document.body.textContent || '';
      const match = allText.match(/People\s*\((\d+)\)/i);
      if (match) {
        const count = Number.parseInt(match[1], 10);
        if (Number.isFinite(count)) {
          return count;
        }
      }
    } catch (error) {
      logger.warn('Failed to extract total invitations count:', error);
    }
    
    return null;
  }

  function scrapeInvitations({ workspace = null, ownerId = null } = {}) {
    if (!workspace) {
      logger.warn('No workspace provided for invitation scraping');
      return [];
    }

    const InvitationScraperModule = window.LinkedCommunicationInvitationScraperModule;
    if (!InvitationScraperModule?.InvitationScraper) {
      logger.error('InvitationScraper module not available');
      return [];
    }

    try {
      const InvitationStoreModule = window.LinkedCommunicationInvitationStore;
      if (!InvitationStoreModule?.InvitationStore) {
        logger.error('InvitationStore module not available');
        return [];
      }

      const store = new InvitationStoreModule.InvitationStore();
      const scraper = new InvitationScraperModule.InvitationScraper(store);
      
      const html = workspace.outerHTML;
      const invitations = scraper.scrapeFromHtml(html);
      
      // Add ownerId to each invitation
      const invitationsWithUser = invitations.map(inv => ({
        ...inv,
        user_id: ownerId ?? null
      }));
      
      logger.log(`InvitationScraper returned ${invitationsWithUser.length} invitations`);
      return invitationsWithUser;
    } catch (error) {
      logger.error('Failed to scrape invitations:', error);
      return [];
    }
  }

  async function filterExistingInvitations(records) {
    if (!Array.isArray(records) || records.length === 0) {
      return Array.isArray(records) ? records : [];
    }

    const payload = records
      .map((record) => {
        if (!record || typeof record !== 'object') {
          return null;
        }

        const userIdRaw = record.user_id ?? record.userId ?? null;
        const slugRaw = record.Connection_Profile_URL ?? record.linkedin_profile ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const slug = typeof slugRaw === 'string' ? slugRaw.trim() : '';

        if (!userId || !slug) {
          return null;
        }

        return {
          user_id: userId,
          linkedin_profile: slug,
        };
      })
      .filter(Boolean);

    if (payload.length === 0) {
      logger.log('Invitation validation skipped; no payload generated.');
      return records;
    }

    const payloadPreview = payload
      .slice(0, Math.min(3, payload.length))
      .map((entry) => entry.linkedin_profile)
      .join(', ');
    logger.log(
      `Validating ${payload.length} invitation(s) with Xano (sample: ${payloadPreview}${
        payload.length > 3 ? '…' : ''
      }).`
    );

    const xanoExports = window.LinkedCommunicationXanoClient;
    const XanoClient = xanoExports?.XanoClient;

    if (!XanoClient) {
      logger.warn('Xano client unavailable; skipping duplicate validation.');
      return records;
    }

    const xanoClient = new XanoClient();

    try {
      const existing = await xanoClient.validateInvitations(payload);
      const status = existing?.statusCode ?? existing?.status ?? null;
      if (status) {
        logger.log(`Xano invitation validation HTTP status: ${status}`);
      }
      const existingArray = Array.isArray(existing)
        ? existing
        : Array.isArray(existing?.data)
          ? existing.data
          : [];

      if (existingArray.length === 0) {
        logger.log('Xano reports 0 existing invitations.');
        return records;
      }

      const existingPreview = existingArray
        .slice(0, Math.min(3, existingArray.length))
        .map((item) => item.Connection_Profile_URL ?? item.linkedin_profile ?? 'unknown')
        .join(', ');
      logger.log(
        `Xano reports ${existingArray.length} existing invitation(s) (sample: ${existingPreview}${
          existingArray.length > 3 ? '…' : ''
        }).`
      );

      const existingSet = new Set();

      existingArray.forEach((item) => {
        if (!item || typeof item !== 'object') {
          return;
        }

        const userIdRaw = item.user_id ?? item.userId ?? null;
        const encodedSlugRaw = item.Connection_Profile_URL ?? item.linkedin_profile ?? null;
        const inputSlugRaw = item.Connection_Profile_URL_Input ?? item.linkedin_profile_input ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const encodedSlug = typeof encodedSlugRaw === 'string' ? encodedSlugRaw.trim() : '';
        const inputSlug = typeof inputSlugRaw === 'string' ? inputSlugRaw.trim() : '';

        if (!userId) {
          return;
        }

        if (encodedSlug) {
          existingSet.add(`${userId}::${encodedSlug}`);
        }

        if (inputSlug) {
          existingSet.add(`${userId}::${inputSlug}`);
        }
      });

      if (existingSet.size === 0) {
        return records;
      }

      const removed = [];
      const kept = [];

      const result = records.filter((record) => {
        const userId = typeof record.user_id === 'number'
          ? String(record.user_id)
          : String(record.user_id ?? '').trim();
        const slug = typeof record.Connection_Profile_URL === 'string'
          ? record.Connection_Profile_URL.trim()
          : '';

        if (!userId || !slug) {
          logger.log('Keeping invitation without user/slug for safety:', record);
          return true;
        }

        const fingerprint = `${userId}::${slug}`;
        const isDuplicate = existingSet.has(fingerprint);
        if (isDuplicate) {
          removed.push(fingerprint);
        } else {
          kept.push(fingerprint);
        }

        return !isDuplicate;
      });

      if (removed.length > 0) {
        logger.log(
          `Duplicate invitation fingerprints removed: ${removed
            .slice(0, 3)
            .join(', ')}${removed.length > 3 ? '…' : ''}`
        );
      }

      return result;
    } catch (error) {
      logger.warn('Failed to validate existing invitations via Xano.', error);
      return records;
    }
  }

  async function saveInvitationsToXano(invitations) {
    if (!Array.isArray(invitations) || invitations.length === 0) {
      return;
    }

    try {
      const xanoModule = window.LinkedCommunicationXanoClient;
      if (!xanoModule?.XanoClient) {
        logger.error('XanoClient not available, cannot save invitations');
        return;
      }

      const xanoClient = new xanoModule.XanoClient();
      const delayMs = 1000;

      logger.log(`Saving ${invitations.length} invitations to Xano`);

      for (let i = 0; i < invitations.length; i++) {
        const inv = invitations[i];
        try {
          await xanoClient.createInvitation(inv);
          logger.log(`Saved invitation ${i + 1}/${invitations.length}: ${inv.Connection_Profile_URL}`);
        } catch (error) {
          logger.error(`Failed to save invitation ${inv.Connection_Profile_URL}:`, error);
        }

        if (i < invitations.length - 1) {
          await new Promise(resolve => setTimeout(resolve, delayMs));
        }
      }

      logger.log('All invitations saved to Xano');
    } catch (error) {
      logger.error('Failed to save invitations to Xano:', error);
    }
  }

  async function recordInvitationExtractTime() {
    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        logger.warn('LongTermMemory module unavailable; skipping timestamp persistence.');
        return;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const timestamp = new Date();
      logger.log('Setting invitation extract timestamp:', timestamp.toISOString());
      memory.setLastImportInvitationDate?.(timestamp);
      await memory.save();
      logger.log('Recorded invitation extract timestamp in long-term memory.');
      
      // Verify it was saved
      await memory.load();
      const saved = memory.getLastImportInvitationDate?.();
      logger.log('Verified saved invitation timestamp:', saved);
    } catch (error) {
      logger.warn('Failed to record invitation extract timestamp in long-term memory.', error);
    }
  }

  function createLogger(prefix) {
    const send = (level, args) => {
      const timestamp = new Date().toISOString().replace('T', ' ').slice(0, 23);
      const loggerFn = typeof console[level] === 'function' ? console[level] : console.log;
      loggerFn(`${prefix} [${timestamp}]`, ...args);

      try {
        if (chrome?.runtime?.id) {
          chrome.runtime.sendMessage({
            type: 'content-log',
            payload: {
              level,
              prefix,
              args
            }
          }).catch(() => {});
        }
      } catch (messagingError) {
        loggerFn(prefix, 'Failed to relay log to background', messagingError);
      }
    };

    return {
      log: (...args) => send('log', args),
      info: (...args) => send('info', args),
      warn: (...args) => send('warn', args),
      error: (...args) => send('error', args)
    };
  }

  // Expose for testing
  if (typeof window !== 'undefined') {
    window.LinkedCommunicationContentCapture = {
      scrapeConnections,
    };
  }
})();
