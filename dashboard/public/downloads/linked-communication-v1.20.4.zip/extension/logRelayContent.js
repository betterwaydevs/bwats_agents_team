'use strict';

const LOG_PREFIX = '[Linked Communication Popup]';

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== 'popup-log-broadcast') {
    return;
  }

  const level = typeof message.payload?.level === 'string' ? message.payload.level : 'log';
  const args = Array.isArray(message.payload?.args) ? message.payload.args : [];
  const target = typeof console[level] === 'function' ? console[level] : console.log;
  target(LOG_PREFIX, ...args);
});
