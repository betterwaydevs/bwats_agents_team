// LinkedIn Auto-Actions Script
// This script is injected into LinkedIn profile pages to perform automated actions

(function() {
  'use strict';

  const TYPING_MIN_DELAY = 30;  // ms between keystrokes
  const TYPING_MAX_DELAY = 80;  // ms between keystrokes
  const ACTION_DELAY = 500;     // ms between major actions

  // Utility: Random delay between min and max
  function randomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  // Utility: Sleep for given ms
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Utility: Wait for element to appear
  async function waitForElement(selector, timeout = 10000) {
    const startTime = Date.now();
    while (Date.now() - startTime < timeout) {
      const element = document.querySelector(selector);
      if (element) return element;
      await sleep(100);
    }
    throw new Error(`Element not found: ${selector}`);
  }

  // Utility: Type text character by character like a human
  async function humanType(element, text) {
    element.focus();

    for (const char of text) {
      // Simulate keydown, keypress, input, keyup events
      const keydownEvent = new KeyboardEvent('keydown', {
        key: char,
        code: `Key${char.toUpperCase()}`,
        charCode: char.charCodeAt(0),
        keyCode: char.charCodeAt(0),
        which: char.charCodeAt(0),
        bubbles: true
      });

      const keypressEvent = new KeyboardEvent('keypress', {
        key: char,
        code: `Key${char.toUpperCase()}`,
        charCode: char.charCodeAt(0),
        keyCode: char.charCodeAt(0),
        which: char.charCodeAt(0),
        bubbles: true
      });

      const inputEvent = new InputEvent('input', {
        data: char,
        inputType: 'insertText',
        bubbles: true
      });

      const keyupEvent = new KeyboardEvent('keyup', {
        key: char,
        code: `Key${char.toUpperCase()}`,
        charCode: char.charCodeAt(0),
        keyCode: char.charCodeAt(0),
        which: char.charCodeAt(0),
        bubbles: true
      });

      element.dispatchEvent(keydownEvent);
      element.dispatchEvent(keypressEvent);

      // Actually insert the character
      element.value += char;
      element.dispatchEvent(inputEvent);

      element.dispatchEvent(keyupEvent);

      // Random delay between keystrokes
      await sleep(randomDelay(TYPING_MIN_DELAY, TYPING_MAX_DELAY));
    }

    // Trigger change event at the end
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Main: Auto Connect with message
  async function autoConnect(inviteMessage) {
    try {
      // Step 1: Find and click the Connect button/link
      // LinkedIn now uses <a> tags with href="/preload/custom-invite/"
      // Try to find Connect in primary area first
      let connectBtn = document.querySelector('a[aria-label*="Invite"][aria-label*="connect"]')
        || document.querySelector('a[href*="custom-invite"]')
        || document.querySelector('button[aria-label*="to connect"][class*="artdeco-button--primary"]')
        || document.querySelector('button[aria-label*="Invite"][aria-label*="connect"]');

      // If not found in primary area, check the "More" dropdown
      if (!connectBtn) {
        const moreBtn = document.querySelector('button[aria-label="More actions"], button[aria-label*="More"]');
        if (moreBtn) {
          moreBtn.click();
          await sleep(500);

          // Look for Connect in dropdown menu - LinkedIn uses <a role="menuitem">
          const menu = document.querySelector('[role="menu"]');
          if (menu) {
            const menuitems = menu.querySelectorAll('[role="menuitem"]');
            for (const item of menuitems) {
              const text = item.textContent?.trim().toLowerCase();
              const href = item.getAttribute('href') || '';
              if (text === 'connect' || href.includes('custom-invite')) {
                connectBtn = item;
                break;
              }
            }
          }

          // Fallback: old dropdown structure
          if (!connectBtn) {
            const dropdownItems = document.querySelectorAll('.artdeco-dropdown__item, [role="button"], a[href*="custom-invite"]');
            for (const item of dropdownItems) {
              const label = item.getAttribute('aria-label')?.toLowerCase() || '';
              const text = item.textContent?.trim().toLowerCase();
              const href = item.getAttribute('href') || '';
              if (label.includes('connect') || text === 'connect' || href.includes('custom-invite')) {
                connectBtn = item;
                break;
              }
            }
          }
        }
      }

      if (!connectBtn) {
        throw new Error('Connect button not found in primary area or More dropdown. Make sure you are on a LinkedIn profile page.');
      }

      connectBtn.click();
      await sleep(1000); // Wait longer for modal to open

      // Step 2: Wait for invite modal (look for "Add note" button which is specific to invite modal)
      // LinkedIn changed "Add a note" to "Add note"
      const addNoteBtn = await waitForElement('button[aria-label="Add note"], button[aria-label="Add a note"], [role="button"][aria-label="Add note"], [role="button"][aria-label="Add a note"]');
      addNoteBtn.click();
      await sleep(ACTION_DELAY);

      // Step 3: Find the message textarea and type the message
      const textarea = await waitForElement('textarea#custom-message, textarea.connect-button-send-invite__custom-message, textarea[name="message"], .artdeco-modal textarea');

      if (inviteMessage && inviteMessage.trim()) {
        await humanType(textarea, inviteMessage);
        await sleep(ACTION_DELAY);
      }

      // DO NOT auto-send - let user review and click Send manually
      return { success: true, message: 'Message typed! Click Send manually to complete.' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // Expose the function for the extension to call
  window.__linkedInAutoConnect = autoConnect;

  // If called with a message parameter, execute immediately
  if (window.__linkedInAutoConnectMessage !== undefined) {
    autoConnect(window.__linkedInAutoConnectMessage).then(result => {
      window.__linkedInAutoConnectResult = result;
    });
  }
})();
