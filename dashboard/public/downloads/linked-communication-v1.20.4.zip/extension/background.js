'use strict';

const LOG_PREFIX = '[Linked Communication][Background]';

if (typeof globalThis.window === 'undefined') {
  globalThis.window = globalThis;
}

importScripts(
  'lib/memoryDefaults.js',
  'lib/ConnectionStore.js',
  'lib/InvitationStore.js',
  'lib/LongTermMemory.js',
  'lib/ConnectionScraper.js',
  'lib/InvitationScraper.js',
  'services/XanoClient.js',
  'services/ConnectionsDriver.js',
  'services/InvitationsDriver.js'
);

const log = (...args) => {
  const timestamp = new Date().toISOString().replace('T', ' ').slice(0, 23);
  console.log(`${LOG_PREFIX} [${timestamp}]`, ...args);
};

// Store current messaging contact for sidepanel queries
let currentMessagingContact = null;

const sleep = (ms) =>
  new Promise((resolve) => {
    setTimeout(resolve, Math.max(0, Number(ms) || 0));
  });

const AUTO_CONNECTIONS_ALARM = 'auto-connections-extract';
const AUTO_INVITATIONS_ALARM = 'auto-invitations-extract';
const DEFAULT_PERIOD_MINUTES = 60;
const DEFAULT_INITIAL_DELAY_MINUTES = 1;
const DEFAULT_COOLDOWN_MINUTES = 30;
const STORAGE_KEYS = {
  connections: {
    lastAutoExtractAt: 'lastAutoConnectionsExtractAt',
    lastManualExtractAt: 'lastManualConnectionsExtractAt',
    nextAutoExtractAt: 'nextAutoConnectionsExtractAt',
    extractInProgress: 'connectionsExtractInProgress',
    extractInProgressSince: 'connectionsExtractInProgressSince',
  },
  invitations: {
    lastAutoExtractAt: 'lastAutoInvitationsExtractAt',
    lastManualExtractAt: 'lastManualInvitationsExtractAt',
    nextAutoExtractAt: 'nextAutoInvitationsExtractAt',
    extractInProgress: 'invitationsExtractInProgress',
    extractInProgressSince: 'invitationsExtractInProgressSince',
  },
};

const AUTO_CONNECTIONS_CONFIG = (() => {
  try {
    const manifest = chrome.runtime.getManifest();
    const raw = manifest?.linkedCommunication?.autoExtract ?? {};
    const toMinutes = (value, fallback) => {
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        return fallback;
      }
      return Math.max(1, Math.round(value));
    };

    return {
      periodMinutes: toMinutes(raw.periodMinutes, DEFAULT_PERIOD_MINUTES),
      initialDelayMinutes: toMinutes(raw.initialDelayMinutes, DEFAULT_INITIAL_DELAY_MINUTES),
      cooldownMinutes: toMinutes(raw.cooldownMinutes, DEFAULT_COOLDOWN_MINUTES),
    };
  } catch (error) {
    log('Failed to read auto connections config from manifest.', error);
    return {
      periodMinutes: DEFAULT_PERIOD_MINUTES,
      initialDelayMinutes: DEFAULT_INITIAL_DELAY_MINUTES,
      cooldownMinutes: DEFAULT_COOLDOWN_MINUTES,
    };
  }
})();

const AUTO_INVITATIONS_CONFIG = (() => {
  try {
    const manifest = chrome.runtime.getManifest();
    const raw = manifest?.linkedCommunication?.autoInvitations ?? {};
    const toMinutes = (value, fallback) => {
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        return fallback;
      }
      return Math.max(1, Math.round(value));
    };

    return {
      periodMinutes: toMinutes(raw.periodMinutes, 30),
      initialDelayMinutes: toMinutes(raw.initialDelayMinutes, 2),
      cooldownMinutes: toMinutes(raw.cooldownMinutes, 23),
    };
  } catch (error) {
    log('Failed to read auto invitations config from manifest.', error);
    return {
      periodMinutes: 30,
      initialDelayMinutes: 2,
      cooldownMinutes: 23,
    };
  }
})();

log('Service worker loaded.');

// Configure side panel to open on action icon click
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .then(() => log('Side panel behavior configured.'))
  .catch((error) => log('Side panel config failed:', error));

async function ensureAutoAlarmsOnLoad() {
  try {
    const [connectionsAlarm, invitationsAlarm] = await Promise.all([
      chrome.alarms.get(AUTO_CONNECTIONS_ALARM),
      chrome.alarms.get(AUTO_INVITATIONS_ALARM),
    ]);

    if (!connectionsAlarm) {
      await ensureAutoConnectionsAlarm();
    } else {
      await updateNextAutoConnectionsExtract(connectionsAlarm?.scheduledTime ?? null);
    }

    if (!invitationsAlarm) {
      await ensureAutoInvitationsAlarm();
    } else {
      await updateNextAutoInvitationsExtract(invitationsAlarm?.scheduledTime ?? null);
    }

    log('Auto alarms verified on service worker load.');
  } catch (error) {
    log('Failed to verify auto alarms on load.', error);
  }
}

// Auto-alarms disabled - extension now operates in manual-only mode
// ensureAutoAlarmsOnLoad();

self.addEventListener('install', (event) => {
  log('Install event received.');
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  log('Activate event received.');
  event.waitUntil((async () => {
    await self.clients.claim();
    await clearStaleExtractFlags();
    await startTaskPollingAlarm();
    // Auto-alarms disabled - manual mode only
    // await ensureAutoConnectionsAlarm();
    // await ensureAutoInvitationsAlarm();
  })());
});

chrome.runtime.onStartup.addListener(() => {
  log('Runtime startup event fired.');
  startTaskPollingAlarm();
  pollTasksInBackground();
  // Auto-alarms disabled - manual mode only
  // ensureAutoConnectionsAlarm();
  // ensureAutoInvitationsAlarm();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) {
    return false;
  }

  if (message.type === 'update-auto-extract-alarms') {
    handleAlarmUpdate(message.payload)
      .then(() => {
        log('Alarms updated successfully.');
        sendResponse({ ok: true });
      })
      .catch((error) => {
        log('Failed to update alarms:', error);
        sendResponse({ ok: false, error: String(error) });
      });
    return true;
  }

  if (message.type === 'content-log') {
    const level = typeof message.payload?.level === 'string' ? message.payload.level : 'log';
    const prefix = message.payload?.prefix ?? LOG_PREFIX;
    const args = Array.isArray(message.payload?.args) ? message.payload.args : [];
    const logger = typeof console[level] === 'function' ? console[level] : console.log;
    logger(`${LOG_PREFIX}[Content]`, prefix, ...args);
    return false;
  }

  if (message.type === 'report-error') {
    // Forward error reports to Xano API
    (async () => {
      try {
        const errorData = {
          timestamp: new Date().toISOString(),
          ...message.payload
        };

        const payload = {
          key: 'COMMUNICATION_EXTENSION',
          value: JSON.stringify(errorData)
        };

        const response = await fetch('https://xano.atlanticsoft.co/api:dyRCgH5i/system_errors', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiemlwIjoiREVGIn0.mdbO16vY9huEA_UxNqCxxIVqUKinlqOqPwQv0hQHk728OL33W-i5r-BdXgBz1un_fYdiSq-IxR7PjE1g35NzepY-QXgIFkY5.y8COi4wlwldYcljWV-z7uw.M7eEei6IGYI1BnI_OR-cWQeCjLjWEuyTR3YYkfu9vF9X730EgKIU7yGJA2cb7rO2l4kAmgvvR5jTh2aXW6YUAQi_kdq4TpVcTE4kXxnq71tssFVhdSdKSBJqePmVCniQl3WdWWMUjqgc7xAEtacJ2A.xQpof9yrRQSqLz_SDlO1hPRL9LcxZJNNq1OJpKp3oPw'
          },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          log('Error reported to Xano API successfully');
          sendResponse({ ok: true });
        } else {
          log('Failed to report error to Xano API:', response.status, response.statusText);
          sendResponse({ ok: false, error: `HTTP ${response.status}` });
        }
      } catch (err) {
        log('Failed to report error to Xano API:', err);
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true; // Will respond asynchronously
  }

  if (message.type === 'background-ping') {
    log('Received ping from', sender?.id ?? 'unknown sender', message.payload ?? null);
    sendResponse({ ok: true, timestamp: Date.now() });
    return true;
  }

  if (message.type === 'popup-log') {
    const level = typeof message.payload?.level === 'string' ? message.payload.level : 'log';
    const args = Array.isArray(message.payload?.args) ? message.payload.args : [];
    const logger = typeof console[level] === 'function' ? console[level] : console.log;
    logger(`${LOG_PREFIX}[Popup]`, ...args);

    broadcastToClients({
      type: 'popup-log-broadcast',
      payload: {
        level,
      },
    });
    return false;
  }

  // Handle background saving of connections (continues even if popup closes)
  if (message.type === 'save-connections-to-xano') {
    const records = message.payload?.records ?? [];
    log(`Received ${records.length} connections to save to Xano in background.`);
    
    saveRecordsToXanoInBackground('connections', records)
      .then(result => {
        log('Background connection save completed:', result);
        // Broadcast completion to any open popups
        broadcastToClients({
          type: 'xano-save-complete',
          payload: { recordType: 'connections', ...result }
        });
      })
      .catch(error => {
        log('Background connection save failed:', error);
      });
    
    sendResponse({ ok: true, message: 'Saving in background' });
    return true;
  }

  // Handle background saving of invitations (continues even if popup closes)
  if (message.type === 'save-invitations-to-xano') {
    const records = message.payload?.records ?? [];
    const userId = message.payload?.userId;
    log(`Received ${records.length} invitations to save to Xano in background.`);
    
    saveRecordsToXanoInBackground('invitations', records, { userId })
      .then(result => {
        log('Background invitation save completed:', result);
        // Broadcast completion to any open popups
        broadcastToClients({
          type: 'xano-save-complete',
          payload: { recordType: 'invitations', ...result }
        });
      })
      .catch(error => {
        log('Background invitation save failed:', error);
      });
    
    sendResponse({ ok: true, message: 'Saving in background' });
    return true;
  }

  if (message.type === 'manual-extract-completed') {
    const timestamp = typeof message.payload?.timestamp === 'number' ? message.payload.timestamp : Date.now();
    const totalNewConnections = Number.isFinite(message.payload?.totalNewConnections)
      ? message.payload.totalNewConnections
      : 0;

    chrome.storage.local.set({
      [STORAGE_KEYS.lastManualExtractAt]: timestamp,
    });

    recordExtractInMemory(new Date(timestamp)).catch((error) => {
      log('Failed to record manual extract timestamp in long-term memory.', error);
    });

    announceExtractSummary({
      source: 'manual',
      timestamp,
      totalNewConnections,
    });
    return false;
  }

  if (message.type === 'request-next-auto-extract') {
    chrome.storage.local
      .get(STORAGE_KEYS.connections.nextAutoExtractAt)
      .then((result) => {
        sendResponse({
          ok: true,
          nextAutoExtractAt: result?.[STORAGE_KEYS.connections.nextAutoExtractAt] ?? null,
        });
      })
      .catch((error) => {
        log('Failed to fetch next auto extract timestamp for popup.', error);
        sendResponse({ ok: false, error: String(error) });
      });
    return true;
  }

  if (message.type === 'trigger-invitations-extract') {
    log('Received trigger-invitations-extract from content script. Starting InvitationsDriver...');
    handleInvitationsExtract()
      .then(() => {
        log('Invitations extract completed successfully.');
      })
      .catch((error) => {
        log('Invitations extract failed:', error);
      });
    return false;
  }

  if (message.type === 'update-task-badge') {
    const count = message.payload?.count;
    updateTaskBadge(count);
    return false;
  }

  if (message.type === 'messaging-thread-detected') {
    const payload = message.payload;
    log('Messaging thread detected:', payload?.contact?.name);
    // Store for sidepanel queries
    currentMessagingContact = payload;
    try {
      chrome.runtime.sendMessage({ type: 'messaging-contact-update', payload }).catch(() => {});
    } catch (e) {
      log('Failed to relay messaging-contact-update via runtime.sendMessage.', e);
    }
    try {
      broadcastToClients({ type: 'messaging-contact-update', payload });
    } catch (e) {
      log('Failed to broadcast messaging-contact-update to clients.', e);
    }
    return false;
  }

  if (message.type === 'messaging-thread-cleared') {
    log('Messaging thread cleared.');
    // Clear stored contact
    currentMessagingContact = null;
    try {
      chrome.runtime.sendMessage({ type: 'messaging-contact-cleared' }).catch(() => {});
    } catch (e) {
      log('Failed to relay messaging-contact-cleared via runtime.sendMessage.', e);
    }
    try {
      broadcastToClients({ type: 'messaging-contact-cleared' });
    } catch (e) {
      log('Failed to broadcast messaging-contact-cleared to clients.', e);
    }
    return false;
  }

  if (message.type === 'get-current-messaging-contact') {
    // Return stored contact to sidepanel
    sendResponse({ contact: currentMessagingContact?.contact || null, threadUrl: currentMessagingContact?.threadUrl || null });
    return true;
  }

  if (message.type === 'capture-chat') {
    (async () => {
      try {
        // First try to get the ACTIVE LinkedIn messaging tab
        let tabs = await chrome.tabs.query({
          url: ['https://www.linkedin.com/messaging/*', 'https://www.linkedin.com/talent/inbox/*'],
          active: true,
          currentWindow: true
        });

        // If no active LinkedIn tab, fall back to any LinkedIn messaging tab
        if (!tabs || tabs.length === 0) {
          tabs = await chrome.tabs.query({ url: ['https://www.linkedin.com/messaging/*', 'https://www.linkedin.com/talent/inbox/*'] });
        }

        if (!tabs || tabs.length === 0) {
          sendResponse({ ok: false, error: 'No LinkedIn messaging tab found. Please open a chat thread first.' });
          return;
        }

        const tab = tabs[0];

        // Try to send message to content script
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { type: 'capture-chat-request' });
          sendResponse(response);
        } catch (contentError) {
          log('Content script not responding, attempting to inject:', contentError.message);

          // Content script may not be loaded - try to inject it
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['extension/messaging-detector.js'],
            });

            // Wait a moment for the script to initialize
            await new Promise(r => setTimeout(r, 500));

            // Retry the message
            const response = await chrome.tabs.sendMessage(tab.id, { type: 'capture-chat-request' });
            sendResponse(response);
          } catch (injectError) {
            log('Failed to inject content script:', injectError.message);
            sendResponse({
              ok: false,
              error: 'Cannot connect to messaging tab. Please refresh the LinkedIn page and try again.',
            });
          }
        }
      } catch (error) {
        log('capture-chat handler failed:', error);
        sendResponse({ ok: false, error: 'Capture failed: ' + error.message });
      }
    })();
    return true;
  }

  return false;
});

// ---- Task Badge ----
function updateTaskBadge(count) {
  try {
    if (typeof count === 'number' && count > 0) {
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (error) {
    log('Failed to update task badge:', error);
  }
}

// ---- Background Task Polling (every 15 minutes) ----
const TASK_POLL_ALARM = 'task-poll-alarm';

async function startTaskPollingAlarm() {
  try {
    const existing = await chrome.alarms.get(TASK_POLL_ALARM);
    if (!existing) {
      await chrome.alarms.create(TASK_POLL_ALARM, {
        delayInMinutes: 15,
        periodInMinutes: 15,
      });
      log('Task polling alarm created (every 15 minutes).');
    }
  } catch (error) {
    log('Failed to create task polling alarm:', error);
  }
}

async function pollTasksInBackground() {
  try {
    const memoryModule = window.LinkedCommunicationLongTermMemory;
    if (!memoryModule?.LongTermMemory) return;

    const memory = new memoryModule.LongTermMemory();
    await memory.load();

    const token = memory.getAuthToken?.();
    const userId = memory.getUserId?.();
    if (!token || !userId) return;

    const xanoExports = window.LinkedCommunicationXanoClient;
    const XanoClient = xanoExports?.XanoClient;
    if (!XanoClient) return;

    const client = new XanoClient({});
    const response = await client.getTasks(token, {
      assigneeId: userId,
      status: 'pending',
      page: 1,
      perPage: 1,
    });

    const pendingCount = response?.pagination?.total ?? response?.itemsTotal ?? 0;
    updateTaskBadge(pendingCount);
    log('Background task poll completed. Pending tasks:', pendingCount);
  } catch (error) {
    log('Background task poll failed:', error);
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm) return;

  if (alarm.name === TASK_POLL_ALARM) {
    await pollTasksInBackground();
    return;
  }
});

// Auto-alarms disabled - manual mode only
// chrome.alarms.onAlarm.addListener(async (alarm) => {
//   if (!alarm) {
//     return;
//   }
//
//   if (alarm.name === AUTO_CONNECTIONS_ALARM) {
//     log('Auto connections extract alarm fired.', alarm);
//     try {
//       await handleAutoConnectionsExtractTrigger();
//     } catch (error) {
//       log('Auto connections extract trigger failed.', error);
//     }
//     return;
//   }
//
//   if (alarm.name === AUTO_INVITATIONS_ALARM) {
//     log('Auto invitations extract alarm fired.', alarm);
//     try {
//       await handleAutoInvitationsExtractTrigger();
//     } catch (error) {
//       log('Auto invitations extract trigger failed.', error);
//     }
//     return;
//   }
// });

async function clearStaleExtractFlags() {
  try {
    await chrome.storage.local.remove([
      STORAGE_KEYS.connections.extractInProgress,
      STORAGE_KEYS.connections.extractInProgressSince,
      STORAGE_KEYS.invitations.extractInProgress,
      STORAGE_KEYS.invitations.extractInProgressSince,
    ]);
    log('Cleared stale extract-in-progress flags on startup.');
  } catch (error) {
    log('Failed to clear stale extract flags.', error);
  }
}

function broadcastToClients(message) {
  clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
    clientList.forEach((client) => {
      client.postMessage(message);
    });
  }).catch((error) => {
    log('Failed to broadcast message to clients', error);
  });
}

async function getConnectionsTimingConfig() {
  try {
    const memoryModule = window.LinkedCommunicationLongTermMemory;
    if (!memoryModule?.LongTermMemory) {
      return AUTO_CONNECTIONS_CONFIG;
    }
    const memory = new memoryModule.LongTermMemory();
    await memory.load();
    const minutes = memory.getConnectionsAutoExtractMinutes?.();
    if (typeof minutes === 'number' && minutes >= 1) {
      return {
        periodMinutes: minutes,
        initialDelayMinutes: minutes,
        cooldownMinutes: minutes,
      };
    }
  } catch (error) {
    log('Failed to read connections timing from memory, using manifest default.', error);
  }
  return AUTO_CONNECTIONS_CONFIG;
}

async function getInvitationsTimingConfig() {
  try {
    const memoryModule = window.LinkedCommunicationLongTermMemory;
    if (!memoryModule?.LongTermMemory) {
      return AUTO_INVITATIONS_CONFIG;
    }
    const memory = new memoryModule.LongTermMemory();
    await memory.load();
    const minutes = memory.getInvitationsAutoExtractMinutes?.();
    if (typeof minutes === 'number' && minutes >= 1) {
      return {
        periodMinutes: minutes,
        initialDelayMinutes: minutes,
        cooldownMinutes: minutes,
      };
    }
  } catch (error) {
    log('Failed to read invitations timing from memory, using manifest default.', error);
  }
  return AUTO_INVITATIONS_CONFIG;
}

async function ensureAutoConnectionsAlarm() {
  try {
    const config = await getConnectionsTimingConfig();
    await chrome.alarms.create(AUTO_CONNECTIONS_ALARM, {
      delayInMinutes: config.initialDelayMinutes,
      periodInMinutes: config.periodMinutes,
    });

    const alarm = await chrome.alarms.get(AUTO_CONNECTIONS_ALARM);
    await updateNextAutoConnectionsExtract(alarm?.scheduledTime ?? null);
    log(
      'Auto connections extract alarm ensured.',
      {
        periodMinutes: config.periodMinutes,
        cooldownMinutes: config.cooldownMinutes,
        initialDelayMinutes: config.initialDelayMinutes,
      }
    );
  } catch (error) {
    log('Failed to ensure auto connections extract alarm.', error);
  }
}

async function ensureAutoInvitationsAlarm() {
  try {
    const config = await getInvitationsTimingConfig();
    await chrome.alarms.create(AUTO_INVITATIONS_ALARM, {
      delayInMinutes: config.initialDelayMinutes,
      periodInMinutes: config.periodMinutes,
    });

    const alarm = await chrome.alarms.get(AUTO_INVITATIONS_ALARM);
    await updateNextAutoInvitationsExtract(alarm?.scheduledTime ?? null);
    log(
      'Auto invitations extract alarm ensured.',
      {
        periodMinutes: config.periodMinutes,
        cooldownMinutes: config.cooldownMinutes,
        initialDelayMinutes: config.initialDelayMinutes,
      }
    );
  } catch (error) {
    log('Failed to ensure auto invitations extract alarm.', error);
  }
}

async function handleAlarmUpdate(payload) {
  const { connectionsMinutes, invitationsMinutes } = payload || {};
  
  if (typeof connectionsMinutes !== 'number' || connectionsMinutes < 1) {
    throw new Error('Invalid connections timing (minimum 1 minute)');
  }
  
  if (typeof invitationsMinutes !== 'number' || invitationsMinutes < 1) {
    throw new Error('Invalid invitations timing (minimum 1 minute)');
  }
  
  if (connectionsMinutes === invitationsMinutes) {
    throw new Error('Timings cannot be the same');
  }
  
  log('Recreating alarms with new timing...', { connectionsMinutes, invitationsMinutes });
  
  // Clear existing alarms
  await chrome.alarms.clear(AUTO_CONNECTIONS_ALARM);
  await chrome.alarms.clear(AUTO_INVITATIONS_ALARM);
  
  // Create connections alarm with payload values
  const connectionsConfig = {
    periodMinutes: connectionsMinutes,
    initialDelayMinutes: connectionsMinutes,
    cooldownMinutes: connectionsMinutes,
  };
  await chrome.alarms.create(AUTO_CONNECTIONS_ALARM, {
    delayInMinutes: connectionsConfig.initialDelayMinutes,
    periodInMinutes: connectionsConfig.periodMinutes,
  });
  const connectionsAlarm = await chrome.alarms.get(AUTO_CONNECTIONS_ALARM);
  await updateNextAutoConnectionsExtract(connectionsAlarm?.scheduledTime ?? null);
  log('Auto connections extract alarm created.', connectionsConfig);
  
  // Create invitations alarm with payload values
  const invitationsConfig = {
    periodMinutes: invitationsMinutes,
    initialDelayMinutes: invitationsMinutes,
    cooldownMinutes: invitationsMinutes,
  };
  await chrome.alarms.create(AUTO_INVITATIONS_ALARM, {
    delayInMinutes: invitationsConfig.initialDelayMinutes,
    periodInMinutes: invitationsConfig.periodMinutes,
  });
  const invitationsAlarm = await chrome.alarms.get(AUTO_INVITATIONS_ALARM);
  await updateNextAutoInvitationsExtract(invitationsAlarm?.scheduledTime ?? null);
  log('Auto invitations extract alarm created.', invitationsConfig);
  
  // Save to memory only after alarms are successfully created
  try {
    const memoryModule = window.LinkedCommunicationLongTermMemory;
    if (!memoryModule?.LongTermMemory) {
      log('LongTermMemory module not available, cannot save timing.');
      return;
    }
    
    const memory = new memoryModule.LongTermMemory();
    await memory.load();
    log('Memory loaded before save. Current values:', {
      connections: memory.getConnectionsAutoExtractMinutes?.(),
      invitations: memory.getInvitationsAutoExtractMinutes?.()
    });
    
    memory.setConnectionsAutoExtractMinutes?.(connectionsMinutes);
    memory.setInvitationsAutoExtractMinutes?.(invitationsMinutes);
    
    log('Set new values in memory:', {
      connections: memory.getConnectionsAutoExtractMinutes?.(),
      invitations: memory.getInvitationsAutoExtractMinutes?.()
    });
    
    await memory.save();
    log('Alarm timing saved to long-term memory. Verifying save...');
    
    // Verify save by reloading
    const verifyMemory = new memoryModule.LongTermMemory();
    await verifyMemory.load();
    log('Verification after save:', {
      connections: verifyMemory.getConnectionsAutoExtractMinutes?.(),
      invitations: verifyMemory.getInvitationsAutoExtractMinutes?.()
    });
  } catch (error) {
    log('Failed to save timing to memory (alarms still active):', error);
  }
  
  log('Alarms recreated successfully.');
}

async function updateNextAutoConnectionsExtract(timestamp) {
  try {
    await chrome.storage.local.set({
      [STORAGE_KEYS.connections.nextAutoExtractAt]: typeof timestamp === 'number' ? timestamp : null,
    });
  } catch (error) {
    log('Failed to update next auto connections extract timestamp.', error);
  }
}

async function updateNextAutoInvitationsExtract(timestamp) {
  try {
    await chrome.storage.local.set({
      [STORAGE_KEYS.invitations.nextAutoExtractAt]: typeof timestamp === 'number' ? timestamp : null,
    });
  } catch (error) {
    log('Failed to update next auto invitations extract timestamp.', error);
  }
}

async function refreshNextAutoConnectionsExtractCache() {
  try {
    const alarm = await chrome.alarms.get(AUTO_CONNECTIONS_ALARM);
    await updateNextAutoConnectionsExtract(alarm?.scheduledTime ?? null);
  } catch (error) {
    log('Failed to refresh next auto connections extract timestamp after manual run.', error);
  }
}

async function refreshNextAutoInvitationsExtractCache() {
  try {
    const alarm = await chrome.alarms.get(AUTO_INVITATIONS_ALARM);
    await updateNextAutoInvitationsExtract(alarm?.scheduledTime ?? null);
  } catch (error) {
    log('Failed to refresh next auto invitations extract timestamp after manual run.', error);
  }
}

async function handleAutoConnectionsExtractTrigger() {
  const now = Date.now();

  try {
    const stored = await chrome.storage.local.get([
      STORAGE_KEYS.connections.extractInProgress,
      STORAGE_KEYS.connections.extractInProgressSince,
      STORAGE_KEYS.connections.lastAutoExtractAt,
      STORAGE_KEYS.connections.lastManualExtractAt,
    ]);

    const periodMs = AUTO_CONNECTIONS_CONFIG.periodMinutes * 60 * 1000;
    const cooldownMs = AUTO_CONNECTIONS_CONFIG.cooldownMinutes * 60 * 1000;

    if (stored?.[STORAGE_KEYS.connections.extractInProgress]) {
      const since = stored?.[STORAGE_KEYS.connections.extractInProgressSince] ?? 0;
      const staleThresholdMs = Math.max(periodMs * 2, 5 * 60 * 1000);

      if (!since || now - since > staleThresholdMs) {
        log('Stale connections extract-in-progress flag detected. Resetting.');
        await chrome.storage.local.set({
          [STORAGE_KEYS.connections.extractInProgress]: false,
          [STORAGE_KEYS.connections.extractInProgressSince]: null,
        });
        stored[STORAGE_KEYS.connections.extractInProgress] = false;
        stored[STORAGE_KEYS.connections.extractInProgressSince] = null;
      } else {
        log('Auto connections extract skipped; another extract is in progress.');
        return;
      }
    }

    const lastAuto = stored?.[STORAGE_KEYS.connections.lastAutoExtractAt] ?? 0;
    const lastManual = stored?.[STORAGE_KEYS.connections.lastManualExtractAt] ?? 0;
    const lastRun = Math.max(lastAuto, lastManual);

    if (lastRun && now - lastRun < cooldownMs) {
      log('Auto connections extract skipped; cooldown not reached.', {
        lastRun,
        now,
        cooldownMs,
      });
      return;
    }

    await chrome.storage.local.set({
      [STORAGE_KEYS.connections.extractInProgress]: true,
      [STORAGE_KEYS.connections.extractInProgressSince]: now,
    });

    try {
      await performBackgroundExtract();
      await chrome.storage.local.set({ [STORAGE_KEYS.connections.lastAutoExtractAt]: Date.now() });
    } finally {
      await chrome.storage.local.set({
        [STORAGE_KEYS.connections.extractInProgress]: false,
        [STORAGE_KEYS.connections.extractInProgressSince]: null,
      });
    }
  } catch (error) {
    log('Auto connections extract handling failed.', error);
    await chrome.storage.local.set({
      [STORAGE_KEYS.connections.extractInProgress]: false,
      [STORAGE_KEYS.connections.extractInProgressSince]: null,
    });
  } finally {
    refreshNextAutoConnectionsExtractCache();
  }
}

async function performBackgroundExtract() {
  log('Scheduling background connection extract.');

  const driverModule = window.LinkedCommunicationConnectionsDriver;
  const DriverClass = driverModule?.ConnectionsDriver;

  if (!DriverClass) {
    log('ConnectionsDriver unavailable; cannot perform auto extract.');
    return;
  }

  const driver = new DriverClass({});

  try {
    const records = await driver.runManualExtract();
    const totalNew = Array.isArray(records) ? records.length : 0;
    const completionTimestamp = new Date();
    log('Auto extract completed.', {
      total: totalNew,
    });

    if (totalNew > 0) {
      await saveConnectionsToXanoSequentially(records);
    }

    await Promise.all([
      chrome.storage.local.set({ [STORAGE_KEYS.connections.lastAutoExtractAt]: completionTimestamp.getTime() }),
      recordExtractInMemory(completionTimestamp),
    ]);

    announceExtractSummary({
      source: 'auto',
      timestamp: completionTimestamp.getTime(),
      totalNewConnections: totalNew,
    });
  } catch (error) {
    log('Auto extract failed.', error);
  } finally {
    refreshNextAutoConnectionsExtractCache();
  }
}

function announceExtractSummary({ source, timestamp, totalNewConnections }) {
  const payload = {
    source,
    timestamp,
    totalNewConnections,
  };

  try {
    chrome.runtime.sendMessage({ type: 'connections-extract-summary', payload }).catch(() => {});
  } catch (error) {
    log('Failed to send extract summary via runtime.sendMessage.', error);
  }

  try {
    broadcastToClients({ type: 'connections-extract-summary', payload });
  } catch (error) {
    log('Failed to broadcast extract summary to clients.', error);
  }
}

async function saveConnectionsToXanoSequentially(records, { delayMs = 1000 } = {}) {
  const xanoExports = window.LinkedCommunicationXanoClient;
  const XanoClient = xanoExports?.XanoClient;

  if (!XanoClient) {
    log('Xano client unavailable; skipping automatic save.');
    return;
  }

  const sanitizedRecords = Array.isArray(records)
    ? records.filter((record) => record && typeof record === 'object')
    : [];

  if (sanitizedRecords.length === 0) {
    log('No connections to send to Xano after sanitization.');
    return;
  }

  log('Saving connections to Xano sequentially.', { total: sanitizedRecords.length });

  const client = new XanoClient();

  for (let index = 0; index < sanitizedRecords.length; index += 1) {
    const record = sanitizedRecords[index];

    try {
      // eslint-disable-next-line no-await-in-loop
      await client.createConnection(record);
      log('Xano save succeeded for connection.', {
        slug: record.Connection_Profile_URL ?? record.linkedin_profile ?? null,
      });
    } catch (error) {
      log('Failed to save connection to Xano.', error);
    }

    if (index < sanitizedRecords.length - 1) {
      // eslint-disable-next-line no-await-in-loop
      await sleep(delayMs);
    }
  }
}

// Background batch saving - continues even if popup closes
async function saveRecordsToXanoInBackground(recordType, records, { userId, batchSize = 5 } = {}) {
  const xanoExports = window.LinkedCommunicationXanoClient;
  const XanoClient = xanoExports?.XanoClient;

  if (!XanoClient) {
    log('Xano client unavailable for background save.');
    return { savedCount: 0, failedCount: 0, error: 'No Xano client' };
  }

  const sanitizedRecords = Array.isArray(records)
    ? records.filter((record) => record && typeof record === 'object')
    : [];

  if (sanitizedRecords.length === 0) {
    return { savedCount: 0, failedCount: 0 };
  }

  const client = new XanoClient();
  let savedCount = 0;
  let failedCount = 0;
  const total = sanitizedRecords.length;

  log(`Background save starting: ${total} ${recordType} in batches of ${batchSize}`);

  // Broadcast progress
  const sendProgress = (current, total, saved, failed) => {
    broadcastToClients({
      type: 'xano-save-progress',
      payload: { recordType, current, total, savedCount: saved, failedCount: failed }
    });
  };

  // Process in batches
  for (let i = 0; i < total; i += batchSize) {
    const batch = sanitizedRecords.slice(i, i + batchSize);
    const batchEnd = Math.min(i + batchSize, total);

    sendProgress(i + 1, total, savedCount, failedCount);

    // Run batch in parallel
    const results = await Promise.allSettled(
      batch.map(record => {
        if (recordType === 'invitations') {
          // Add userId if provided
          const recordWithUser = userId ? { ...record, user_id: userId } : record;
          return client.createInvitation(recordWithUser);
        } else {
          return client.createConnection(record);
        }
      })
    );

    results.forEach((result, idx) => {
      if (result.status === 'fulfilled') {
        savedCount++;
      } else {
        failedCount++;
        log(`Failed to save ${recordType}:`, result.reason);
      }
    });

    log(`Background save progress: ${batchEnd}/${total} processed, ${savedCount} saved, ${failedCount} failed`);
  }

  sendProgress(total, total, savedCount, failedCount);
  
  return { savedCount, failedCount, total };
}

async function recordExtractInMemory(timestamp) {
  try {
    const memoryModule = window.LinkedCommunicationLongTermMemory;
    const MemoryClass = memoryModule?.LongTermMemory;
    if (!MemoryClass) {
      log('LongTermMemory module unavailable; skipping extract timestamp persistence.');
      return;
    }

    const memory = new MemoryClass();
    await memory.load();
    memory.setLastImportConnectionDate?.(timestamp);
    await memory.save();
    log('Recorded extract timestamp in long-term memory.');
  } catch (error) {
    log('Failed to record extract timestamp in long-term memory.', error);
  }
}

async function handleInvitationsExtract() {
  const driverModule = window.LinkedCommunicationInvitationsDriver;
  if (!driverModule?.InvitationsDriver) {
    log('InvitationsDriver module not available.');
    return;
  }

  log('Creating InvitationsDriver instance...');
  const driver = new driverModule.InvitationsDriver();
  
  log('Starting manual invitations extract...');
  const records = await driver.runManualExtract();
  
  log(`Invitations extract completed. Extracted ${records?.length ?? 0} invitations.`);
  
  return records;
}

async function handleAutoInvitationsExtractTrigger() {
  const now = Date.now();

  try {
    const stored = await chrome.storage.local.get([
      STORAGE_KEYS.invitations.extractInProgress,
      STORAGE_KEYS.invitations.extractInProgressSince,
      STORAGE_KEYS.invitations.lastAutoExtractAt,
      STORAGE_KEYS.invitations.lastManualExtractAt,
    ]);

    const periodMs = AUTO_INVITATIONS_CONFIG.periodMinutes * 60 * 1000;
    const cooldownMs = AUTO_INVITATIONS_CONFIG.cooldownMinutes * 60 * 1000;

    if (stored?.[STORAGE_KEYS.invitations.extractInProgress]) {
      const since = stored?.[STORAGE_KEYS.invitations.extractInProgressSince] ?? 0;
      const staleThresholdMs = Math.max(periodMs * 2, 5 * 60 * 1000);

      if (!since || now - since > staleThresholdMs) {
        log('Stale invitations extract-in-progress flag detected. Resetting.');
        await chrome.storage.local.set({
          [STORAGE_KEYS.invitations.extractInProgress]: false,
          [STORAGE_KEYS.invitations.extractInProgressSince]: null,
        });
        stored[STORAGE_KEYS.invitations.extractInProgress] = false;
        stored[STORAGE_KEYS.invitations.extractInProgressSince] = null;
      } else {
        log('Auto invitations extract skipped; another extract is in progress.');
        return;
      }
    }

    const lastAuto = stored?.[STORAGE_KEYS.invitations.lastAutoExtractAt] ?? 0;
    const lastManual = stored?.[STORAGE_KEYS.invitations.lastManualExtractAt] ?? 0;
    const lastRun = Math.max(lastAuto, lastManual);

    if (lastRun && now - lastRun < cooldownMs) {
      log('Auto invitations extract skipped; cooldown not reached.', {
        lastRun,
        now,
        cooldownMs,
      });
      return;
    }

    await chrome.storage.local.set({
      [STORAGE_KEYS.invitations.extractInProgress]: true,
      [STORAGE_KEYS.invitations.extractInProgressSince]: now,
    });

    try {
      log('Starting auto invitations extract...');
      const records = await handleInvitationsExtract();
      await chrome.storage.local.set({ [STORAGE_KEYS.invitations.lastAutoExtractAt]: Date.now() });
      log(`Auto invitations extract completed. Extracted ${records?.length ?? 0} invitations.`);
    } finally {
      await chrome.storage.local.set({
        [STORAGE_KEYS.invitations.extractInProgress]: false,
        [STORAGE_KEYS.invitations.extractInProgressSince]: null,
      });
    }
  } catch (error) {
    log('Auto invitations extract handling failed.', error);
    await chrome.storage.local.set({
      [STORAGE_KEYS.invitations.extractInProgress]: false,
      [STORAGE_KEYS.invitations.extractInProgressSince]: null,
    });
  } finally {
    refreshNextAutoInvitationsExtractCache();
  }
}
