'use strict';


(function initializeInvitationsDriver() {
  const LOG_PREFIX = '[Linked Communication][InvitationsDriver]';
  const SCROLL_DELAY_MS = 2000; // Increased default delay to 2 seconds
  const SCROLL_MAX_ITERATIONS = 100; // Increased max iterations
  const SCROLL_RETRY_ATTEMPTS = 3; // Number of retry attempts for failed scrolls
  const SCROLL_CONTAINER_SELECTORS = [
    '.scaffold-finite-scroll__content',
    '.scaffold-finite-scroll__content-vertical',
    '.artdeco-entity-lockup__content',
    '.scaffold-layout__main',
    '#main',
    '#workspace'
  ];
  const DOCUMENT_SCROLL_SELECTOR = '__document_scrolling_element__';
  const CAPTURE_GATE_KEY = 'LinkedCommunication::allowInvitationsCapture';
  const CAPTURE_GATE_TTL_MS = 2 * 60 * 1000;

  const { InvitationStore } = window.LinkedCommunicationInvitationStore ?? {};

  class InvitationsDriver {
  constructor({ opener, scraperFactory } = {}) {
    if (!InvitationStore) {
      throw new Error('InvitationStore not exposed on window.');
    }

    this.store = new InvitationStore();
    this.opener = opener ?? window?.chrome?.tabs?.create;
    this.scraperFactory = scraperFactory ?? (async (store) => {
      const moduleRef = window.LinkedCommunicationInvitationScraperModule;
      if (!moduleRef?.InvitationScraper) {
        throw new Error('InvitationScraper not exposed on window.');
      }

      return new moduleRef.InvitationScraper(store);
    });
    this.lastTabId = null;
  }

  async #resolveInvitationLimit() {
    const defaults = window.LinkedCommunicationMemoryDefaults;
    const fallback = Number.isFinite(defaults?.DEFAULT_MEMORY?.invitationLimit)
      ? defaults.DEFAULT_MEMORY.invitationLimit
      : 5;

    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        return fallback;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const limit = memory.getInvitationLimit?.();
      if (Number.isFinite(limit) && limit > 0) {
        return limit;
      }
    } catch (error) {
      console.warn('[Linked Communication] Failed to resolve invitation limit from memory, using fallback.', error);
    }

    return fallback;
  }

  async #getUserId() {
    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        console.warn(LOG_PREFIX, 'LongTermMemory module not available');
        return null;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const userId = memory.getUserId();
      
      if (!userId) {
        console.warn(LOG_PREFIX, 'No user_id found in LongTermMemory');
        return null;
      }

      return userId;
    } catch (error) {
      console.error(LOG_PREFIX, 'Failed to retrieve user_id from LongTermMemory:', error);
      return null;
    }
  }

  async #filterExistingInvitations(records) {
    if (!Array.isArray(records) || records.length === 0) {
      return Array.isArray(records) ? records : [];
    }

    const payload = records
      .map((record) => {
        const userId = typeof record.user_id === 'number' ? String(record.user_id) : String(record.user_id ?? '').trim();
        const slug = typeof record.Connection_Profile_URL === 'string' ? record.Connection_Profile_URL.trim() : '';

        if (!userId || !slug) {
          return null;
        }

        return {
          user_id: userId,
          linkedin_profile: slug,
        };
      })
      .filter(Boolean);

    if (payload.length === 0) {
      console.log(LOG_PREFIX, 'Invitation validation skipped; no payload generated.');
      return records;
    }

    console.log(LOG_PREFIX, `Validating ${payload.length} invitation(s) with Xano`);

    const xanoExports = window.LinkedCommunicationXanoClient;
    const XanoClient = xanoExports?.XanoClient;

    if (!XanoClient) {
      console.warn(LOG_PREFIX, 'Xano client unavailable; skipping duplicate validation.');
      return records;
    }

    const xanoClient = new XanoClient();

    try {
      const existing = await xanoClient.validateInvitations(payload);
      const existingArray = Array.isArray(existing)
        ? existing
        : Array.isArray(existing?.data)
          ? existing.data
          : [];

      if (existingArray.length === 0) {
        console.log(LOG_PREFIX, 'Xano reports 0 existing invitations.');
        return records;
      }

      console.log(LOG_PREFIX, `Xano reports ${existingArray.length} existing invitation(s).`);

      const existingSet = new Set();

      existingArray.forEach((item) => {
        const userId = typeof item.user_id === 'number' ? String(item.user_id) : String(item.user_id ?? '').trim();
        const encodedSlug = typeof item.Connection_Profile_URL === 'string' ? item.Connection_Profile_URL.trim() : '';
        const inputSlug = typeof item.Connection_Profile_URL_Input === 'string' ? item.Connection_Profile_URL_Input.trim() : '';

        if (userId && encodedSlug) {
          existingSet.add(`${userId}::${encodedSlug}`);
        }
        if (userId && inputSlug) {
          existingSet.add(`${userId}::${inputSlug}`);
        }
      });

      if (existingSet.size === 0) {
        return records;
      }

      const result = records.filter((record) => {
        const userId = typeof record.user_id === 'number'
          ? String(record.user_id)
          : String(record.user_id ?? '').trim();
        const slug = typeof record.Connection_Profile_URL === 'string'
          ? record.Connection_Profile_URL.trim()
          : '';

        if (!userId || !slug) {
          return true;
        }

        const fingerprint = `${userId}::${slug}`;
        return !existingSet.has(fingerprint);
      });

      const removedCount = records.length - result.length;
      if (removedCount > 0) {
        console.log(LOG_PREFIX, `Filtered out ${removedCount} duplicate invitation(s)`);
      }

      return result;
    } catch (error) {
      console.warn(LOG_PREFIX, 'Failed to validate existing invitations via Xano.', error);
      return records;
    }
  }

  async #saveInvitationsToXano(invitations) {
    if (!Array.isArray(invitations) || invitations.length === 0) {
      return;
    }

    const xanoModule = window.LinkedCommunicationXanoClient;
    if (!xanoModule?.XanoClient) {
      console.error(LOG_PREFIX, 'XanoClient not available, cannot save invitations');
      return;
    }

    const xanoClient = new xanoModule.XanoClient();
    const delayMs = 1000;

    console.log(LOG_PREFIX, `Saving ${invitations.length} invitations to Xano`);

    for (let i = 0; i < invitations.length; i++) {
      const inv = invitations[i];
      try {
        await xanoClient.createInvitation(inv);
        console.log(LOG_PREFIX, `Saved invitation ${i + 1}/${invitations.length}: ${inv.Connection_Profile_URL}`);
      } catch (error) {
        console.error(LOG_PREFIX, `Failed to save invitation ${inv.Connection_Profile_URL}:`, error);
      }

      if (i < invitations.length - 1) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }

  async #recordInvitationExtractTime() {
    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        console.warn(LOG_PREFIX, 'LongTermMemory module unavailable; skipping timestamp persistence.');
        return;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const timestamp = new Date();
      console.log(LOG_PREFIX, 'Setting invitation extract timestamp:', timestamp.toISOString());
      memory.setLastImportInvitationDate?.(timestamp);
      await memory.save();
      console.log(LOG_PREFIX, 'Recorded invitation extract timestamp in long-term memory.');
      
      // Verify it was saved
      await memory.load();
      const saved = memory.getLastImportInvitationDate?.();
      console.log(LOG_PREFIX, 'Verified saved timestamp:', saved);
    } catch (error) {
      console.warn(LOG_PREFIX, 'Failed to record invitation extract timestamp in long-term memory.', error);
    }
  }

  async #grantCaptureGate() {
    if (!chrome?.storage?.local?.set) {
      return;
    }

    const payload = {
      allow: true,
      issuedAt: Date.now(),
      expiresAt: Date.now() + CAPTURE_GATE_TTL_MS,
    };

    try {
      await chrome.storage.local.set({ [CAPTURE_GATE_KEY]: payload });
    } catch (error) {
      console.warn('[Linked Communication] Failed to set capture gate payload.', error);
    }
  }

  async #revokeCaptureGate() {
    if (!chrome?.storage?.local?.remove) {
      return;
    }

    try {
      await chrome.storage.local.remove(CAPTURE_GATE_KEY);
    } catch (error) {
      console.warn('[Linked Communication] Failed to revoke capture gate payload.', error);
    }
  }

  async runManualExtract() {
    // Manual mode: capture from current active tab without opening new tabs or scrolling
    // User must already be on the invitations page and have scrolled manually
    console.log(LOG_PREFIX, 'Manual extract requested (manual mode - no auto-scroll).');

    const targetTab = await this.#getCurrentInvitationsTab();
    
    if (!targetTab) {
      console.warn(LOG_PREFIX, 'Not on LinkedIn invitations page. Please navigate to https://www.linkedin.com/mynetwork/invitation-manager/sent/');
      return { error: 'not_on_invitations_page', records: [] };
    }

    const tabId = targetTab.id;
    console.log(LOG_PREFIX, 'Manual extract from current tab:', tabId);

    let records = [];

    try {
      this.#resetStore();

      // No scrolling - capture what's currently visible
      const html = (await this.captureWorkspaceHtml(tabId)) ?? '';

      if (!html) {
        console.warn(LOG_PREFIX, 'No workspace HTML captured. Returning empty results.');
        return { error: 'no_html_captured', records: [] };
      }

      console.log(LOG_PREFIX, `Workspace HTML length=${html.length}.`);
      console.log(LOG_PREFIX, 'Beginning HTML scrape via InvitationScraper.');

      const scraperCandidate = this.scraperFactory(this.store);
      const scraper = scraperCandidate instanceof Promise ? await scraperCandidate : scraperCandidate;
      console.log(LOG_PREFIX, 'Scraper instance resolved. Starting parse.');

      try {
        records = scraper.scrapeFromHtml(html);
        console.log(LOG_PREFIX, `scrapeFromHtml returned ${records?.length ?? 0} record(s).`);
      } catch (error) {
        console.warn(LOG_PREFIX, 'Failed to scrape invitations.', error);
        records = [];
      }

      if (!Array.isArray(records)) {
        records = [];
      }

      console.log(LOG_PREFIX, `Parsed ${records.length} invitation(s).`);
      if (records.length > 0) {
        const previewSlugs = records
          .slice(0, Math.min(3, records.length))
          .map((record) => record?.Connection_Profile_URL ?? 'unknown')
          .join(', ');
        console.log(LOG_PREFIX, `Parsed sample: ${previewSlugs}${records.length > 3 ? '…' : ''}`);
      }

      this.store.clear();
      this.store.addMany(records);
      const finalEntries = this.store.getAll();
      console.log(LOG_PREFIX, `Store now contains ${finalEntries.length} record(s).`);
      
      try {
        console.log(LOG_PREFIX, 'Store contents JSON:', JSON.stringify(finalEntries));
      } catch (error) {
        console.log(LOG_PREFIX, 'Store contents (fallback):', finalEntries);
      }
      
      this.store.display();

      // Return records - popup will handle Xano saving with progress feedback
      // NOTE: Timestamp is saved by the popup's click handler
    } catch (error) {
      console.error(LOG_PREFIX, 'Manual extract failed:', error);
      return { error: 'extract_failed', records: [] };
    }

    // Don't close the tab - user is browsing manually
    return records;
  }

  async #getCurrentInvitationsTab() {
    // Check if the current active tab is the LinkedIn invitations page
    const INVITATIONS_PATH = '/mynetwork/invitation-manager/sent';
    
    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!activeTab?.url) {
        console.log(LOG_PREFIX, 'No active tab URL found');
        return null;
      }

      console.log(LOG_PREFIX, 'Checking tab URL:', activeTab.url);
      
      // Check if URL is LinkedIn invitations page (with or without trailing slash)
      try {
        const url = new URL(activeTab.url);
        const isLinkedIn = url.hostname === 'www.linkedin.com' || url.hostname === 'linkedin.com';
        const isInvitationsPath = url.pathname.startsWith(INVITATIONS_PATH);
        
        if (isLinkedIn && isInvitationsPath) {
          console.log(LOG_PREFIX, 'Found invitations tab:', activeTab.id);
          return activeTab;
        }
      } catch (urlError) {
        console.warn(LOG_PREFIX, 'Failed to parse URL:', urlError);
      }

      console.log(LOG_PREFIX, 'Active tab is not the invitations page');
      return null;
    } catch (error) {
      console.error(LOG_PREFIX, 'Failed to get current tab:', error);
      return null;
    }
  }

  async openInvitationsPage() {
    if (typeof this.opener !== 'function') {
      console.warn(LOG_PREFIX, 'No opener available to create invitations tab.');
      return null;
    }

    const targetUrl = 'https://www.linkedin.com/mynetwork/invitation-manager/sent/';

    const tab = await new Promise((resolve) => {
      let settled = false;

      const finalize = (openedTab) => {
        if (settled) {
          return;
        }
        settled = true;
        resolve(openedTab ?? null);
      };

      try {
        const result = this.opener(
          {
            url: targetUrl,
            active: true,
          },
          (createdTab) => finalize(createdTab)
        );

        if (result && typeof result.then === 'function') {
          result
            .then((createdTab) => finalize(createdTab))
            .catch((error) => {
              console.error('Failed to create tab via promise', error);
              finalize(null);
            });
        } else if (this.opener.length < 2) {
          finalize(result ?? null);
        }
      } catch (error) {
        console.error(LOG_PREFIX, 'Error while opening invitations tab', error);
        finalize(null);
      }
    });

    if (tab?.id) {
      this.lastTabId = tab.id;
      console.log(LOG_PREFIX, 'New invitations tab created with id:', tab.id);
      return tab;
    }

    const [existingTab] = await chrome.tabs.query({ url: targetUrl });
    if (existingTab?.id) {
      this.lastTabId = existingTab.id;
      console.log(LOG_PREFIX, 'Using existing invitations tab with id:', existingTab.id);
      
      // Focus the existing tab
      try {
        if (existingTab.windowId != null) {
          await chrome.windows.update(existingTab.windowId, { focused: true });
        }
        await chrome.tabs.update(existingTab.id, { active: true });
        console.log(LOG_PREFIX, 'Focused existing invitations tab');
        
        // Give Chrome time to actually switch tabs
        await new Promise(resolve => setTimeout(resolve, 300));
      } catch (error) {
        console.warn(LOG_PREFIX, 'Failed to focus existing tab:', error);
      }
      
      return existingTab;
    }

    console.warn(LOG_PREFIX, 'Invitations tab could not be opened or located.');
    return null;
  }

  async waitForTabLoad(tabId, attempts = 20, delayMs = 500) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab?.status === 'complete') {
          console.log(LOG_PREFIX, 'Tab reported complete on attempt', attempt + 1);
          return tab;
        }
      } catch (error) {
        console.error(LOG_PREFIX, 'Failed to query tab status', error);
        break;
      }

      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }

    console.warn(LOG_PREFIX, 'Tab did not finish loading in time.');
    return null;
  }

  async captureWorkspaceHtml(tabId) {
    if (!chrome?.scripting?.executeScript) {
      console.warn(LOG_PREFIX, 'chrome.scripting.executeScript unavailable.');
      return null;
    }

    console.log(LOG_PREFIX, 'Capturing workspace HTML from tab:', tabId);

    try {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId },
        func: async () => {
          const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
          const timeoutMs = 5000; // Reduced timeout since user already scrolled
          const pollIntervalMs = 300;
          const deadline = Date.now() + timeoutMs;

          while (Date.now() < deadline) {
            const workspace = document.querySelector('#workspace');
            if (workspace) {
              // Check for invitation items
              const listItems = workspace.querySelectorAll('[role="listitem"]');
              console.log('[InvitationsDriver][Page] Found', listItems.length, 'list items');
              if (listItems.length > 0) {
                return workspace.outerHTML;
              }
            }

            await sleep(pollIntervalMs);
          }

          // Return whatever we have even if no invitations found
          const workspace = document.querySelector('#workspace');
          console.log('[InvitationsDriver][Page] Timeout - workspace exists:', !!workspace);
          return workspace?.outerHTML ?? null;
        },
        world: 'MAIN',
      });

      const result = injection?.result ?? null;
      console.log(LOG_PREFIX, 'Captured HTML length:', result?.length ?? 0);
      return result;
    } catch (error) {
      console.error(LOG_PREFIX, 'Failed to capture workspace HTML', error);
      return null;
    }
  }

  async #getScrollContainer(tabId) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [SCROLL_CONTAINER_SELECTORS, DOCUMENT_SCROLL_SELECTOR],
        func: (selectors, fallbackToken) => {
          const toDescriptor = (selector, element) => ({
            selector,
            height: element?.scrollHeight ?? 0,
            clientHeight: element?.clientHeight ?? 0,
            scrollTop: element?.scrollTop ?? 0,
          });

          if (Array.isArray(selectors)) {
            for (const selector of selectors) {
              try {
                const element = typeof selector === 'string' ? document.querySelector(selector) : null;
                if (element && element.scrollHeight > 0) {
                  return toDescriptor(selector, element);
                }
              } catch (error) {
                console.warn(`Failed to check selector: ${selector}`, error);
              }
            }
          }

          const fallback = document.scrollingElement || document.documentElement || document.body;
          if (fallback) {
            return toDescriptor(fallbackToken, fallback);
          }

          return null;
        },
      });

      return result?.result ?? null;
    } catch (error) {
      console.error(LOG_PREFIX, 'Error finding scroll container:', error);
      return null;
    }
  }

  async #scrollInvitationsList(tabId, { targetInvitations = 0, maxScrolls = 100, waitMs = SCROLL_DELAY_MS } = {}) {
    if (!chrome?.scripting?.executeScript) {
      console.warn(LOG_PREFIX, 'Unable to auto-scroll invitations list; scripting API unavailable.');
      return { success: false, reason: 'scripting_api_unavailable' };
    }

    try {
      console.log(LOG_PREFIX, 'Initiating auto-scroll of invitations list.');

      try {
        const currentTab = await chrome.tabs.get(tabId);
        if (currentTab?.windowId != null) {
          await chrome.windows.update(currentTab.windowId, { focused: true }).catch(() => {});
        }
        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
        console.log(LOG_PREFIX, 'Tab focused, waiting for page to be ready...');

        const maxAttempts = 20;
        let attempts = 0;
        let pageReady = false;

        while (attempts < maxAttempts && !pageReady) {
          const [checkResult] = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: () => {
              const scrollRoot =
                document.querySelector('#workspace .scaffold-finite-scroll__content') ||
                document.querySelector('#workspace .scaffold-finite-scroll__body') ||
                document.querySelector('#workspace') ||
                document.scrollingElement;
              const hasInvitations = document.querySelectorAll('[role="listitem"]').length > 0;
              return scrollRoot && hasInvitations;
            },
          });

          pageReady = checkResult?.result ?? false;

          if (!pageReady) {
            attempts += 1;
            await new Promise((resolve) => setTimeout(resolve, 500));
          }
        }

        if (pageReady) {
          console.log(LOG_PREFIX, `Page ready after ${attempts * 500}ms`);
        } else {
          console.warn(LOG_PREFIX, 'Page may not be fully ready, continuing anyway...');
        }
      } catch (error) {
        console.warn(LOG_PREFIX, 'Unable to focus tab or check page readiness, continuing anyway.', error);
      }

      const containerInfo = await this.#getScrollContainer(tabId);
      if (!containerInfo) {
        console.error(LOG_PREFIX, 'Could not find a suitable scroll container');
        return { success: false, reason: 'no_scroll_container' };
      }

      console.log(LOG_PREFIX, `Using scroll container: ${containerInfo.selector} (height: ${containerInfo.height}px)`);

      const [injection] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [{
          maxIterations: maxScrolls,
          waitDelay: waitMs,
          targetCount: targetInvitations,
          containerSelector: containerInfo.selector,
          scrollBehavior: 'smooth',
          scrollPercentage: 0.8,
          maxRetries: SCROLL_RETRY_ATTEMPTS,
          documentScrollSelector: DOCUMENT_SCROLL_SELECTOR,
        }],
        func: async (options) => {
          const {
            maxIterations,
            waitDelay,
            targetCount,
            containerSelector,
            scrollBehavior,
            scrollPercentage,
            maxRetries,
            documentScrollSelector,
          } = options;

          const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

          const resolveScrollRoot = () => {
            try {
              if (typeof containerSelector === 'string') {
                if (containerSelector === documentScrollSelector) {
                  return document.scrollingElement || document.documentElement || document.body;
                }
                return document.querySelector(containerSelector);
              }

              return containerSelector || document.scrollingElement || document.documentElement || document.body;
            } catch (error) {
              console.error('Error resolving scroll root:', error);
              return document.scrollingElement || document.documentElement || document.body || null;
            }
          };

          const normalizeInteger = (value, fallback = 0, min = 0) => {
            const numeric = Number.parseInt(value, 10);
            return Number.isFinite(numeric) && numeric >= min ? numeric : fallback;
          };

          const target = normalizeInteger(targetCount, 0);
          const maxSteps = normalizeInteger(maxIterations, 100, 1);
          const delay = normalizeInteger(waitDelay, 2000, 500);
          const retries = normalizeInteger(maxRetries, 3, 0);
          const scrollPct = Math.min(Math.max(0.1, Number.parseFloat(scrollPercentage) || 0.8), 1);

          const countInvitations = () => {
            try {
              const selectors = [
                () => document.querySelectorAll('[role="listitem"]'),
                () => document.querySelectorAll('.artdeco-list__item'),
                () => document.querySelectorAll('.invitation-card'),
              ];

              for (const getter of selectors) {
                try {
                  const elements = getter();
                  if (elements.length > 0) {
                    return elements.length;
                  }
                } catch (error) {
                  console.warn('Error counting invitations with selector:', getter.toString(), error);
                }
              }

              return 0;
            } catch (error) {
              console.error('Error in countInvitations:', error);
              return 0;
            }
          };

          let note = '';
          const history = [];
          const preExisting = countInvitations();
          if (target > 0 && preExisting >= target) {
            note = 'Target invitation count already present before scrolling.';
          }

          history.push({
            step: 0,
            invitations: preExisting,
            capturedAt: Date.now(),
            scrollPosition: null,
            scrollHeight: null,
            clientHeight: null,
          });

          let consecutiveNoChange = 0;
          const MAX_CONSECUTIVE_NO_CHANGE = 3;
          let lastInvitationCount = preExisting;

          for (let index = 0; index < maxSteps; index += 1) {
            const beforeScrollCount = countInvitations();
            if (target > 0 && beforeScrollCount >= target) {
              note = 'Target invitation count reached.';
              break;
            }

            let scrollSuccess = false;
            let retryCount = 0;

            while (retryCount <= retries && !scrollSuccess) {
              try {
                const scrollRoot = resolveScrollRoot();
                if (!scrollRoot) {
                  throw new Error('No scroll root found');
                }

                const scrollHeight = scrollRoot.scrollHeight ?? 0;
                const clientHeight = scrollRoot.clientHeight ?? 0;
                const currentPosition = scrollRoot.scrollTop ?? 0;
                const maxScroll = Math.max(0, scrollHeight - clientHeight);

                if (maxScroll - currentPosition < 100) {
                  note = 'Reached bottom of container.';
                  scrollSuccess = true;
                  break;
                }

                const scrollAmount = Math.max(
                  200,
                  Math.min(clientHeight * scrollPct, maxScroll - currentPosition),
                );

                const targetPosition = Math.min(currentPosition + scrollAmount, maxScroll);

                if (scrollBehavior === 'smooth' && typeof scrollRoot.scrollTo === 'function') {
                  scrollRoot.scrollTo({ top: targetPosition, behavior: 'smooth' });
                } else {
                  scrollRoot.scrollTop = targetPosition;
                }

                scrollSuccess = true;
              } catch (error) {
                console.error(`Scroll attempt ${retryCount + 1} failed:`, error);
                retryCount += 1;
                if (retryCount <= retries) {
                  await sleep(1000);
                }
              }
            }

            if (!scrollSuccess) {
              if (!note) {
                note = 'Failed to scroll after multiple attempts.';
              }
              break;
            }

            if (delay > 0) {
              await sleep(delay);
            }

            const afterScrollCount = countInvitations();
            const latestRoot = resolveScrollRoot();

            history.push({
              step: index + 1,
              invitations: afterScrollCount,
              capturedAt: Date.now(),
              scrollPosition: latestRoot?.scrollTop ?? null,
              scrollHeight: latestRoot?.scrollHeight ?? null,
              clientHeight: latestRoot?.clientHeight ?? null,
            });

            if (afterScrollCount <= lastInvitationCount) {
              consecutiveNoChange += 1;
              if (consecutiveNoChange >= MAX_CONSECUTIVE_NO_CHANGE) {
                if (!note) {
                  note = 'No new invitations loaded after several attempts.';
                }
                break;
              }
            } else {
              consecutiveNoChange = 0;
            }

            lastInvitationCount = afterScrollCount;

            if (note === 'Reached bottom of container.') {
              break;
            }
          }

          const finalRoot = resolveScrollRoot();
          const invitations = countInvitations();

          if (!note) {
            if (target > 0 && invitations >= target) {
              note = 'Reached target invitation count.';
            } else if (invitations > 0) {
              note = `Found ${invitations} invitations.`;
            } else {
              note = 'No invitations found.';
            }
          }

          const durationMs = history.length > 0 ? Date.now() - history[0].capturedAt : 0;
          const stats = {
            durationMs,
            invitationsPerMinute: 0,
            scrollsPerMinute: 0,
          };

          if (history.length > 1 && durationMs > 0) {
            const durationMinutes = durationMs / (60 * 1000);
            stats.invitationsPerMinute = Math.round(invitations / durationMinutes);
            stats.scrollsPerMinute = Math.round(history.length / durationMinutes);
          }

          const success = note !== 'Failed to scroll after multiple attempts.';

          return {
            success,
            steps: history.length,
            finalHeight: finalRoot?.scrollHeight ?? null,
            invitations,
            initialInvitations: preExisting,
            history,
            note,
            stats,
            container: {
              selector: typeof containerSelector === 'string' ? containerSelector : documentScrollSelector,
              height: finalRoot?.scrollHeight ?? null,
              clientHeight: finalRoot?.clientHeight ?? null,
              scrollTop: finalRoot?.scrollTop ?? null,
            },
          };
        },
      });

      const result = injection?.result ?? {};
      console.log(LOG_PREFIX, 'Scrolling completed:', {
        success: result.success,
        invitations: result.invitations,
        steps: result.steps,
        note: result.note,
        stats: result.stats,
      });

      if (!result.success) {
        console.warn(LOG_PREFIX, 'Scrolling did not complete successfully:', result.note);
      }

      return result;
    } catch (error) {
      console.warn(LOG_PREFIX, 'Failed to auto-scroll invitations list.', error);
      return { success: false, reason: 'execution_failed' };
    }
  }

  #resetStore() {
    try {
      const capacity = typeof this.store?.capacity === 'number' ? this.store.capacity : undefined;
      this.store = new InvitationStore({ capacity });
    } catch (error) {
      console.warn('Failed to reset invitation store; falling back to clear.', error);
      if (this.store?.clear) {
        this.store.clear();
      } else if (InvitationStore) {
        this.store = new InvitationStore();
      }
    }
  }

  async #closeInvitationsTab(tabId) {
    if (!tabId || !chrome?.tabs?.remove) {
      this.lastTabId = null;
      return;
    }

    try {
      await chrome.tabs.remove(tabId);
    } catch (error) {
      console.warn(LOG_PREFIX, 'Failed to close invitations tab.', error);
    } finally {
      if (this.lastTabId === tabId) {
        this.lastTabId = null;
      }
    }
  }
}

  window.LinkedCommunicationInvitationsDriver = {
    InvitationsDriver,
  };
})();
