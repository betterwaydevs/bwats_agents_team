'use strict';

(function initializeConnectionsDriver() {
  const SCROLL_DELAY_MS = 800;
  const SCROLL_MAX_ITERATIONS = 50;
  const CAPTURE_GATE_KEY = 'LinkedCommunication::allowConnectionsCapture';
  const CAPTURE_GATE_TTL_MS = 2 * 60 * 1000;

  const { ConnectionStore } = window.LinkedCommunicationConnectionStore ?? {};

  class ConnectionsDriver {
  constructor({ opener, scraperFactory } = {}) {
    if (!ConnectionStore) {
      throw new Error('ConnectionStore not exposed on window.');
    }

    this.store = new ConnectionStore();
    this.opener = opener ?? window?.chrome?.tabs?.create;
    this.scraperFactory = scraperFactory ?? (async (store) => {
      const moduleRef = window.LinkedCommunicationScraperModule;
      if (!moduleRef?.ConnectionScraper) {
        throw new Error('ConnectionScraper not exposed on window.');
      }

      let memoryInstance = null;
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (memoryModule?.LongTermMemory) {
        try {
          memoryInstance = new memoryModule.LongTermMemory();
          await memoryInstance.load();
        } catch (error) {
          console.warn('Failed to load long-term memory snapshot for scraper.', error);
          memoryInstance = null;
        }
      }

      return new moduleRef.ConnectionScraper(store, { memory: memoryInstance });
    });
    this.lastTabId = null;
  }

  async #resolveConnectionLimit() {
    const defaults = window.LinkedCommunicationMemoryDefaults;
    const fallback = Number.isFinite(defaults?.DEFAULT_MEMORY?.connectionLimit)
      ? defaults.DEFAULT_MEMORY.connectionLimit
      : 20;

    try {
      const memoryModule = window.LinkedCommunicationLongTermMemory;
      if (!memoryModule?.LongTermMemory) {
        return fallback;
      }

      const memory = new memoryModule.LongTermMemory();
      await memory.load();
      const limit = memory.getConnectionLimit?.();
      if (Number.isFinite(limit) && limit > 0) {
        return limit;
      }
    } catch (error) {
      console.warn('[Linked Communication] Failed to resolve connection limit from memory, using fallback.', error);
    }

    return fallback;
  }

  async #activateTab(tabId) {
    if (!tabId || !chrome?.tabs?.get) {
      return;
    }

    try {
      const tab = await chrome.tabs.get(tabId);
      if (!tab) {
        return;
      }

      if (tab?.windowId != null && chrome?.windows?.update) {
        await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
      }

      if (chrome?.tabs?.update) {
        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
      }
    } catch (error) {
      console.warn('[Linked Communication] Unable to focus connections tab before capture.', error);
    }
  }

  async #grantCaptureGate() {
    if (!chrome?.storage?.local?.set) {
      return;
    }

    const payload = {
      allow: true,
      issuedAt: Date.now(),
      expiresAt: Date.now() + CAPTURE_GATE_TTL_MS,
    };

    try {
      await chrome.storage.local.set({ [CAPTURE_GATE_KEY]: payload });
    } catch (error) {
      console.warn('[Linked Communication] Failed to set capture gate payload.', error);
    }
  }

  async #revokeCaptureGate() {
    if (!chrome?.storage?.local?.remove) {
      return;
    }

    try {
      await chrome.storage.local.remove(CAPTURE_GATE_KEY);
    } catch (error) {
      console.warn('[Linked Communication] Failed to revoke capture gate payload.', error);
    }
  }

  async runManualExtract() {
    // Manual mode: capture from current active tab without opening new tabs or scrolling
    // User must already be on the connections page and have scrolled manually
    
    const targetTab = await this.#getCurrentConnectionsTab();
    
    if (!targetTab) {
      console.warn('[Linked Communication] Not on LinkedIn connections page. Please navigate to https://www.linkedin.com/mynetwork/invite-connect/connections/');
      return { error: 'not_on_connections_page', records: [] };
    }

    const tabId = targetTab.id;
    console.log('[Linked Communication] Manual extract from current tab:', tabId);

    let filteredRecords = [];

    try {
      this.#resetStore();

      // No scrolling - capture what's currently visible
      const html = (await this.captureWorkspaceHtml(tabId)) ?? '';

      if (!html) {
        console.warn('No workspace HTML captured.');
        return { error: 'no_html_captured', records: [] };
      }

      console.log(`[Linked Communication] Workspace HTML length=${html.length}.`);
      console.log('[Linked Communication] Beginning HTML scrape via ConnectionScraper.');

      const scraperCandidate = this.scraperFactory(this.store);
      const scraper = scraperCandidate instanceof Promise ? await scraperCandidate : scraperCandidate;
      console.log('[Linked Communication] Scraper instance resolved. Starting parse.');

      let records = [];
      let parsedUsingFallback = false;
      try {
        records = scraper.scrapeFromHtml(html);
        console.log(`[Linked Communication] scrapeFromHtml returned ${records?.length ?? 0} record(s).`);
      } catch (error) {
        console.warn('[Linked Communication] Failed to scrape connections via DOMParser; attempting in-page fallback.', error);
        const ownerId = this.#resolveOwnerIdentifier(scraper);
        records = await this.#scrapeConnectionsInPage(tabId, ownerId ? { ownerId } : {});
        parsedUsingFallback = true;
        console.log(
          `[Linked Communication] Fallback in-page scrape produced ${records?.length ?? 0} record(s).`
        );
      }

      if (!Array.isArray(records)) {
        records = [];
      }

      console.log(
        `[Linked Communication] Parsed ${records.length} connection(s)${parsedUsingFallback ? ' via fallback' : ''}.`
      );
      if (records.length > 0) {
        const previewSlugs = records
          .slice(0, Math.min(3, records.length))
          .map((record) => record?.Connection_Profile_URL ?? 'unknown')
          .join(', ');
        console.log(`[Linked Communication] Parsed sample: ${previewSlugs}${records.length > 3 ? '…' : ''}`);
      }

      filteredRecords = await this.#filterExistingConnections(records);
      if (filteredRecords.length === 0 && records.length > 0) {
        console.warn('[Linked Communication] All parsed connections were filtered out (likely duplicates).');
      }
      if (filteredRecords.length > 0) {
        const filteredSlugs = filteredRecords
          .slice(0, Math.min(3, filteredRecords.length))
          .map((record) => record?.Connection_Profile_URL ?? 'unknown')
          .join(', ');
        console.log(
          `[Linked Communication] New connections sample: ${filteredSlugs}${filteredRecords.length > 3 ? '…' : ''}`
        );
      }
      console.log(`[Linked Communication] ${filteredRecords.length} new connection(s) after duplicate check.`);

      this.store.clear();
      this.store.addMany(filteredRecords);
      const finalEntries = this.store.getAll();
      console.log(
        `[Linked Communication] Store now contains ${finalEntries.length} record(s) prior to Xano validation.`
      );
      try {
        console.log('[Linked Communication] Store contents after update JSON:', JSON.stringify(finalEntries));
      } catch (error) {
        console.log('[Linked Communication] Store contents after update (fallback):', finalEntries);
      }
      this.store.display();
    } catch (error) {
      console.error('[Linked Communication] Manual extract failed:', error);
      return { error: 'extract_failed', records: [] };
    }

    // Don't close the tab - user is browsing manually
    return filteredRecords;
  }

  async #getCurrentConnectionsTab() {
    // Check if the current active tab is the LinkedIn connections page
    const CONNECTIONS_PATH = '/mynetwork/invite-connect/connections';
    
    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!activeTab?.url) {
        console.log('[Linked Communication] No active tab URL found');
        return null;
      }

      console.log('[Linked Communication] Checking tab URL:', activeTab.url);
      
      // Check if URL is LinkedIn connections page (with or without trailing slash)
      try {
        const url = new URL(activeTab.url);
        const isLinkedIn = url.hostname === 'www.linkedin.com' || url.hostname === 'linkedin.com';
        const isConnectionsPath = url.pathname.startsWith(CONNECTIONS_PATH);
        
        if (isLinkedIn && isConnectionsPath) {
          console.log('[Linked Communication] Found connections tab:', activeTab.id);
          return activeTab;
        }
      } catch (urlError) {
        console.warn('[Linked Communication] Failed to parse URL:', urlError);
      }

      console.log('[Linked Communication] Active tab is not the connections page');
      return null;
    } catch (error) {
      console.error('[Linked Communication] Failed to get current tab:', error);
      return null;
    }
  }

  async openConnectionsPage() {
    if (typeof this.opener !== 'function') {
      console.warn('No opener available to create connections tab.');
      return null;
    }

    const targetUrl = 'https://www.linkedin.com/mynetwork/invite-connect/connections/';

    const tab = await new Promise((resolve) => {
      let settled = false;

      const finalize = (openedTab) => {
        if (settled) {
          return;
        }
        settled = true;
        resolve(openedTab ?? null);
      };

      try {
        const result = this.opener(
          {
            url: targetUrl,
            active: false,
          },
          (createdTab) => finalize(createdTab)
        );

        if (result && typeof result.then === 'function') {
          result
            .then((createdTab) => finalize(createdTab))
            .catch((error) => {
              console.error('Failed to create tab via promise', error);
              finalize(null);
            });
        } else if (this.opener.length < 2) {
          // Some custom opener may return the tab synchronously without a callback.
          finalize(result ?? null);
        }
      } catch (error) {
        console.error('Error while opening connections tab', error);
        finalize(null);
      }
    });

    if (tab?.id) {
      this.lastTabId = tab.id;
      return tab;
    }

    const [existingTab] = await chrome.tabs.query({ url: targetUrl });
    if (existingTab?.id) {
      this.lastTabId = existingTab.id;
      console.log('Using existing connections tab with id:', existingTab.id);
      
      // Focus the existing tab
      try {
        if (existingTab.windowId != null) {
          await chrome.windows.update(existingTab.windowId, { focused: true });
        }
        await chrome.tabs.update(existingTab.id, { active: true });
        console.log('Focused existing connections tab');
        
        // Give Chrome time to actually switch tabs
        await new Promise(resolve => setTimeout(resolve, 300));
      } catch (error) {
        console.warn('Failed to focus existing connections tab:', error);
      }
      
      return existingTab;
    }

    console.warn('Connections tab could not be opened or located.');
    return null;
  }
  async waitForTabLoad(tabId, attempts = 20, delayMs = 500) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab?.status === 'complete') {
          return tab;
        }
      } catch (error) {
        console.error('Failed to query tab status', error);
        break;
      }

      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }

    console.warn('Tab did not finish loading in time.');
    return null;
  }

  async captureWorkspaceHtml(tabId) {
    if (!chrome?.scripting?.executeScript) {
      console.warn('[Linked Communication] chrome.scripting.executeScript unavailable.');
      return null;
    }

    console.log('[Linked Communication] Capturing workspace HTML from tab:', tabId);

    try {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId },
        func: async () => {
          const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
          const timeoutMs = 5000; // Reduced timeout since user already scrolled
          const pollIntervalMs = 300;
          const deadline = Date.now() + timeoutMs;

          while (Date.now() < deadline) {
            const workspace = document.querySelector('#workspace');
            if (workspace) {
              const connections = workspace.querySelectorAll('[data-view-name="message-button"]');
              console.log('[ConnectionsDriver][Page] Found', connections.length, 'connections');
              if (connections.length > 0) {
                return workspace.outerHTML;
              }
            }

            await sleep(pollIntervalMs);
          }

          // Return whatever we have even if no connections found
          const workspace = document.querySelector('#workspace');
          console.log('[ConnectionsDriver][Page] Timeout - workspace exists:', !!workspace);
          return workspace?.outerHTML ?? null;
        },
        world: 'MAIN',
      });

      const result = injection?.result ?? null;
      console.log('[Linked Communication] Captured HTML length:', result?.length ?? 0);
      return result;
    } catch (error) {
      console.error('[Linked Communication] Failed to capture workspace HTML', error);
      return null;
    }
  }

  async #scrollConnectionsList(tabId, { targetConnections = 0, maxScrolls = 200, waitMs = 800 } = {}) {
    if (!chrome?.scripting?.executeScript) {
      console.warn('[Linked Communication] Unable to auto-scroll connections list; scripting API unavailable.');
      return;
    }

    try {
      console.log('[Linked Communication] Initiating auto-scroll of connections list.');
      
      // Focus the tab right after starting the scroll script
      try {
        const currentTab = await chrome.tabs.get(tabId);
        if (currentTab?.windowId != null) {
          await chrome.windows.update(currentTab.windowId, { focused: true }).catch(() => {});
        }
        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
        console.log('[Linked Communication] Tab focused, waiting for page to be ready...');
        
        // Wait for the scroll root to be available (page is ready)
        const maxAttempts = 20;
        let attempts = 0;
        let pageReady = false;
        
        while (attempts < maxAttempts && !pageReady) {
          const [checkResult] = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: () => {
              const scrollRoot = document.querySelector('#workspace .scaffold-finite-scroll__content') ||
                                document.querySelector('#workspace .scaffold-finite-scroll__body') ||
                                document.querySelector('#workspace') ||
                                document.scrollingElement;
              const hasConnections = document.querySelectorAll('[data-view-name="connections-list"] [data-view-name="message-button"]').length > 0;
              return scrollRoot && hasConnections;
            }
          });
          
          pageReady = checkResult?.result ?? false;
          
          if (!pageReady) {
            attempts++;
            await new Promise((resolve) => setTimeout(resolve, 500));
          }
        }
        
        if (pageReady) {
          console.log(`[Linked Communication] Page ready after ${attempts * 500}ms`);
        } else {
          console.warn('[Linked Communication] Page may not be fully ready, continuing anyway...');
        }
      } catch (error) {
        console.warn('[Linked Communication] Unable to focus tab or check page readiness, continuing anyway.', error);
      }
      
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [maxScrolls, waitMs, targetConnections],
        func: async (maxIterations, waitDelay, targetCount) => {
          const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

          const resolveScrollRoot = () =>
            document.querySelector('#workspace .scaffold-finite-scroll__content') ||
            document.querySelector('#workspace .scaffold-finite-scroll__body') ||
            document.querySelector('#workspace') ||
            document.scrollingElement;

          const normalizeInteger = (value, fallback = 0) => {
            const numeric = Number.parseInt(value, 10);
            return Number.isFinite(numeric) && numeric >= 0 ? numeric : fallback;
          };

          const target = normalizeInteger(targetCount, 0);
          const maxSteps = normalizeInteger(maxIterations, 0);

          const countConnections = () => {
            const workspace = document.querySelector('#workspace');
            if (!workspace) {
              return 0;
            }

            return workspace.querySelectorAll(
              '[data-view-name="connections-list"] [data-view-name="message-button"]'
            ).length;
          };

          let note = '';
          let stepsTaken = 0;
          const history = [];
          const preExisting = countConnections();
          if (target > 0 && preExisting >= target) {
            note = 'Target connection count already present before scrolling.';
          }

          history.push({ step: 0, connections: preExisting, capturedAt: Date.now() });

          for (let index = 0; index < maxSteps && (target === 0 || countConnections() < target); index += 1) {
            const scrollRoot = resolveScrollRoot();
            if (!scrollRoot) {
              note = 'No scroll root found.';
              break;
            }

            const delta = Math.max(200, scrollRoot.clientHeight ?? 600);

            if (typeof scrollRoot.scrollBy === 'function') {
              scrollRoot.scrollBy({ top: delta, behavior: 'auto' });
            } else {
              scrollRoot.scrollTop = Math.min(
                (scrollRoot.scrollTop ?? 0) + delta,
                scrollRoot.scrollHeight ?? (scrollRoot.scrollTop ?? 0) + delta
              );
            }

            stepsTaken += 1;

            if (waitDelay > 0) {
              // eslint-disable-next-line no-await-in-loop
              await sleep(waitDelay);
            }

            history.push({ step: stepsTaken, connections: countConnections(), capturedAt: Date.now() });
          }

          const finalRoot = resolveScrollRoot();
          const connections = countConnections();
          if (!note && target > 0 && connections >= target) {
            note = 'Reached target connection count.';
          } else if (!note && maxSteps > 0 && stepsTaken >= maxSteps) {
            note = 'Reached max scroll iterations.';
          }

          return {
            steps: stepsTaken,
            finalHeight: finalRoot?.scrollHeight ?? null,
            connections,
            initialConnections: preExisting,
            history,
            note,
          };
        },
      });

      const meta = injection?.result ?? {};
    } catch (error) {
      console.warn('[Linked Communication] Failed to auto-scroll connections list.', error);
    }
  }

  #resolveOwnerIdentifier(scraperInstance) {
    const memory = scraperInstance?.memory;
    const idCandidate = typeof memory?.getUserId === 'function' ? memory.getUserId() : null;
    if (typeof idCandidate === 'string' && idCandidate.trim().length > 0) {
      return idCandidate.trim();
    }

    const username = typeof memory?.getUsername === 'function' ? memory.getUsername() : null;
    if (typeof username === 'string' && username.trim().length > 0) {
      return username.trim();
    }

    return null;
  }

  async #scrapeConnectionsInPage(tabId, { ownerId = null } = {}) {
    if (!chrome?.scripting?.executeScript) {
      console.warn('[Linked Communication] Unable to fall back to in-page scraping; scripting API unavailable.');
      return [];
    }

    try {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [ownerId],
        func: (owner) => {
          const toTrimmedText = (text) => (typeof text === 'string' ? text.trim() : '');

          const extractSlug = (reference) => {
            if (!reference) {
              return '';
            }

            let target = reference;
            try {
              const url = new URL(reference, 'https://www.linkedin.com');
              target = url.pathname;
            } catch (error) {
              // keep relative reference
            }

            const match = target.match(/\/in\/([^/?#]+)(?:\/|$)/i);
            return match ? decodeURIComponent(match[1]) : '';
          };

          const splitName = (fullName) => {
            const parts = (fullName || '')
              .split(' ')
              .map((part) => part.trim())
              .filter(Boolean);

            const count = parts.length;
            if (count === 0) {
              return { firstName: '', lastName: '' };
            }

            if (count === 1) {
              return { firstName: parts[0], lastName: '' };
            }

            if (count === 2) {
              return { firstName: parts[0], lastName: parts[1] };
            }

            if (count === 4) {
              const midpoint = count / 2;
              return {
                firstName: parts.slice(0, midpoint).join(' '),
                lastName: parts.slice(midpoint).join(' '),
              };
            }

            return {
              firstName: parts.slice(0, count - 1).join(' '),
              lastName: parts[count - 1],
            };
          };

          const stripHeadline = (text, position) => {
            if (!text || !position) {
              return text;
            }

            let result = text;

            // Remove the position string if it appears in the text
            if (result.includes(position)) {
              result = result.replace(position, '').trim();
            }

            // Remove newlines and everything after
            const newlineIndex = result.search(/[\r\n]/);
            if (newlineIndex >= 0) {
              result = result.slice(0, newlineIndex).trim();
            }

            // Remove everything after delimiter if found
            const delimiterMatch = result.match(/\s[|•·–—-]+\s/);
            if (delimiterMatch) {
              result = result.slice(0, delimiterMatch.index).trim();
            }

            // Remove trailing delimiters
            result = result.replace(/[|•·–—-]+$/g, '').trim();

            // If result contains job keywords, cut at first occurrence
            const keywordMatch = result.match(/\b(CEO|Founder|Officer|Consultant|Director|President|Manager|Engineer|Developer|Designer|Ambassador|Advisor|Coach|Strategist|Builder|Entrepreneur|Marketing|Growth|Product|Community)\b/i);
            if (keywordMatch && keywordMatch.index > 0) {
              result = result.slice(0, keywordMatch.index).trim();
            }

            return result;
          };

          const toPosition = (element) => {
            const candidates = [
              element.querySelector('p[class*="ce3ac449"], p[class*="0dfd3b8b"], span[class*="ce3ac449"]'),
              element.querySelector('p + p'),
            ];

            for (const node of candidates) {
              const value = toTrimmedText(node?.textContent);
              if (value && !/^Connected on/i.test(value)) {
                return value;
              }
            }

            return null;
          };

          const toConnectedOn = (element) => {
            const texts = Array.from(element.querySelectorAll('p, span, li'))
              .map((node) => toTrimmedText(node?.textContent))
              .filter((text) => /^Connected on/i.test(text));
            return texts[0] || null;
          };

          const findCardRoot = (marker) => {
            if (!marker) {
              return null;
            }

            const direct = marker.closest?.('[data-view-name="connections-list"] [componentkey]');
            if (direct?.querySelector?.('[data-view-name="message-button"]')) {
              return direct;
            }

            let current = marker;
            let depth = 0;
            const MAX_DEPTH = 150;
            while (current && depth < MAX_DEPTH) {
              if (current.querySelector?.('[data-view-name="message-button"]')) {
                return current;
              }
              current = current.parentElement ?? current.parentNode ?? null;
              depth += 1;
            }

            return marker;
          };

          const containers = Array.from(document.querySelectorAll('[data-view-name="connections-list"]'));
          const results = [];
          const seen = new Set();

          containers.forEach((container) => {
            const markers = Array.from(
              container.querySelectorAll('[componentkey][data-view-name="connections-profile"]')
            );

            markers
              .map((marker) => findCardRoot(marker))
              .filter(Boolean)
              .forEach((card) => {
                const messageLink = card.querySelector('[data-view-name="message-button"] a');
                const profileUrn = messageLink?.getAttribute('href') ?? '';

                const profileAnchors = Array.from(card.querySelectorAll('a[href*="linkedin.com/in/"]'));
                if (profileAnchors.length === 0) {
                  return;
                }

                const profileNameLink =
                  profileAnchors.find((anchor) => toTrimmedText(anchor.textContent).length > 0) || profileAnchors[0];

                const rawReference = profileNameLink?.getAttribute('href') ?? profileUrn;
                const profileSlug = extractSlug(rawReference);
                if (!profileSlug) {
                  return;
                }

                const fingerprint = `${owner || ''}::${profileSlug}`;
                if (seen.has(fingerprint)) {
                  return;
                }

                // Get position first to use for headline stripping
                const position = toPosition(card);

                const fullNameText = (() => {
                  const nameCandidates = [
                    profileNameLink?.textContent,
                    card.querySelector('p[class*="4682befa"], p[class*="1e1ac73c"], h3')?.textContent,
                    card.querySelector('a[href*="linkedin.com/in/"] span')?.textContent,
                  ];
                  
                  const rawText = nameCandidates
                    .map((text) => toTrimmedText(text))
                    .find((text) => text && !/\bmessage\b/i.test(text) && !/^connected on/i.test(text)) ?? '';
                  
                  // Strip headline from name if position is present
                  if (rawText && position) {
                    return stripHeadline(rawText, position);
                  }
                  
                  return rawText;
                })();

                if (!fullNameText) {
                  return;
                }

                const { firstName, lastName } = splitName(fullNameText);
                if (!firstName && !lastName) {
                  return;
                }

                const connectedOn = toConnectedOn(card);

                results.push({
                  user_id: owner ?? null,
                  First_Name: firstName ?? '',
                  Last_Name: lastName ?? '',
                  Connection_Profile_URL: profileSlug,
                  Email_Address: null,
                  Company: null,
                  Position: position,
                  Connected_On: connectedOn,
                });

                seen.add(fingerprint);
              });
          });

          return results;
        },
      });

      return Array.isArray(injection?.result) ? injection.result : [];
    } catch (error) {
      console.warn('[Linked Communication] Failed to scrape connections within page context.', error);
      return [];
    }
  }

  async #filterExistingConnections(records) {
    if (!Array.isArray(records) || records.length === 0) {
      return Array.isArray(records) ? records : [];
    }

    const payload = records
      .map((record) => {
        if (!record || typeof record !== 'object') {
          return null;
        }

        const userIdRaw = record.user_id ?? record.userId ?? null;
        const slugRaw = record.Connection_Profile_URL ?? record.linkedin_profile ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const slug = typeof slugRaw === 'string' ? slugRaw.trim() : '';

        if (!userId || !slug) {
          return null;
        }

        return {
          user_id: userId,
          linkedin_profile: slug,
        };
      })
      .filter(Boolean);

    if (payload.length === 0) {
      console.log('[Linked Communication] Duplicate validation skipped; no payload generated.');
      return records;
    }

    const payloadPreview = payload
      .slice(0, Math.min(3, payload.length))
      .map((entry) => entry.linkedin_profile)
      .join(', ');
    console.log(
      `[Linked Communication] Validating ${payload.length} connection(s) with Xano (sample: ${payloadPreview}${
        payload.length > 3 ? '…' : ''
      }).`
    );

    const xanoExports = window.LinkedCommunicationXanoClient;
    const XanoClient = xanoExports?.XanoClient;

    if (!XanoClient) {
      console.warn('[Linked Communication] Xano client unavailable; skipping duplicate validation.');
      return records;
    }

    const xanoClient = new XanoClient();

    try {
      const existing = await xanoClient.validateConnections(payload);
      const status = existing?.statusCode ?? existing?.status ?? null;
      if (status) {
        console.log('[Linked Communication] Xano validation HTTP status:', status);
      }
      const existingArray = Array.isArray(existing)
        ? existing
        : Array.isArray(existing?.data)
          ? existing.data
          : [];

      if (existingArray.length === 0) {
        console.log('[Linked Communication] Xano reports 0 existing connections.');
        return records;
      }

      const existingPreview = existingArray
        .slice(0, Math.min(3, existingArray.length))
        .map((item) => item.Connection_Profile_URL ?? item.linkedin_profile ?? 'unknown')
        .join(', ');
      console.log(
        `[Linked Communication] Xano reports ${existingArray.length} existing connection(s) (sample: ${existingPreview}${
          existingArray.length > 3 ? '…' : ''
        }).`
      );

      const existingSet = new Set();

      existingArray.forEach((item) => {
        if (!item || typeof item !== 'object') {
          return;
        }

        const userIdRaw = item.user_id ?? item.userId ?? null;
        const encodedSlugRaw = item.Connection_Profile_URL ?? item.linkedin_profile ?? null;
        const inputSlugRaw = item.Connection_Profile_URL_Input ?? item.linkedin_profile_input ?? null;

        const userId = typeof userIdRaw === 'number' ? String(userIdRaw) : String(userIdRaw ?? '').trim();
        const encodedSlug = typeof encodedSlugRaw === 'string' ? encodedSlugRaw.trim() : '';
        const inputSlug = typeof inputSlugRaw === 'string' ? inputSlugRaw.trim() : '';

        if (!userId) {
          return;
        }

        if (encodedSlug) {
          existingSet.add(`${userId}::${encodedSlug}`);
        }

        if (inputSlug) {
          existingSet.add(`${userId}::${inputSlug}`);
        }
      });

      if (existingSet.size === 0) {
        return records;
      }

      const removed = [];
      const kept = [];

      const result = records.filter((record) => {
        const userId = typeof record.user_id === 'number'
          ? String(record.user_id)
          : String(record.user_id ?? '').trim();
        const slug = typeof record.Connection_Profile_URL === 'string'
          ? record.Connection_Profile_URL.trim()
          : '';

        if (!userId || !slug) {
          console.log('[Linked Communication] Keeping connection without user/slug for safety:', record);
          return true;
        }

        const fingerprint = `${userId}::${slug}`;
        const isDuplicate = existingSet.has(fingerprint);
        if (isDuplicate) {
          removed.push(fingerprint);
        } else {
          kept.push(fingerprint);
        }

        return !isDuplicate;
      });

      if (removed.length > 0) {
        console.log(
          `[Linked Communication] Duplicate fingerprints removed: ${removed
            .slice(0, 3)
            .join(', ')}${removed.length > 3 ? '…' : ''}`
        );
      }

      return result;
    } catch (error) {
      console.warn('[Linked Communication] Failed to validate existing connections via Xano.', error);
      return records;
    }
  }

  async #prefetchConnections() {
    // No-op placeholder reserved for future enhancements.
  }

  #resetStore() {
    try {
      const capacity = typeof this.store?.capacity === 'number' ? this.store.capacity : undefined;
      this.store = new ConnectionStore({ capacity });
    } catch (error) {
      console.warn('Failed to reset connection store; falling back to clear.', error);
      if (this.store?.clear) {
        this.store.clear();
      } else if (ConnectionStore) {
        this.store = new ConnectionStore();
      }
    }
  }

  async #closeConnectionsTab(tabId) {
    if (!tabId || !chrome?.tabs?.remove) {
      this.lastTabId = null;
      return;
    }

    try {
      await chrome.tabs.remove(tabId);
    } catch (error) {
      console.warn('Failed to close connections tab.', error);
    } finally {
      if (this.lastTabId === tabId) {
        this.lastTabId = null;
      }
    }
  }
}

  window.LinkedCommunicationConnectionsDriver = {
    ConnectionsDriver,
  };
})();
