'use strict';

(function attachXanoClientToWindow() {
  const DEFAULT_BASE_URL = 'https://xano.atlanticsoft.co/api:Ks58d17q';
  const DEFAULT_LOGIN_PATH = '/auth/login';
  const DEFAULT_ME_PATH = '/auth/me';
  const DEFAULT_VALIDATE_URL = 'https://xano.atlanticsoft.co/api:mIBuuXC3/validate_existing_connections';
  const DEFAULT_CREATE_CONNECTION_URL = 'https://xano.atlanticsoft.co/api:mIBuuXC3/create_linkedin_connections';
  const DEFAULT_VALIDATE_INVITATIONS_URL = 'https://xano.atlanticsoft.co/api:mIBuuXC3/validate_existing_invitations';
  const DEFAULT_CREATE_INVITATION_URL = 'https://xano.atlanticsoft.co/api:mIBuuXC3/create_linkedin_invitation';
  const DEFAULT_LINKEDIN_API_BASE_URL = 'https://xano.atlanticsoft.co/api:mIBuuXC3';
  const DEFAULT_TASKS_BASE_URL = 'https://xano.atlanticsoft.co/api:i2KWpEI8';
  const DEFAULT_PROJECTS_BASE_URL = 'https://xano.atlanticsoft.co/api:_dY_2A8p';
  const DEFAULT_EXPIRY_SECONDS = 7 * 24 * 60 * 60;

  class XanoClient {
    constructor({
      baseUrl = DEFAULT_BASE_URL,
      loginPath = DEFAULT_LOGIN_PATH,
      mePath = DEFAULT_ME_PATH,
      validateUrl = DEFAULT_VALIDATE_URL,
      createConnectionUrl = DEFAULT_CREATE_CONNECTION_URL,
      validateInvitationsUrl = DEFAULT_VALIDATE_INVITATIONS_URL,
      createInvitationUrl = DEFAULT_CREATE_INVITATION_URL,
      linkedinApiBaseUrl = DEFAULT_LINKEDIN_API_BASE_URL,
      tasksBaseUrl = DEFAULT_TASKS_BASE_URL,
      projectsBaseUrl = DEFAULT_PROJECTS_BASE_URL,
      fetchImpl,
    } = {}) {
      this.baseUrl = this.#trimTrailingSlash(baseUrl);
      this.loginPath = loginPath;
      this.mePath = mePath;
      this.validateUrl = validateUrl;
      this.createConnectionUrl = createConnectionUrl;
      this.validateInvitationsUrl = validateInvitationsUrl;
      this.createInvitationUrl = createInvitationUrl;
      this.linkedinApiBaseUrl = this.#trimTrailingSlash(linkedinApiBaseUrl);
      this.tasksBaseUrl = this.#trimTrailingSlash(tasksBaseUrl);
      this.projectsBaseUrl = this.#trimTrailingSlash(projectsBaseUrl);
      this.fetchImpl = this.#resolveFetch(fetchImpl);
    }

    async login({ email, password }) {
      if (typeof email !== 'string' || email.trim().length === 0) {
        throw new Error('Email is required to log in.');
      }

      if (typeof password !== 'string' || password.length === 0) {
        throw new Error('Password is required to log in.');
      }

      const response = await this.fetchImpl(`${this.baseUrl}${this.loginPath}`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: email.trim(), password }),
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano login failed: ${message}`);
      }

      const payload = await this.#safeJson(response);
      const token = payload?.authToken ?? payload?.token ?? payload?.jwt ?? null;

      if (typeof token !== 'string' || token.trim().length === 0) {
        throw new Error('Xano login response did not include an auth token.');
      }

      const expiresInSeconds = this.#extractExpirySeconds(payload);
      const expiresAt = new Date(Date.now() + expiresInSeconds * 1000).toISOString();

      return {
        token: token.trim(),
        expiresAt,
        raw: payload,
      };
    }

    async me(authToken) {
      if (typeof authToken !== 'string' || authToken.trim().length === 0) {
        throw new Error('Auth token is required to fetch current user.');
      }

      const response = await this.fetchImpl(`${this.baseUrl}${this.mePath}`, {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          Authorization: authToken.trim(),
        },
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano me request failed: ${message}`);
      }

      return this.#safeJson(response);
    }

    async createConnection(connection) {
      if (!connection || typeof connection !== 'object') {
        throw new Error('connection must be an object.');
      }

      if (typeof this.createConnectionUrl !== 'string' || this.createConnectionUrl.trim().length === 0) {
        throw new Error('Xano create connection URL is not configured.');
      }

      const connectionUrl = this.#normalizeString(
        connection.Connection_Profile_URL ?? connection.linkedin_profile ?? connection.slug ?? ''
      );

      if (!connectionUrl) {
        throw new Error('Connection_Profile_URL is required to create a connection.');
      }

      let connectedOn = this.#coerceTimestamp(
        connection.Connected_On ?? connection.connected_on ?? connection.connectedOn
      );
      
      // Never send null for Connected_On - default to today
      if (!connectedOn) {
        connectedOn = new Date().toISOString();
      }

      const payload = {
        user_id: this.#coerceUserId(connection.user_id ?? connection.userId ?? null),
        First_Name: this.#toOptionalString(connection.First_Name ?? connection.first_name),
        Last_Name: this.#toOptionalString(connection.Last_Name ?? connection.last_name),
        Connection_Profile_URL: connectionUrl,
        Email_Address: this.#toOptionalString(connection.Email_Address ?? connection.email),
        Company: this.#toOptionalString(connection.Company ?? connection.company),
        Position: this.#toOptionalString(connection.Position ?? connection.position),
        Connected_On: connectedOn,
      };

      const response = await this.fetchImpl(this.createConnectionUrl.trim(), {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano create connection request failed: ${message}`);
      }

      return this.#safeJson(response);
    }

    async validateConnections(connections) {
      if (!Array.isArray(connections)) {
        throw new Error('connections must be an array.');
      }

      if (connections.length === 0) {
        return [];
      }

      if (typeof this.validateUrl !== 'string' || this.validateUrl.trim().length === 0) {
        throw new Error('Xano validate URL is not configured.');
      }

      const response = await this.fetchImpl(this.validateUrl.trim(), {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ connections }),
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano validate request failed: ${message}`);
      }

      return this.#safeJson(response);
    }

    async validateInvitations(invitations) {
      if (!Array.isArray(invitations)) {
        throw new Error('invitations must be an array.');
      }

      if (invitations.length === 0) {
        return [];
      }

      if (typeof this.validateInvitationsUrl !== 'string' || this.validateInvitationsUrl.trim().length === 0) {
        throw new Error('Xano validate invitations URL is not configured.');
      }

      const response = await this.fetchImpl(this.validateInvitationsUrl.trim(), {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ connections: invitations }),
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano validate invitations request failed: ${message}`);
      }

      return this.#safeJson(response);
    }

    async createInvitation(invitation) {
      if (!invitation || typeof invitation !== 'object') {
        throw new Error('invitation must be an object.');
      }

      if (typeof this.createInvitationUrl !== 'string' || this.createInvitationUrl.trim().length === 0) {
        throw new Error('Xano create invitation URL is not configured.');
      }

      const profileUrl = this.#normalizeString(
        invitation.Connection_Profile_URL ?? invitation.linkedin_profile ?? invitation.slug ?? ''
      );

      if (!profileUrl) {
        throw new Error('Connection_Profile_URL is required to create an invitation.');
      }

      const invitedOnRaw = invitation.Invited_On ?? invitation.invited_on ?? invitation.invitedOn;
      let invitedOnCoerced = this.#coerceTimestamp(invitedOnRaw);
      
      // Never send null for Invited_On - default to today
      if (!invitedOnCoerced) {
        invitedOnCoerced = new Date().toISOString();
      }

      const payload = {
        user_id: this.#coerceUserId(invitation.user_id ?? invitation.userId ?? null),
        First_Name: this.#toOptionalString(invitation.First_Name ?? invitation.first_name),
        Last_Name: this.#toOptionalString(invitation.Last_Name ?? invitation.last_name),
        Connection_Profile_URL: profileUrl,
        Message: this.#toOptionalString(invitation.Message ?? invitation.message),
        Position: this.#toOptionalString(invitation.Position ?? invitation.position),
        Invited_On: invitedOnCoerced,
      };

      const response = await this.fetchImpl(this.createInvitationUrl.trim(), {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const message = await this.#safeReadError(response);
        throw new Error(`Xano create invitation request failed: ${message}`);
      }

      return this.#safeJson(response);
    }

    #buildAuthHeaders(authToken) {
      return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        'X-Xano-Authorization': `Bearer ${authToken}`,
        'X-Xano-Authorization-Only': 'true',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
      };
    }

    async getTaskTypeDefinitions(authToken) {
      if (!authToken) throw new Error('Auth token is required to fetch task type definitions.');

      const url = `${this.tasksBaseUrl}/task_type_definition`;
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to fetch task type definitions: ${message}`);
      }

      return this.#safeJson(response);
    }

    async getBatchFreeInMail(authToken, linkedinProfiles) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!Array.isArray(linkedinProfiles) || linkedinProfiles.length === 0) return { matches: [] };

      const url = `${this.linkedinApiBaseUrl}/get_batch_free_in_mail`;
      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: {
          ...this.#buildAuthHeaders(authToken),
          'x-data-source': 'live',
        },
        body: JSON.stringify({ linkedin_profiles: linkedinProfiles }),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to check free InMail: ${message}`);
      }

      return this.#safeJson(response);
    }

    async checkLinkedNetwork(authToken, linkedinConnections) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!Array.isArray(linkedinConnections) || linkedinConnections.length === 0) {
        return { connections: [], invitations: [] };
      }

      const url = `${this.linkedinApiBaseUrl}/check_linked_network`;
      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: {
          ...this.#buildAuthHeaders(authToken),
          'x-data-source': 'live',
        },
        body: JSON.stringify({ linkedin_connections: linkedinConnections }),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to check LinkedIn network: ${message}`);
      }

      return this.#safeJson(response);
    }

    async getTasks(authToken, { assigneeId, status = 'pending', taskTypeId, taskTypeName, personType, projectId, hasFreeInmail, connectedToUserId, page = 1, perPage = 25, sortBy = 'created_at', sortOrder = 'desc' } = {}) {
      if (!authToken) throw new Error('Auth token is required to fetch tasks.');
      if (!assigneeId) throw new Error('assigneeId is required to fetch tasks.');

      const params = new URLSearchParams({
        assignee_id: String(assigneeId),
        executor_type: 'user',
        status,
        page: String(page),
        per_page: String(perPage),
        sort_by: sortBy,
        sort_order: sortOrder,
      });
      if (taskTypeId) params.set('task_type', String(taskTypeId));
      if (taskTypeName) params.set('task_type', taskTypeName);
      if (personType) params.set('person_type', personType);
      if (projectId) params.set('project_id', String(projectId));
      if (typeof hasFreeInmail === 'boolean') params.set('has_free_inmail', String(hasFreeInmail));
      if (connectedToUserId) params.set('connected_to_user_id', String(connectedToUserId));

      const url = `${this.tasksBaseUrl}/tasks?${params.toString()}`;
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to fetch tasks: ${message}`);
      }

      return this.#safeJson(response);
    }

    async getActiveProjects(authToken) {
      if (!authToken) throw new Error('Auth token is required to fetch projects.');

      const url = `${this.projectsBaseUrl}/project`;
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: {
          ...this.#buildAuthHeaders(authToken),
          'x-data-source': 'live',
        },
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to fetch projects: ${message}`);
      }

      const projects = await this.#safeJson(response);
      // Filter to only active projects
      return Array.isArray(projects) ? projects.filter(p => p.status === 'active') : [];
    }

    async getProjectStages(authToken, { projectId, stageType }) {
      if (!authToken) throw new Error('Auth token is required to fetch project stages.');
      if (!projectId) throw new Error('projectId is required to fetch project stages.');

      const params = new URLSearchParams();
      if (stageType) params.set('stage_type', stageType);
      const queryString = params.toString();
      const url = `${this.projectsBaseUrl}/project/${projectId}/stages${queryString ? '?' + queryString : ''}`;

      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to fetch project stages: ${message}`);
      }

      return this.#safeJson(response);
    }

    async changeAssociationStage(authToken, { associationId, stageId, notes }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!associationId) throw new Error('associationId is required.');
      if (!stageId) throw new Error('stageId is required.');

      const url = `${this.projectsBaseUrl}/association/id/${associationId}/change-stage`;
      const body = {
        project_person_association_id: associationId,
        stage_id: stageId,
        activity_type: 'stage_change',
      };
      if (notes) body.notes = notes;

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to change association stage: ${message}`);
      }

      return this.#safeJson(response);
    }

    async deleteTask(authToken, taskId) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!taskId) throw new Error('taskId is required.');

      const url = `${this.tasksBaseUrl}/task/${taskId}`;
      const response = await this.fetchImpl(url, {
        method: 'DELETE',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to delete task: ${message}`);
      }

      return this.#safeJson(response);
    }

    async getTaskCounts(authToken, { status, taskType, assigneeType, assigneeId, personType, connectedToUserId, hasFreeInmail } = {}) {
      if (!authToken) throw new Error('Auth token is required to fetch task counts.');

      const params = new URLSearchParams();
      if (status) params.set('status', status);
      if (taskType) params.set('task_type', taskType);
      if (assigneeType) params.set('assignee_type', assigneeType);
      if (assigneeId) params.set('assignee_id', String(assigneeId));
      if (personType) params.set('person_type', personType);
      if (connectedToUserId) params.set('connected_to_user_id', String(connectedToUserId));
      if (typeof hasFreeInmail === 'boolean') params.set('has_free_inmail', String(hasFreeInmail));

      // Add cache-busting timestamp
      params.set('_t', String(Date.now()));
      const queryString = params.toString();
      const url = `${this.tasksBaseUrl}/tasks/counts?${queryString}`;

      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to fetch task counts: ${message}`);
      }

      return this.#safeJson(response);
    }

    async completeLinkedInOutreach(authToken, { taskId, status = 'done', actionType }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!taskId) throw new Error('taskId is required.');

      const url = `${this.tasksBaseUrl}/special_taks/complete_linkedin_outreach`;
      const body = { task_id: taskId, status };
      if (actionType) body.action_type = actionType;
      if (status === 'skipped' || status === 'failed') {
        body.result = actionType || '';
      }

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to complete LinkedIn outreach: ${message}`);
      }

      return this.#safeJson(response);
    }

    async completeMessagingTask(authToken, { taskId, status = 'done', result }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!taskId) throw new Error('taskId is required.');

      const url = `${this.tasksBaseUrl}/special_taks/complete_messaging_task`;
      const body = { task_id: taskId, status };
      if (result) body.result = result;

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to complete messaging task: ${message}`);
      }

      return this.#safeJson(response);
    }

    async reassignTask(authToken, { taskIds, newAssigneeId, taskType }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!Array.isArray(taskIds) || taskIds.length === 0) throw new Error('taskIds array is required.');
      if (!newAssigneeId) throw new Error('newAssigneeId is required.');

      const isLinkedIn = taskType === 'linkedin_outreach';
      const url = isLinkedIn
        ? `${this.tasksBaseUrl}/special_taks/linked_in_reassign`
        : `${this.tasksBaseUrl}/tasks/reassign`;

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify({ task_ids: taskIds, new_assignee_id: newAssigneeId }),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to reassign task: ${message}`);
      }

      return this.#safeJson(response);
    }

    async getInvitationCount(authToken, { since, userId }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!since) throw new Error('since date is required.');

      const params = new URLSearchParams({
        since,
        per_page: '1',
      });
      if (userId) params.set('user_id', String(userId));

      const url = `${this.linkedinApiBaseUrl}/linkedin_invitation?${params.toString()}`;
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to get invitation count: ${message}`);
      }

      const data = await this.#safeJson(response);
      return { count: data?.itemsTotal ?? 0 };
    }

    async findLinkedInPerson(authToken, { linkedinUrl, linkedRecruiterProfileId, name, headline, source }) {
      if (!authToken) throw new Error('Auth token is required.');

      const body = {};
      if (linkedinUrl) body.linkedin_url = linkedinUrl;
      if (linkedRecruiterProfileId) body.linked_recruiter_profile_id = linkedRecruiterProfileId;
      if (name) body.name = name;
      if (headline) body.headline = headline;
      if (source) body.source = source;

      const url = `${this.linkedinApiBaseUrl}:v1/find_linked_in_person`;
      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        throw new Error(`Failed to find LinkedIn person: ${message}`);
      }

      return this.#safeJson(response);
    }

    async captureConversation(authToken, { personType, personId, threadUrl, conversation }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!personType) throw new Error('personType is required.');
      if (!personId) throw new Error('personId is required.');
      if (!threadUrl) throw new Error('threadUrl is required.');
      if (!conversation?.messages?.length) throw new Error('conversation.messages must be a non-empty array.');

      const url = 'https://xano.atlanticsoft.co/api:8MRsSZQv/call_recruiter_assistant/update_person_from_linkedin_conversation';
      const body = {
        person_id: personId,
        person_type: personType,
        conversation: {
          thread_url: threadUrl,
          captured_at: conversation.captured_at || new Date().toISOString(),
          messages: conversation.messages.map(msg => ({
            timestamp: msg.timestamp,
            sender: msg.sender,
            direction: msg.direction,
            body: msg.body,
          })),
        },
      };

      console.log('[XanoClient] captureConversation request:', {
        url,
        person_type: personType,
        person_id: personId,
        thread_url: threadUrl,
        message_count: conversation.messages.length,
      });

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorBody = await this.#safeReadError(response);
        console.error('[XanoClient] captureConversation failed:', {
          status: response.status,
          body: errorBody,
          person_type: personType,
          person_id: personId,
        });

        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        throw new Error(errorBody || `Request failed with status ${response.status}`);
      }

      const result = await this.#safeJson(response);
      console.log('[XanoClient] captureConversation success:', result);
      return result;
    }

    async suggestReply(authToken, { personId, personType, instructions, projectId, conversation }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!personType) throw new Error('personType is required.');
      if (!personId) throw new Error('personId is required.');
      if (!instructions) throw new Error('instructions is required.');
      if (!conversation?.messages?.length) throw new Error('conversation.messages must be a non-empty array.');

      const url = 'https://xano.atlanticsoft.co/api:8MRsSZQv/auto_agents/suggest_reply';
      const body = {
        person_id: personId,
        person_type: personType,
        instructions: instructions,
        project_id: projectId || null,
        conversation: {
          messages: conversation.messages.map(msg => ({
            timestamp: msg.timestamp,
            sender: msg.sender,
            direction: msg.direction,
            body: msg.body,
          })),
        },
      };

      console.log('[XanoClient] suggestReply request:', {
        url,
        person_type: personType,
        person_id: personId,
        project_id: projectId,
        message_count: conversation.messages.length,
      });

      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers: this.#buildAuthHeaders(authToken),
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorBody = await this.#safeReadError(response);
        console.error('[XanoClient] suggestReply failed:', {
          status: response.status,
          body: errorBody,
        });

        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        throw new Error(errorBody || `Request failed with status ${response.status}`);
      }

      const result = await this.#safeJson(response);
      console.log('[XanoClient] suggestReply success:', result);
      return result;
    }

    async getPersonAssociations(authToken, { personType, personId }) {
      if (!authToken) throw new Error('Auth token is required.');
      if (!personType) throw new Error('personType is required.');
      if (!personId) throw new Error('personId is required.');

      const url = `${this.projectsBaseUrl}/association/person/${personType}/${personId}`;
      console.log('[XanoClient] getPersonAssociations request:', { url, person_type: personType, person_id: personId });
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: this.#buildAuthHeaders(authToken),
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('AUTH_EXPIRED');
        const message = await this.#safeReadError(response);
        console.error('[XanoClient] getPersonAssociations failed:', { status: response.status, error: message });
        throw new Error(`Failed to get person associations: ${message}`);
      }

      const result = await this.#safeJson(response);
      console.log('[XanoClient] getPersonAssociations success:', { count: Array.isArray(result) ? result.length : 0 });
      return result;
    }

    #extractExpirySeconds(payload) {
      if (!payload || typeof payload !== 'object') {
        return DEFAULT_EXPIRY_SECONDS;
      }

      const raw = payload.expiresIn ?? payload.expires_in ?? payload.expiry ?? payload.ttl ?? payload.expires;
      if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
        return raw;
      }

      return DEFAULT_EXPIRY_SECONDS;
    }

    #normalizeString(value) {
      if (typeof value !== 'string') {
        return '';
      }
      return value.trim();
    }

    #toOptionalString(value) {
      if (typeof value !== 'string') {
        return '';
      }
      const trimmed = value.trim();
      return trimmed.length > 0 ? trimmed : '';
    }

    #coerceUserId(value) {
      if (typeof value === 'number' && Number.isFinite(value)) {
        return value;
      }

      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (trimmed.length === 0) {
          return null;
        }

        const parsed = Number.parseInt(trimmed, 10);
        return Number.isFinite(parsed) ? parsed : null;
      }

      return null;
    }

    #coerceTimestamp(value) {
      if (!value) {
        return null;
      }

      let candidate;

      if (value instanceof Date) {
        candidate = value;
      } else if (typeof value === 'number' && Number.isFinite(value)) {
        candidate = new Date(value);
      } else if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) {
          return null;
        }

        const cleaned = trimmed.replace(/^Connected on\s+/i, '');
        candidate = new Date(cleaned);
      }

      if (!(candidate instanceof Date) || Number.isNaN(candidate.getTime())) {
        return null;
      }

      return candidate.toISOString();
    }

    #resolveFetch(fetchOverride) {
      if (typeof fetchOverride === 'function') {
        return fetchOverride;
      }

      if (typeof window !== 'undefined' && typeof window.fetch === 'function') {
        return window.fetch.bind(window);
      }

      if (typeof globalThis.fetch === 'function') {
        return (...args) => globalThis.fetch(...args);
      }

      throw new Error('XanoClient requires a fetch implementation.');
    }

    async #safeReadError(response) {
      try {
        const data = await response.json();
        if (data && typeof data === 'object') {
          return data.message ?? JSON.stringify(data);
        }
      } catch (error) {
        // Ignore JSON parse errors.
      }

      try {
        return await response.text();
      } catch (error) {
        return `${response.status} ${response.statusText}`;
      }
    }

    async #safeJson(response) {
      try {
        return await response.json();
      } catch (error) {
        throw new Error('Failed to parse JSON response from Xano.');
      }
    }

    #trimTrailingSlash(value) {
      if (typeof value !== 'string') {
        return DEFAULT_BASE_URL;
      }
      return value.endsWith('/') ? value.slice(0, -1) : value;
    }
  }

  window.LinkedCommunicationXanoClient = {
    XanoClient,
    DEFAULT_BASE_URL,
    DEFAULT_VALIDATE_URL,
  };
})();
