function logWithTimestamp(...args) {
  const timestamp = new Date().toISOString().replace('T', ' ').slice(0, 23);
  console.log(`[${timestamp}]`, ...args);
}

// ---- Global State ----
let currentAuthToken = null;
let currentUserId = null;
let currentUserName = null;
let tasksCurrentPage = 1;
let tasksPageTotal = 1;
let taskPollInterval = null;
let taskTypeDefinitions = []; // Loaded from API
let taskTypeIdMap = {}; // Maps id -> name_key
let taskTypeNameMap = {}; // Maps name_key -> definition
let stageCache = {};
const STAGE_CACHE_TTL = 10 * 60 * 1000; // 10 minutes
let currentChatContact = null;
let currentCapturedChat = null; // Stores captured chat data for "Update ATS"

// LinkedIn tab group management
let linkedInTabId = null;
let linkedInGroupId = null;

// Human-facing task types (shown in filter dropdown)
const HUMAN_TASK_TYPES = ['linkedin_outreach', 'manual_check'];

// ---- LinkedIn Tab Group Management ----
// Extract LinkedIn slug from URL (e.g., "john-doe" from "https://www.linkedin.com/in/john-doe/")
function getLinkedInSlug(url) {
  if (!url) return null;
  const match = url.match(/linkedin\.com\/in\/([^/?#]+)/);
  return match ? match[1].toLowerCase() : null;
}

async function openInLinkedInTab(url) {
  try {
    const targetSlug = getLinkedInSlug(url);

    // Find existing LinkedIn tabs
    const linkedInTabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });

    // Check if any LinkedIn tab already has the same profile - just focus it
    for (const tab of linkedInTabs) {
      const tabSlug = getLinkedInSlug(tab.url);
      if (targetSlug && tabSlug && targetSlug === tabSlug) {
        linkedInTabId = tab.id;
        await chrome.tabs.update(tab.id, { active: true });
        await chrome.windows.update(tab.windowId, { focused: true });
        return; // Already on correct profile, no refresh needed
      }
    }

    // Find existing LinkedIn tab group
    if (chrome.tabGroups && !linkedInGroupId) {
      try {
        const groups = await chrome.tabGroups.query({ title: 'LinkedIn' });
        if (groups.length > 0) {
          linkedInGroupId = groups[0].id;
        }
      } catch (e) {
        // tabGroups.query not supported in all versions
      }
    }

    // If we have a tracked tab or found LinkedIn tabs, reuse one
    let tabToUse = null;

    if (linkedInTabId) {
      try {
        tabToUse = await chrome.tabs.get(linkedInTabId);
      } catch (e) {
        linkedInTabId = null;
      }
    }

    // If no tracked tab, use first LinkedIn tab found
    if (!tabToUse && linkedInTabs.length > 0) {
      tabToUse = linkedInTabs[0];
      linkedInTabId = tabToUse.id;
    }

    if (tabToUse) {
      // Update existing tab with new URL
      await chrome.tabs.update(tabToUse.id, { url, active: true });
      await chrome.windows.update(tabToUse.windowId, { focused: true });
      return;
    }

    // No existing LinkedIn tab - create a new one

    // Create a new tab
    const newTab = await chrome.tabs.create({ url, active: true });
    linkedInTabId = newTab.id;

    // Try to add to or create a tab group (if API available)
    if (chrome.tabGroups) {
      try {
        if (linkedInGroupId) {
          try {
            await chrome.tabs.group({ tabIds: [newTab.id], groupId: linkedInGroupId });
          } catch (e) {
            linkedInGroupId = await chrome.tabs.group({ tabIds: [newTab.id] });
            await chrome.tabGroups.update(linkedInGroupId, {
              title: 'LinkedIn',
              color: 'blue',
              collapsed: false
            });
          }
        } else {
          linkedInGroupId = await chrome.tabs.group({ tabIds: [newTab.id] });
          await chrome.tabGroups.update(linkedInGroupId, {
            title: 'LinkedIn',
            color: 'blue',
            collapsed: false
          });
        }
      } catch (e) {
        console.warn('Tab grouping failed:', e);
      }
    }
  } catch (error) {
    console.error('Failed to open LinkedIn tab:', error);
    chrome.tabs.create({ url });
  }
}

async function loadTaskTypeDefinitions(xanoClient, authToken) {
  if (!xanoClient || !authToken) return;

  try {
    const definitions = await xanoClient.getTaskTypeDefinitions(authToken);
    if (Array.isArray(definitions)) {
      taskTypeDefinitions = definitions;
      // Build lookup maps
      taskTypeIdMap = {};
      taskTypeNameMap = {};
      definitions.forEach(def => {
        if (def.id && def.name_key) {
          taskTypeIdMap[def.id] = def.name_key;
          taskTypeNameMap[def.name_key] = def;
        }
      });
      // Update the filter dropdown
      populateTaskTypeFilter();
    }
  } catch (error) {
    console.warn('Failed to load task type definitions:', error);
    // Fallback to hardcoded values if API fails
    taskTypeIdMap = {
      1: 'linkedin_outreach',
      7: 'direct_outreach',
      8: 'manual_check',
    };
  }
}

function populateTaskTypeFilter() {
  const typeFilter = document.getElementById('task-type-filter');
  if (!typeFilter) return;

  // Get current value to restore after repopulating
  const currentValue = typeFilter.value;

  // Clear existing options
  typeFilter.innerHTML = '';

  // Hardcoded task type options (only these 3 needed)
  // Order: All Types first, then specific types
  // Use API name keys (not numeric IDs)
  const taskTypeOptions = [
    { id: '', name: 'All Types' },
    { id: 'linkedin_outreach', name: 'LinkedIn Outreach' },
    { id: 'manual_check', name: 'Manual Review' },
  ];

  taskTypeOptions.forEach(opt => {
    const option = document.createElement('option');
    option.value = opt.id;
    option.textContent = opt.name;
    typeFilter.appendChild(option);
  });

  // Restore previous selection if valid, default to LinkedIn Outreach
  if (currentValue && Array.from(typeFilter.options).some(opt => opt.value === currentValue)) {
    typeFilter.value = currentValue;
  } else {
    typeFilter.value = 'linkedin_outreach'; // Default to LinkedIn Outreach
  }
}

function formatTaskTypeName(nameKey) {
  // Convert name_key to human-readable format
  const names = {
    'linkedin_outreach': 'LinkedIn Outreach',
    'manual_check': 'Manual Review',
  };
  return names[nameKey] || nameKey.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

async function initialize() {
  bridgeConsoleToBackground();

  const memory = await prepareMemory();
  const xanoClient = await prepareXanoClient();

  // Check for existing auth
  const storedToken = memory.getAuthToken?.();
  const storedUserId = memory.getUserId?.();
  const storedExpiry = memory.getTokenValidUntil?.();

  if (storedToken && storedUserId) {
    const expiry = storedExpiry ? new Date(storedExpiry) : null;
    if (expiry && expiry <= new Date()) {
      // Token expired
      showLoginUI();
    } else {
      currentAuthToken = storedToken;
      currentUserId = storedUserId;
      currentUserName = memory.getUsername?.() || 'User';
      // Load task type definitions before showing UI
      await loadTaskTypeDefinitions(xanoClient, currentAuthToken);
      showAuthenticatedUI(xanoClient, memory);
    }
  } else {
    showLoginUI();
  }

  setupLoginForm(memory, xanoClient);
  setupLogout(memory, xanoClient);
  setupTabs();
  setupChatTab(xanoClient);
  setupSettingsForm(memory, xanoClient);
  setupManualExtract(memory, xanoClient);
  setupManualInvitationExtract(memory, xanoClient);
  setupOpenLinkedInButtons();
}

// ---- Toast Notification ----
function showToast(message, type = '') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = 'toast';
  if (type) toast.classList.add(`toast-${type}`);
  toast.classList.remove('hidden');
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => toast.classList.add('hidden'), 2500);
}

// ---- Auth UI ----
function showLoginUI() {
  const loginContainer = document.getElementById('login-container');
  const authContent = document.getElementById('auth-content');
  if (loginContainer) loginContainer.classList.remove('hidden');
  if (authContent) authContent.classList.add('hidden');
  stopTaskPolling();
}

function showAuthenticatedUI(xanoClient, memory) {
  const loginContainer = document.getElementById('login-container');
  const authContent = document.getElementById('auth-content');
  if (loginContainer) loginContainer.classList.add('hidden');
  if (authContent) authContent.classList.remove('hidden');

  // Update auth bar
  const avatarEl = document.getElementById('auth-avatar');
  const nameEl = document.getElementById('auth-name');
  const sessionEl = document.getElementById('auth-session');

  if (avatarEl && currentUserName) {
    avatarEl.textContent = currentUserName.charAt(0).toUpperCase();
  }
  if (nameEl) nameEl.textContent = currentUserName || 'User';
  if (sessionEl) sessionEl.textContent = 'Session active';

  // Update stored credentials in settings
  updateCredentialSummary(memory);

  // Load tasks and refresh project filter
  if (xanoClient) {
    populateProjectFilter(xanoClient);
    loadTasks(xanoClient);
    loadInvitationCounts(xanoClient);
    startTaskPolling(xanoClient);
  }
}

function updateCredentialSummary(memory) {
  const storedUserIdEl = document.getElementById('stored-user-id');
  const storedExpiryEl = document.getElementById('stored-token-expiry');

  if (storedUserIdEl) {
    storedUserIdEl.textContent = memory.getUserId?.() || 'Not set';
  }
  if (storedExpiryEl) {
    const expiry = memory.getTokenValidUntil?.();
    storedExpiryEl.textContent = expiry ? formatTimestamp(expiry) : 'Not set';
  }
}

// ---- Login ----
function setupLoginForm(memory, xanoClient) {
  const form = document.getElementById('login-form');
  const loginBtn = document.getElementById('login-btn');
  const errorEl = document.getElementById('login-error');

  if (!form || !xanoClient) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email')?.value?.trim();
    const password = document.getElementById('login-password')?.value;

    if (!email || !password) {
      if (errorEl) errorEl.textContent = 'Please provide email and password.';
      return;
    }

    if (loginBtn) {
      loginBtn.disabled = true;
      loginBtn.textContent = 'Logging in...';
    }
    if (errorEl) errorEl.textContent = '';

    try {
      const { token, expiresAt } = await xanoClient.login({ email, password });
      const profile = await xanoClient.me(token);

      memory.setAuthToken?.(token);
      memory.setTokenValidUntil?.(expiresAt);

      const resolvedId = resolveUserId(profile);
      if (resolvedId) {
        memory.setUserId?.(resolvedId);
        currentUserId = resolvedId;
      }

      const resolvedName = profile?.name || profile?.first_name || profile?.email || email;
      memory.setUsername?.(resolvedName);
      currentUserName = resolvedName;

      await memory.save();

      currentAuthToken = token;

      // Clear password
      const passwordInput = document.getElementById('login-password');
      if (passwordInput) passwordInput.value = '';

      // Load task type definitions after login
      await loadTaskTypeDefinitions(xanoClient, currentAuthToken);

      showAuthenticatedUI(xanoClient, memory);
      showToast('Login successful', 'success');
    } catch (error) {
      console.error('Login failed', error);
      if (errorEl) errorEl.textContent = error?.message || 'Login failed. Check your credentials.';
    } finally {
      if (loginBtn) {
        loginBtn.disabled = false;
        loginBtn.textContent = 'Login';
      }
    }
  });
}

// ---- Logout ----
function setupLogout(memory, xanoClient) {
  const logoutBtn = document.getElementById('logout-btn');
  if (!logoutBtn) return;

  logoutBtn.addEventListener('click', async () => {
    currentAuthToken = null;
    currentUserId = null;
    currentUserName = null;

    memory.setAuthToken?.(null);
    memory.setUserId?.(null);
    memory.setTokenValidUntil?.(null);
    await memory.save();

    stopTaskPolling();
    showLoginUI();
    showToast('Logged out');
  });
}

// ---- Task Loading ----
async function loadTasks(xanoClient) {
  if (!currentAuthToken || !currentUserId) return;

  const tasksList = document.getElementById('tasks-list');
  const pendingCountEl = document.getElementById('task-pending-count');
  const totalCountEl = document.getElementById('task-total-count');
  const projectFilterValue = document.getElementById('task-project-filter')?.value || '';
  const typeFilterValue = document.getElementById('task-type-filter')?.value || '';
  const statusFilter = 'pending';
  const sortFilter = document.getElementById('task-sort-filter')?.value || 'created_at-desc';
  const freeInmailFilterValue = document.getElementById('task-free-inmail-filter')?.value || '';
  const connectedFilterValue = document.getElementById('task-connected-filter')?.value || '';

  // Parse sort filter
  const [sortBy, sortOrder] = sortFilter.split('-');

  if (tasksList) tasksList.innerHTML = '<p class="tasks-empty">Loading tasks...</p>';

  try {
    const options = {
      assigneeId: currentUserId,
      status: statusFilter,
      page: tasksCurrentPage,
      perPage: 25,
      sortBy: sortBy || 'created_at',
      sortOrder: sortOrder || 'desc',
    };
    // Filter by project
    if (projectFilterValue) {
      const projectId = parseInt(projectFilterValue, 10);
      if (!isNaN(projectId)) {
        options.projectId = projectId;
      }
    }
    // Free InMail filter (server-side)
    if (freeInmailFilterValue === 'true') {
      options.hasFreeInmail = true;
    } else if (freeInmailFilterValue === 'false') {
      options.hasFreeInmail = false;
    }
    // Connected filter (server-side)
    if (connectedFilterValue === 'connected') {
      options.connectedToUserId = currentUserId;
    } else if (connectedFilterValue === 'not_connected') {
      options.connectedToUserId = -currentUserId; // Negative = NOT connected
    }
    // Filter by task type name (e.g., 'linkedin_outreach', 'manual_check')
    if (typeFilterValue) {
      options.taskTypeName = typeFilterValue;
    }

    const response = await xanoClient.getTasks(currentAuthToken, options);
    const tasks = response?.tasks || response?.items || [];
    const pagination = response?.pagination || {};
    const itemsTotal = pagination?.total ?? response?.itemsTotal ?? 0;
    const perPage = pagination?.per_page ?? 25;
    tasksPageTotal = pagination?.total ? Math.ceil(pagination.total / perPage) : (response?.pageTotal || 1);

    if (pendingCountEl) pendingCountEl.textContent = statusFilter === 'pending' ? String(itemsTotal) : '-';
    if (totalCountEl) totalCountEl.textContent = String(itemsTotal);

    if (tasks.length === 0) {
      if (tasksList) tasksList.innerHTML = '<p class="tasks-empty">No tasks found.</p>';
    } else {
      // Fetch enrichment data for tasks
      const enrichmentData = await fetchEnrichmentData(xanoClient, tasks);

      if (tasksList) tasksList.innerHTML = '';
      tasks.forEach(task => {
        const card = renderTaskCard(task, xanoClient, enrichmentData);
        if (tasksList) tasksList.appendChild(card);
      });
    }

    updatePagination();

    // Update badge via background
    if (statusFilter === 'pending') {
      try {
        chrome.runtime.sendMessage({
          type: 'update-task-badge',
          payload: { count: itemsTotal },
        });
      } catch (e) { /* ignore */ }
    }
  } catch (error) {
    console.error('Failed to load tasks', error);
    if (error.message === 'AUTH_EXPIRED') {
      showLoginUI();
      showToast('Session expired. Please login again.', 'error');
      return;
    }
    if (tasksList) tasksList.innerHTML = '<p class="tasks-empty">Failed to load tasks.</p>';
  }
}

// ---- Enrichment Data Fetching ----
async function fetchEnrichmentData(xanoClient, tasks) {
  const enrichment = {
    freeInMail: {}, // Maps linkedin_slug -> { can_send: boolean, recruiter_name: string }
    connections: new Set(), // Set of linkedin_slugs that are connections
    invitations: new Set(), // Set of linkedin_slugs that have pending invitations
  };

  if (!tasks || tasks.length === 0) return enrichment;

  // Extract LinkedIn slugs from tasks
  const linkedinSlugs = [];
  tasks.forEach(task => {
    const slug = extractLinkedInSlug(task);
    if (slug) linkedinSlugs.push(slug);
  });

  if (linkedinSlugs.length === 0) return enrichment;

  // Fetch enrichment data in parallel
  try {
    const [freeInMailResponse, networkResponse] = await Promise.all([
      xanoClient.getBatchFreeInMail(currentAuthToken, linkedinSlugs).catch(err => {
        console.warn('Failed to fetch free InMail data:', err);
        return { matches: [] };
      }),
      xanoClient.checkLinkedNetwork(currentAuthToken, linkedinSlugs).catch(err => {
        console.warn('Failed to fetch network data:', err);
        return { connections: [], invitations: [] };
      }),
    ]);

    // Process free InMail results
    const freeInMailMatches = freeInMailResponse?.matches || freeInMailResponse?.data || [];
    if (Array.isArray(freeInMailMatches)) {
      freeInMailMatches.forEach(match => {
        const slug = match.linkedin_slug || match.linkedin_profile || match.slug || '';
        if (slug) {
          // If match exists in response, free InMail is available via the users listed
          const firstUser = Array.isArray(match.users) ? match.users[0] : null;
          enrichment.freeInMail[slug] = {
            canSend: true,
            recruiterName: firstUser?.user_name || '',
          };
        }
      });
    }

    // Process connection results
    const connectionsList = networkResponse?.connections || [];
    if (Array.isArray(connectionsList)) {
      connectionsList.forEach(conn => {
        const slug = conn.linkedin_profile || conn.slug || conn.Connection_Profile_URL || conn;
        if (typeof slug === 'string' && slug) {
          enrichment.connections.add(slug);
        }
      });
    }

    // Process invitation results
    const invitationsList = networkResponse?.invitations || [];
    if (Array.isArray(invitationsList)) {
      invitationsList.forEach(inv => {
        const slug = inv.linkedin_profile || inv.slug || inv.Connection_Profile_URL || inv;
        if (typeof slug === 'string' && slug) {
          enrichment.invitations.add(slug);
        }
      });
    }
  } catch (error) {
    console.error('Error fetching enrichment data:', error);
  }

  return enrichment;
}

function extractLinkedInSlug(task) {
  const payload = task.payload || {};
  const person = task.person || {};

  // Try multiple field names for LinkedIn URL/slug
  const profileUrl = payload.profile_url || payload.linkedin_url || payload.linkedin_profile_url
    || person.linkedin_profile || person.linkedin_url || person.linkedin_profile_url
    || person.profile_url || '';

  if (!profileUrl) return '';

  // If it's a full URL, extract the slug
  if (profileUrl.includes('linkedin.com')) {
    const match = profileUrl.match(/linkedin\.com\/in\/([^/?]+)/);
    return match ? match[1] : profileUrl;
  }

  return profileUrl;
}

function updatePagination() {
  const paginationEl = document.getElementById('tasks-pagination');
  const prevBtn = document.getElementById('tasks-prev-btn');
  const nextBtn = document.getElementById('tasks-next-btn');
  const pageInfo = document.getElementById('tasks-page-info');

  if (!paginationEl) return;

  if (tasksPageTotal <= 1) {
    paginationEl.classList.add('hidden');
    return;
  }

  paginationEl.classList.remove('hidden');
  if (prevBtn) prevBtn.disabled = tasksCurrentPage <= 1;
  if (nextBtn) nextBtn.disabled = tasksCurrentPage >= tasksPageTotal;
  if (pageInfo) pageInfo.textContent = `Page ${tasksCurrentPage} of ${tasksPageTotal}`;
}

// ---- Invitation Counts ----
async function loadInvitationCounts(xanoClient) {
  if (!currentAuthToken || !currentUserId) return;

  const weekCountEl = document.getElementById('invites-week-count');
  const rolling7dCountEl = document.getElementById('invites-7d-count');

  // Calculate Monday of this week (start of week)
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday, ...
  const daysSinceMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  const monday = new Date(now);
  monday.setDate(now.getDate() - daysSinceMonday);
  monday.setHours(0, 0, 0, 0);
  const mondayISO = monday.toISOString().split('T')[0];

  // Calculate 7 days ago
  const sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(now.getDate() - 7);
  sevenDaysAgo.setHours(0, 0, 0, 0);
  const sevenDaysAgoISO = sevenDaysAgo.toISOString().split('T')[0];

  try {
    const [weekResult, rolling7dResult] = await Promise.all([
      xanoClient.getInvitationCount(currentAuthToken, { since: mondayISO, userId: currentUserId }),
      xanoClient.getInvitationCount(currentAuthToken, { since: sevenDaysAgoISO, userId: currentUserId }),
    ]);

    if (weekCountEl) weekCountEl.textContent = weekResult.count ?? '-';
    if (rolling7dCountEl) rolling7dCountEl.textContent = rolling7dResult.count ?? '-';
  } catch (error) {
    console.error('Failed to load invitation counts:', error);
    if (weekCountEl) weekCountEl.textContent = '-';
    if (rolling7dCountEl) rolling7dCountEl.textContent = '-';
  }
}

// ---- Task Card Rendering ----
function renderTaskCard(task, xanoClient, enrichmentData = {}) {
  const person = task.person || {};
  const project = task._project || task.project || {};
  const taskType = getTaskType(task);
  const payload = task.payload || {};

  const card = document.createElement('div');
  card.className = 'task-card';
  card.dataset.taskId = task.id;

  const firstName = person.first_name || '';
  const lastName = person.last_name || '';
  const fullName = person.name || `${firstName} ${lastName}`.trim() || 'Unknown';
  const nameParts = fullName.split(' ').filter(Boolean);
  const initials = nameParts.length >= 2
    ? `${nameParts[0].charAt(0)}${nameParts[nameParts.length - 1].charAt(0)}`.toUpperCase()
    : (nameParts[0]?.charAt(0)?.toUpperCase() || '?');

  // Task type badge - normalize for comparison
  const normalizedType = (taskType || '').toLowerCase().replace(/\s+/g, '_');
  let typeBadgeClass = 'badge-linkedin';
  let typeBadgeText = 'LinkedIn';
  if (normalizedType === 'manual_check' || normalizedType.includes('manual') || normalizedType.includes('review')) {
    typeBadgeClass = 'badge-manual';
    typeBadgeText = 'Review';
  }

  // Person type badge
  const personType = task.person_type || person.type;
  const personTypeBadge = personType === 'candidate'
    ? '<span class="badge badge-candidate">C</span>'
    : '<span class="badge badge-prospect">P</span>';

  // Project badge
  const projectName = project.name || project.title || '';
  const projectBadge = projectName
    ? `<span class="badge badge-project" title="${escapeHtml(projectName)}">${escapeHtml(projectName)}</span>`
    : '';

  // Score badge with expandable score_reasons
  const association = task.association || {};
  const personScore = association.score || person.score || project.score || task.score || '';
  const scoreReasonsRaw = association.score_reasons || person.score_reasons || [];
  const scoreReasonsList = Array.isArray(scoreReasonsRaw) ? scoreReasonsRaw : (scoreReasonsRaw ? [scoreReasonsRaw] : []);
  const scoreBadge = personScore
    ? `<span class="badge badge-score${scoreReasonsList.length ? ' has-reasons' : ''}" data-action="toggle-score-reasons">${personScore}${scoreReasonsList.length ? ' ▾' : ''}</span>`
    : '';
  const scoreReasonsHtml = scoreReasonsList.length
    ? `<div class="score-reasons-panel hidden"><div class="score-reasons-header">Score Breakdown</div><ul class="score-reasons-list">${scoreReasonsList.map(r => `<li>${escapeHtml(r)}</li>`).join('')}</ul></div>`
    : '';

  // Current stage badge
  const currentStage = association.stage?.name || association.stage_name || '';
  const stageBadge = currentStage
    ? `<span class="badge badge-stage" title="Current stage">${escapeHtml(currentStage)}</span>`
    : '';

  // Enrichment badges
  const linkedinSlug = extractLinkedInSlug(task);
  let enrichmentBadges = '';

  if (linkedinSlug && enrichmentData) {
    // Check if already connected
    if (enrichmentData.connections?.has?.(linkedinSlug)) {
      enrichmentBadges += '<span class="badge badge-connected" title="Already connected">Connected</span>';
    }
    // Check if invitation pending
    else if (enrichmentData.invitations?.has?.(linkedinSlug)) {
      enrichmentBadges += '<span class="badge badge-invited" title="Invitation pending">Invited</span>';
    }

    // Check free InMail availability
    const freeInMailInfo = enrichmentData.freeInMail?.[linkedinSlug];
    if (freeInMailInfo && freeInMailInfo.canSend) {
      const recruiterTitle = freeInMailInfo.recruiterName
        ? `Free InMail via ${freeInMailInfo.recruiterName}`
        : 'Free InMail available';
      enrichmentBadges += `<span class="badge badge-free-inmail" title="${escapeHtml(recruiterTitle)}">Free InMail</span>`;
    }
  }

  // Location
  const locationParts = [person.city, person.country].filter(Boolean);
  const location = locationParts.length > 0 ? locationParts.join(', ') : '';

  // Date
  const dateStr = task.created_at ? formatShortDate(task.created_at) : '';

  let cardHTML = `
    <div class="task-card-header">
      <div class="task-person-avatar">${escapeHtml(initials)}</div>
      <div class="task-person-info">
        <p class="task-person-name">${escapeHtml(fullName)}</p>
        ${(person.headline || person.short_role) ? `<p class="task-person-role">${escapeHtml(person.headline || person.short_role)}</p>` : ''}
      </div>
      <div class="task-header-actions">
        <button class="icon-btn btn-linkedin" data-action="open-linkedin" title="Open LinkedIn profile">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
        </button>
        <button class="icon-btn btn-ats" data-action="view-profile" title="View ATS profile">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        </button>
      </div>
    </div>
    <div class="task-meta-row">
      <div class="task-badges-left">
        <span class="badge ${typeBadgeClass}">${typeBadgeText}</span>
        ${personTypeBadge}
        ${scoreBadge}
      </div>
      <div class="task-badges-right">
        ${stageBadge}
        ${enrichmentBadges}
      </div>
    </div>
    ${projectName ? `<div class="task-project-row"><span class="project-label">${escapeHtml(projectName)}</span><span class="task-date">${escapeHtml(dateStr)}</span></div>` : `<div class="task-project-row"><span class="task-date">${escapeHtml(dateStr)}</span></div>`}
    ${scoreReasonsHtml}
  `;

  // Manual check notes - show agent_notes and suggested/recommended action
  const isManualCheck = taskType === 'manual_check' || normalizedType === 'manual_check' || normalizedType.includes('manual');
  const agentNotes = payload.agent_notes || '';
  const suggestedAction = payload.suggested_action || payload.recommended_action || '';

  if (isManualCheck && (agentNotes || suggestedAction)) {
    cardHTML += '<div class="task-notes">';
    if (agentNotes) {
      cardHTML += `<div class="task-agent-notes"><span class="notes-label">Agent Notes</span>${escapeHtml(agentNotes)}</div>`;
    }
    if (suggestedAction) {
      cardHTML += `<div class="task-suggested-action"><span class="notes-label">Suggested Action</span>${escapeHtml(suggestedAction)}</div>`;
    }
    cardHTML += '</div>';
  }

  // Actions
  cardHTML += '<div class="task-actions">';
  cardHTML += buildTaskActions(task, taskType);
  cardHTML += '</div>';

  card.innerHTML = cardHTML;

  // Attach action handlers
  attachTaskActionHandlers(card, task, xanoClient);

  return card;
}

function getTaskType(task) {
  // Hardcoded ID to name mapping (always reliable)
  const idToName = {
    1: 'linkedin_outreach',
    8: 'manual_check',
  };

  // First check task_type_id with hardcoded mapping
  if (task.task_type_id && idToName[task.task_type_id]) {
    return idToName[task.task_type_id];
  }

  // Then try the loaded definitions map
  if (task.task_type_id && taskTypeIdMap[task.task_type_id]) {
    return taskTypeIdMap[task.task_type_id];
  }

  // Try multiple ways to get the task type from other fields
  const candidates = [
    task._task_type_definition?.name_key,
    task._task_type_definition?.name,
    task.task_type_definition?.name_key,
    task.task_type_definition?.name,
    task.task_type?.name_key,
    task.task_type?.name,
    task.task_type?.key,
    task.task_type?.label,
    task.task_type,
    task.type,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim()) {
      return candidate.trim().toLowerCase().replace(/\s+/g, '_');
    }
  }

  // Fallback: detect by payload content
  const payload = task.payload || {};
  // Manual check has agent_notes
  if (payload.agent_notes || payload.recommended_action || payload.suggested_action) {
    return 'manual_check';
  }
  if (payload.profile_url && (payload.message_invite || payload.message_inmail)) {
    return 'linkedin_outreach';
  }

  return '';
}

async function getStagesCached(xanoClient, projectId, stageType) {
  const key = `${projectId}:${stageType}`;
  const cached = stageCache[key];
  if (cached && (Date.now() - cached.ts < STAGE_CACHE_TTL)) {
    return cached.data;
  }
  const data = await xanoClient.getProjectStages(currentAuthToken, { projectId, stageType });
  stageCache[key] = { data, ts: Date.now() };
  return data;
}

function renderStagePanel(card, task, xanoClient, preSelectStageName = null) {
  // Toggle: if panel already open, close it
  const existing = card.querySelector('.stage-panel');
  if (existing) {
    existing.remove();
    return;
  }

  const projectId = task._project?.id || task.project?.id || task.project_id;
  const associationId = task.association?.id;

  if (!projectId) {
    showToast('No project found for this task', 'error');
    return;
  }
  if (!associationId) {
    showToast('No association ID found for this task', 'error');
    return;
  }

  // Derive stage type from person_type
  const personType = task.person_type || task.payload?.person_type || '';
  let stageType = '';
  if (personType === 'candidate') stageType = 'candidates';
  else if (personType === 'prospect') stageType = 'prospects';

  // Determine header text based on pre-selection
  const headerText = preSelectStageName ? `Discard` : 'Move to Stage';

  // Create panel skeleton with loading state
  const panel = document.createElement('div');
  panel.className = 'stage-panel';
  panel.innerHTML = `
    <div class="stage-panel-header">
      <span>${headerText}</span>
      <button data-action="close-stage-panel" title="Close">&times;</button>
    </div>
    <select class="stage-select" ${preSelectStageName ? 'style="display:none"' : ''} disabled><option>Loading stages...</option></select>
    <textarea class="stage-notes" placeholder="Notes (optional)" rows="2"></textarea>
    <div class="stage-panel-buttons">
      <button class="btn-stage-confirm" data-action="confirm-stage-change" disabled>Select a stage</button>
      <button class="btn-stage-confirm-delete" data-action="confirm-stage-change-delete" disabled title="Change stage and delete task">Confirm & Delete</button>
    </div>
  `;

  // Insert panel into task-actions area
  const actionsEl = card.querySelector('.task-actions');
  if (actionsEl) {
    actionsEl.appendChild(panel);
  } else {
    card.appendChild(panel);
  }

  // Fetch stages and populate
  getStagesCached(xanoClient, projectId, stageType).then(stages => {
    const select = panel.querySelector('.stage-select');
    const confirmBtn = panel.querySelector('.btn-stage-confirm');
    const confirmDeleteBtn = panel.querySelector('.btn-stage-confirm-delete');
    const stageList = Array.isArray(stages) ? stages : (stages?.items || stages?.stages || []);

    select.innerHTML = '<option value="">-- Select stage --</option>';
    let preSelectedId = null;
    stageList.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      const isTerminal = s.is_terminal || s.terminal || false;
      opt.textContent = s.name + (isTerminal ? ' (terminal)' : '');
      opt.dataset.terminal = isTerminal ? 'true' : 'false';
      select.appendChild(opt);
      // Check if this stage matches the pre-select name (case-insensitive)
      if (preSelectStageName && s.name.toLowerCase().includes(preSelectStageName.toLowerCase())) {
        preSelectedId = s.id;
      }
    });
    select.disabled = false;

    // If pre-select stage found, auto-select it
    if (preSelectedId) {
      select.value = preSelectedId;
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'Confirm Discard';
      confirmBtn.classList.add('terminal-stage');
      confirmDeleteBtn.disabled = false;
    }

    select.addEventListener('change', () => {
      const selected = select.options[select.selectedIndex];
      if (select.value) {
        confirmBtn.disabled = false;
        confirmDeleteBtn.disabled = false;
        confirmBtn.textContent = 'Confirm';
        if (selected?.dataset.terminal === 'true') {
          confirmBtn.classList.add('terminal-stage');
        } else {
          confirmBtn.classList.remove('terminal-stage');
        }
      } else {
        confirmBtn.disabled = true;
        confirmDeleteBtn.disabled = true;
        confirmBtn.textContent = 'Select a stage';
        confirmBtn.classList.remove('terminal-stage');
      }
    });
  }).catch(err => {
    console.error('Failed to load stages', err);
    const select = panel.querySelector('.stage-select');
    select.innerHTML = '<option>Failed to load stages</option>';
    if (err.message === 'AUTH_EXPIRED') {
      showLoginUI();
      showToast('Session expired', 'error');
    }
  });
}

function buildTaskActions(task, taskType) {
  const isPending = task.status === 'pending';
  const payload = task.payload || {};

  // Normalize task type for comparison
  const normalizedType = (taskType || '').toLowerCase().replace(/\s+/g, '_');
  const isLinkedInOutreach = normalizedType === 'linkedin_outreach' || normalizedType.includes('linkedin');

  // Row 1: Copy message buttons (only for LinkedIn outreach)
  let copyHtml = '';
  if (isLinkedInOutreach) {
    const hasCopyButtons = (payload.message_invite || payload.invite_message) ||
                           (payload.inmail_subject || payload.subject) ||
                           (payload.message_inmail || payload.inmail_body || payload.inmail_message);
    if (hasCopyButtons) {
      copyHtml = '<div class="task-actions-copy">';
      if (payload.message_invite || payload.invite_message) {
        copyHtml += `<button class="task-action-btn btn-helper" data-action="copy-invite" title="Copy invite message">Copy Invite</button>`;
      }
      if (payload.inmail_subject || payload.subject) {
        copyHtml += `<button class="task-action-btn btn-helper" data-action="copy-subject" title="Copy InMail subject">Copy Subject</button>`;
      }
      if (payload.message_inmail || payload.inmail_body || payload.inmail_message) {
        copyHtml += `<button class="task-action-btn btn-helper" data-action="copy-inmail" title="Copy InMail body">Copy InMail</button>`;
      }
      copyHtml += '</div>';
    }
  }

  // Row 2: Auto actions (only for LinkedIn outreach pending tasks)
  let autoHtml = '';
  if (isPending && isLinkedInOutreach) {
    const hasInviteMsg = payload.message_invite || payload.invite_message;
    const hasInMailMsg = payload.message_inmail || payload.inmail_body || payload.inmail_message;
    if (hasInviteMsg || hasInMailMsg) {
      autoHtml = '<div class="task-actions-auto">';
      if (hasInviteMsg) {
        autoHtml += `<button class="task-action-btn btn-auto-action" data-action="auto-connect" title="Auto-connect with invite message">Auto Connect</button>`;
      }
      if (hasInMailMsg) {
        autoHtml += `<button class="task-action-btn btn-auto-action" data-action="auto-message" title="Auto-message with InMail">Auto Message</button>`;
      }
      autoHtml += `<button class="task-action-btn btn-stop" data-action="stop" title="Stop automation">Stop</button>`;
      autoHtml += '</div>';
    }
  }

  // Row 3: Completion actions (Invited/Messaged, Skip, Fail) + Management (Move to Stage, Delete)
  let completionHtml = '';
  if (isPending) {
    completionHtml = '<div class="task-actions-completion">';

    // Success buttons - same for LinkedIn and Manual tasks
    if (isLinkedInOutreach || normalizedType === 'manual_check' || normalizedType.includes('manual') || normalizedType.includes('review')) {
      completionHtml += `<button class="task-action-btn action-success" data-action="complete-invited" title="Mark as invited">Invited</button>`;
      completionHtml += `<button class="task-action-btn action-success" data-action="complete-messaged" title="Mark as messaged">Messaged</button>`;
    }

    // Skip and Fail
    completionHtml += `<button class="task-action-btn action-skip" data-action="skip" title="Skip this task">Skip</button>`;
    completionHtml += `<button class="task-action-btn action-fail" data-action="fail" title="Mark as failed">Fail</button>`;
    completionHtml += '</div>';
  }

  // Row 4: Management actions (Discard, Move to Stage, Delete)
  let managementHtml = '';
  if (isPending) {
    managementHtml = '<div class="task-actions-management">';
    if (task.association?.id) {
      managementHtml += `<button class="task-action-btn btn-discard-action" data-action="discard-task" title="Quick discard">Discard</button>`;
      managementHtml += `<button class="task-action-btn btn-stage-action" data-action="move-to-stage" title="Move to different stage">Move to Stage</button>`;
    }
    managementHtml += `<button class="task-action-btn action-delete" data-action="delete-task" title="Delete task">
      <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
    </button>`;
    managementHtml += '</div>';
  }

  return copyHtml + autoHtml + completionHtml + managementHtml;
}

function attachTaskActionHandlers(card, task, xanoClient) {
  const payload = task.payload || {};
  const person = task.person || {};
  const taskType = getTaskType(task);
  const normalizedType = (taskType || '').toLowerCase().replace(/\s+/g, '_');
  const isLinkedInOutreach = normalizedType === 'linkedin_outreach' || normalizedType.includes('linkedin');
  // Try multiple field names for LinkedIn URL
  const profileUrl = payload.profile_url || payload.linkedin_url || payload.linkedin_profile_url
    || person.linkedin_profile || person.linkedin_url || person.linkedin_profile_url
    || person.profile_url || '';

  card.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;

    const action = btn.dataset.action;
    btn.disabled = true;

    try {
      switch (action) {
        case 'copy-invite': {
          const text = payload.message_invite || payload.invite_message || '';
          if (text) {
            await copyToClipboard(text);
            showToast('Invite message copied', 'success');
          } else {
            showToast('No invite message available', 'error');
          }
          break;
        }

        case 'copy-subject': {
          const text = payload.inmail_subject || payload.subject || '';
          if (text) {
            await copyToClipboard(text);
            showToast('InMail subject copied', 'success');
          } else {
            showToast('No subject available', 'error');
          }
          break;
        }

        case 'copy-inmail': {
          const text = payload.message_inmail || payload.inmail_body || payload.inmail_message || '';
          if (text) {
            await copyToClipboard(text);
            showToast('InMail body copied', 'success');
          } else {
            showToast('No InMail body available', 'error');
          }
          break;
        }

        case 'open-linkedin':
          if (profileUrl) {
            openInLinkedInTab(profileUrl);
          } else {
            showToast('No LinkedIn URL available', 'error');
          }
          break;

        case 'toggle-score-reasons': {
          const panel = card.querySelector('.score-reasons-panel');
          if (panel) {
            panel.classList.toggle('hidden');
            btn.textContent = panel.classList.contains('hidden')
              ? btn.textContent.replace('▴', '▾')
              : btn.textContent.replace('▾', '▴');
          }
          break;
        }

        case 'view-profile': {
          const elasticId = person.elastic_search_id || person.elastic_search_document_id;
          if (elasticId) {
            const personType = task.person_type || person.type;
            const source = personType === 'candidate' ? 'candidates' : 'prospects';
            chrome.tabs.create({ url: `https://bwats.betterway.dev/profile/${elasticId}?source=${source}#activity` });
          } else {
            showToast('No profile ID available', 'error');
          }
          break;
        }

        case 'auto-connect': {
          const inviteMessage = payload.message_invite || payload.invite_message || '';
          if (!profileUrl) {
            showToast('No LinkedIn URL available', 'error');
            break;
          }
          if (!inviteMessage) {
            showToast('No invite message available', 'error');
            break;
          }

          showToast('Starting auto-connect...', 'info');

          try {
            // Check if currently active tab is already on the profile page
            let needsNavigation = true;
            let targetTabId = null;

            // First check active tab
            const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (activeTab && activeTab.url === profileUrl) {
              needsNavigation = false;
              targetTabId = activeTab.id;
              linkedInTabId = activeTab.id;
              showToast('Already on profile page', 'info');
            }

            // If not on active tab, check our tracked LinkedIn tab
            if (needsNavigation && linkedInTabId) {
              try {
                const tab = await chrome.tabs.get(linkedInTabId);
                if (tab && tab.url === profileUrl) {
                  needsNavigation = false;
                  targetTabId = linkedInTabId;
                  showToast('Using existing LinkedIn tab', 'info');
                }
              } catch (e) {
                // Tab no longer exists
                linkedInTabId = null;
              }
            }

            // Navigate to the profile if needed
            if (needsNavigation) {
              await openInLinkedInTab(profileUrl);
              targetTabId = linkedInTabId;
              showToast('Waiting for page to load...', 'info');
              // Wait longer for the page to fully load
              await new Promise(resolve => setTimeout(resolve, 4000));
            } else {
              // Just wait a bit to ensure page is ready
              await new Promise(resolve => setTimeout(resolve, 500));
            }

            // Verify we have a tab ID
            if (!targetTabId) {
              showToast('Failed to get LinkedIn tab', 'error');
              break;
            }

            linkedInTabId = targetTabId;

            const results = await chrome.scripting.executeScript({
              target: { tabId: linkedInTabId },
              func: (message) => {
                const TYPING_MIN_DELAY = 30;
                const TYPING_MAX_DELAY = 80;
                const ACTION_DELAY = 800;

                function randomDelay(min, max) {
                  return Math.floor(Math.random() * (max - min + 1)) + min;
                }

                function sleep(ms) {
                  return new Promise(resolve => setTimeout(resolve, ms));
                }

                // Error reporting to Xano API via background worker
                async function reportError(errorData) {
                  try {
                    const payload = {
                      url: window.location.href,
                      userAgent: navigator.userAgent,
                      ...errorData
                    };

                    // Send to background worker which can make cross-origin requests
                    chrome.runtime.sendMessage({
                      type: 'report-error',
                      payload: payload
                    }, (response) => {
                      if (response?.ok) {
                        console.log('[LinkedComm] Error reported to API successfully');
                      } else {
                        console.error('[LinkedComm] Failed to report error:', response?.error);
                      }
                    });
                  } catch (err) {
                    console.error('[LinkedComm] Failed to send error report message:', err);
                  }
                }

                function isVisible(el) {
                  if (!el) return false;
                  const style = window.getComputedStyle(el);
                  if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
                    return false;
                  }
                  if (el.offsetParent === null && style.position !== 'fixed') {
                    return false;
                  }
                  const rect = el.getBoundingClientRect();
                  return rect.width > 0 && rect.height > 0;
                }

                async function waitForVisible(finder, timeout = 10000) {
                  const startTime = Date.now();
                  while (Date.now() - startTime < timeout) {
                    const element = typeof finder === 'function' ? finder() : document.querySelector(finder);
                    if (element && isVisible(element)) {
                      return element;
                    }
                    await sleep(150);
                  }
                  return null;
                }

                async function humanType(element, text) {
                  element.focus({ preventScroll: true });
                  for (const char of text) {
                    const inputEvent = new InputEvent('input', {
                      data: char,
                      inputType: 'insertText',
                      bubbles: true
                    });
                    element.value += char;
                    element.dispatchEvent(inputEvent);
                    await sleep(randomDelay(TYPING_MIN_DELAY, TYPING_MAX_DELAY));
                  }
                  element.dispatchEvent(new Event('change', { bubbles: true }));
                }

                function clickElement(element) {
                  console.log('[LinkedComm] Clicking element:', element.tagName, element.getAttribute('aria-label') || element.textContent?.trim().substring(0,30));

                  // Get element position for realistic mouse events
                  const rect = element.getBoundingClientRect();
                  const x = rect.left + rect.width / 2;
                  const y = rect.top + rect.height / 2;

                  console.log('[LinkedComm] Element position - x:', Math.round(x), 'y:', Math.round(y), 'width:', rect.width, 'height:', rect.height);

                  const eventInit = {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    clientX: x,
                    clientY: y,
                    screenX: x + window.screenX,
                    screenY: y + window.screenY,
                    button: 0,
                    buttons: 1
                  };

                  // Focus first (without scrolling)
                  element.focus({ preventScroll: true });

                  // Full mouse event sequence (this is what worked before!)
                  element.dispatchEvent(new MouseEvent('mouseenter', eventInit));
                  element.dispatchEvent(new MouseEvent('mouseover', eventInit));
                  element.dispatchEvent(new MouseEvent('mousedown', { ...eventInit, buttons: 1 }));
                  element.dispatchEvent(new MouseEvent('mouseup', eventInit));
                  element.dispatchEvent(new MouseEvent('click', eventInit));

                  // Also try native click
                  element.click();

                  // For div[role="button"], also try Enter key
                  if (element.getAttribute('role') === 'button') {
                    element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                    element.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                    element.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                  }

                  // For div[role="button"] or role="menuitem", also try Enter key
                  const role = element.getAttribute('role');
                  if (role === 'button' || role === 'menuitem') {
                    element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                    element.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                    element.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                  }
                }

                // IMPORTANT: Exclude buttons with artdeco-button--muted class (sidebar "People also viewed" buttons)
                function findConnectButton() {
                  // CRITICAL: Only search within the main profile top card to avoid clicking Connect from "People similar to..." sections
                  // First, find the main profile container
                  console.log('[LinkedComm] Finding main profile container...');

                  let mainProfileContainer = null;

                  // Try to find container with profile action buttons (Message, View in Recruiter, More, Connect)
                  const actionContainers = document.querySelectorAll('[data-view-name*="profile-primary"], [data-view-name*="profile-overflow"], [data-view-name*="relationship-building"]');
                  if (actionContainers.length > 0) {
                    // Find the common ancestor of these action buttons (should be the main profile area)
                    mainProfileContainer = actionContainers[0].closest('[class*="_01245026"]') || actionContainers[0].closest('section') || actionContainers[0].parentElement?.parentElement;
                    console.log('[LinkedComm] Found profile container via action buttons');
                  }

                  // Fallback: Find by top card classes
                  if (!mainProfileContainer) {
                    mainProfileContainer = document.querySelector('[class*="pv-top-card"], [class*="profile-top-card"], main > section:first-of-type, main > div:first-of-type');
                    console.log('[LinkedComm] Found profile container via top card classes');
                  }

                  if (!mainProfileContainer) {
                    console.log('[LinkedComm] ⚠ Could not find main profile container, will search carefully');
                    mainProfileContainer = document.body;
                  }

                  console.log('[LinkedComm] Searching for Connect button/element in main profile container only...');

                  // Search for Connect in various forms: <button>, <div role="button">, <a> (if doesn't navigate)
                  const selectors = [
                    'button[aria-label*="connect" i]',
                    'button[aria-label*="Invite" i]',
                    '[role="button"][aria-label*="connect" i]',
                    '[role="button"][aria-label*="Invite" i]',
                    'a[aria-label*="connect" i]',
                    'a[aria-label*="Invite" i]'
                  ];

                  const allConnectElements = mainProfileContainer.querySelectorAll(selectors.join(', '));

                  console.log(`[LinkedComm] Found ${allConnectElements.length} Connect elements in main profile container`);

                  for (const elem of allConnectElements) {
                    const label = elem.getAttribute('aria-label') || '';
                    const href = elem.getAttribute('href') || '';
                    const tagName = elem.tagName.toLowerCase();

                    console.log(`[LinkedComm]   ${tagName.toUpperCase()}: "${label.substring(0, 50)}", href="${href.substring(0, 30)}", visible=${isVisible(elem)}`);

                    if (!isVisible(elem)) continue;

                    // Return the first visible Connect element found in main profile
                    // LinkedIn handles click behavior (might open modal via JS or navigate)
                    console.log('[LinkedComm] ✓ Found Connect element in main profile');
                    return elem;
                  }

                  console.log('[LinkedComm] No Connect button in main profile - will use More button instead');
                  return null;
                }

                // Find More button (ONLY in main profile area - never in "People similar to..." sections)
                function findMoreButton() {
                  console.log('[LinkedComm] Finding More button in main profile container...');

                  // Find main profile container first
                  let mainProfileContainer = null;

                  // Look for profile-overflow-button which is the More button's data-view-name
                  const overflowContainer = document.querySelector('[data-view-name="profile-overflow-button"]');
                  if (overflowContainer) {
                    mainProfileContainer = overflowContainer.closest('[class*="_01245026"]') || overflowContainer.parentElement?.parentElement;
                    console.log('[LinkedComm] Found profile container via overflow button');
                  }

                  // Fallback: Find by top card classes
                  if (!mainProfileContainer) {
                    mainProfileContainer = document.querySelector('[class*="pv-top-card"], [class*="profile-top-card"], main > section:first-of-type, main > div:first-of-type');
                    console.log('[LinkedComm] Found profile container via top card classes');
                  }

                  if (!mainProfileContainer) {
                    console.log('[LinkedComm] ⚠ Could not find main profile container for More button');
                    mainProfileContainer = document.body;
                  }

                  // Primary: aria-label="More"
                  const byAriaLabel = mainProfileContainer.querySelector('button[aria-label="More"]');
                  if (byAriaLabel && isVisible(byAriaLabel)) {
                    console.log('[LinkedComm] ✓ Found More button by aria-label');
                    return byAriaLabel;
                  }

                  // Secondary: aria-label contains "More"
                  const byPartialLabel = mainProfileContainer.querySelector('button[aria-label*="More"]');
                  if (byPartialLabel && isVisible(byPartialLabel)) {
                    console.log('[LinkedComm] ✓ Found More button by partial aria-label');
                    return byPartialLabel;
                  }

                  // Tertiary: text content (only in main profile container)
                  const allBtns = mainProfileContainer.querySelectorAll('button');
                  for (const btn of allBtns) {
                    const txt = btn.textContent?.trim();
                    if ((txt === 'More' || txt === 'More…' || txt === 'More...') && isVisible(btn)) {
                      console.log('[LinkedComm] ✓ Found More button by text content');
                      return btn;
                    }
                  }

                  console.log('[LinkedComm] No More button found in main profile');
                  return null;
                }

                function findConnectInDropdown() {
                  // First, find the opened dropdown/menu container
                  let dropdown = document.querySelector('[role="menu"]');
                  if (!dropdown) {
                    dropdown = document.querySelector('.artdeco-dropdown__content[aria-hidden="false"]');
                  }

                  if (!dropdown) {
                    console.log('[LinkedComm] No opened dropdown/menu found');
                    return null;
                  }

                  console.log('[LinkedComm] Searching within opened dropdown/menu...');

                  // Look for Connect menuitem - LinkedIn uses <a role="menuitem"> with href="/preload/custom-invite/"
                  const menuitems = dropdown.querySelectorAll('[role="menuitem"]');
                  console.log(`[LinkedComm] Found ${menuitems.length} menuitems`);

                  for (const item of menuitems) {
                    const text = item.textContent?.trim().toLowerCase();
                    const href = item.getAttribute('href') || '';

                    console.log(`[LinkedComm]   Menuitem: text="${text}", href="${href.substring(0, 40)}"`);

                    if ((text === 'connect' || href.includes('custom-invite')) && isVisible(item)) {
                      console.log('[LinkedComm] ✓ Found Connect in dropdown menu');
                      return item;
                    }
                  }

                  // Fallback: look for other dropdown item types
                  const fallbackSelectors = [
                    '.artdeco-dropdown__item',
                    'a[href*="custom-invite"]',
                    'li > a'
                  ];

                  for (const selector of fallbackSelectors) {
                    const items = dropdown.querySelectorAll(selector);
                    console.log(`[LinkedComm] Fallback checking ${items.length} items with selector: ${selector}`);

                    for (const item of items) {
                      const label = item.getAttribute('aria-label')?.toLowerCase() || '';
                      const text = item.textContent?.trim().toLowerCase();
                      const href = item.getAttribute('href') || '';

                      if ((label.includes('connect') || text === 'connect' || href.includes('custom-invite')) &&
                          !label.includes('message') && isVisible(item)) {
                        console.log('[LinkedComm] ✓ Found Connect in dropdown (fallback):', text || label);
                        return item;
                      }
                    }
                  }

                  return null;
                }

                // Find Add a note button (searches Shadow DOM where LinkedIn renders modals)
                function findAddNoteButton() {
                  console.log('[LinkedComm] Searching for Add note button...');

                  // LinkedIn renders modals in Shadow DOM inside #interop-outlet
                  const interopOutlet = document.getElementById('interop-outlet');
                  const shadowRoot = interopOutlet?.shadowRoot;

                  console.log(`[LinkedComm] interop-outlet: ${!!interopOutlet}, shadowRoot: ${!!shadowRoot}`);

                  if (shadowRoot) {
                    // Search inside Shadow DOM
                    console.log('[LinkedComm] Searching in Shadow DOM...');

                    // Direct search by aria-label
                    let btn = shadowRoot.querySelector('button[aria-label="Add a note"]');
                    if (btn) {
                      console.log('[LinkedComm] ✓ Found in Shadow DOM by aria-label');
                      return btn;
                    }

                    // Search by text content
                    const allBtns = shadowRoot.querySelectorAll('button');
                    console.log(`[LinkedComm] Found ${allBtns.length} buttons in Shadow DOM`);

                    for (const b of allBtns) {
                      const label = b.getAttribute('aria-label')?.toLowerCase() || '';
                      const text = b.textContent?.trim().toLowerCase() || '';
                      console.log(`[LinkedComm] Button: label="${label}", text="${text}"`);
                      if (label.includes('add') && label.includes('note')) {
                        console.log('[LinkedComm] ✓ Found in Shadow DOM by label');
                        return b;
                      }
                      if (text === 'add a note' || text === 'add note') {
                        console.log('[LinkedComm] ✓ Found in Shadow DOM by text');
                        return b;
                      }
                    }

                    // Check for modal in shadow DOM
                    const modal = shadowRoot.querySelector('.artdeco-modal, [data-test-modal-id="send-invite-modal"]');
                    console.log(`[LinkedComm] Modal in Shadow DOM: ${!!modal}`);
                  }

                  // Search main document + React Portals (LinkedIn renders modal in detached DOM)
                  console.log('[LinkedComm] Searching in main document + all portals...');

                  // Search ALL elements including React Portals
                  const allElements = document.querySelectorAll('*');
                  console.log(`[LinkedComm] Searching ${allElements.length} total elements`);

                  // First try to find the modal container
                  for (const el of allElements) {
                    const style = window.getComputedStyle(el);
                    const text = el.textContent || '';

                    // Check if this is the invite modal (visible element containing modal text)
                    if (style.display !== 'none' &&
                        style.visibility !== 'hidden' &&
                        text.includes('Add a note to your invitation')) {
                      console.log('[LinkedComm] ✓ Found modal container!');

                      // Search buttons in this modal container
                      const modalContainer = el.closest('div[role="dialog"]') || el.parentElement || el;
                      const buttons = modalContainer.querySelectorAll('button');
                      console.log(`[LinkedComm] Found ${buttons.length} buttons in modal`);

                      for (const btn of buttons) {
                        const btnLabel = btn.getAttribute('aria-label')?.toLowerCase() || '';
                        const btnText = btn.textContent?.trim().toLowerCase() || '';
                        console.log(`[LinkedComm]   Modal button: label="${btnLabel}", text="${btnText}"`);

                        if ((btnLabel.includes('add') && btnLabel.includes('note')) ||
                            btnText === 'add a note' || btnText === 'add note') {
                          console.log('[LinkedComm] ✓ Found Add Note button in portal!');
                          return btn;
                        }
                      }
                    }
                  }

                  // Fallback: direct button search
                  const allBtns = document.querySelectorAll('button');
                  console.log(`[LinkedComm] Fallback: searching ${allBtns.length} buttons`);

                  for (const b of allBtns) {
                    const label = b.getAttribute('aria-label')?.toLowerCase() || '';
                    const text = b.textContent?.trim().toLowerCase() || '';
                    if ((label.includes('add') && label.includes('note')) || text === 'add a note' || text === 'add note') {
                      console.log(`[LinkedComm] ✓ Found in fallback: label="${label}", text="${text}"`);
                      return b;
                    }
                  }

                  console.log('[LinkedComm] Add note button not found');
                  return null;
                }

                // Find textarea in modal (searches Shadow DOM)
                function findTextarea() {
                  const selectors = ['textarea#custom-message', 'textarea[name="message"]', '.artdeco-modal textarea', 'textarea'];

                  // First search in Shadow DOM
                  const interopOutlet = document.getElementById('interop-outlet');
                  const shadowRoot = interopOutlet?.shadowRoot;

                  if (shadowRoot) {
                    for (const selector of selectors) {
                      const el = shadowRoot.querySelector(selector);
                      if (el) {
                        console.log('[LinkedComm] Found textarea in Shadow DOM');
                        return el;
                      }
                    }
                  }

                  // Fallback: search main document
                  for (const selector of selectors) {
                    const el = document.querySelector(selector);
                    if (el && isVisible(el)) return el;
                  }
                  return null;
                }

                return (async () => {
                  // Track click state for error reporting
                  let clickDebugInfo = {
                    connectButtonFound: false,
                    connectButtonType: null,
                    connectButtonHref: null,
                    connectButtonLabel: null,
                    urlBefore: null,
                    urlAfter: null,
                    modalsAfterClick: 0,
                    overlaysAfterClick: 0,
                    shadowModalsAfterClick: 0
                  };

                  try {
                    console.log('[LinkedComm] Starting auto-connect...');
                    await sleep(500);

                    // Check if we're already on the custom-invite page
                    if (window.location.pathname.includes('custom-invite') || window.location.pathname.includes('preload/custom-invite')) {
                      console.log('[LinkedComm] Already on custom-invite page, looking for textarea...');

                      const textarea = await waitForVisible(findTextarea, 5000);
                      if (textarea) {
                        console.log('[LinkedComm] Found textarea on invite page, typing message...');
                        await humanType(textarea, message);
                        console.log('[LinkedComm] Done! Message typed on invite page.');
                        return { success: true, message: 'Message typed on invite page! Click Send to complete.' };
                      } else {
                        throw new Error('Textarea not found on custom-invite page');
                      }
                    }

                    let connectBtn = findConnectButton();
                    if (!connectBtn) {
                      console.log('[LinkedComm] Connect not in primary area, trying More dropdown...');
                      const moreBtn = findMoreButton();
                      if (!moreBtn) throw new Error('Neither Connect nor More button found');

                      console.log('[LinkedComm] Clicking More button...');
                      clickElement(moreBtn);
                      await sleep(1000); // 1 second after clicking More

                      // Check if dropdown opened
                      if (moreBtn.getAttribute('aria-expanded') !== 'true') {
                        console.log('[LinkedComm] Dropdown may not have opened, trying anyway...');
                      } else {
                        console.log('[LinkedComm] Dropdown opened');
                      }

                      connectBtn = await waitForVisible(findConnectInDropdown, 5000);
                      if (!connectBtn) {
                        const items = document.querySelectorAll('.artdeco-dropdown__item');
                        console.log('[LinkedComm] Dropdown items:', items.length);
                        items.forEach((item, i) => console.log(`[LinkedComm]   ${i}: ${item.getAttribute('aria-label')}`));
                        throw new Error('Connect not found in More dropdown');
                      }

                      console.log('[LinkedComm] ✓ Found Connect in dropdown, will click it');
                    }

                    // Step 2: Click Connect button (may open modal or navigate to new page)
                    clickDebugInfo.connectButtonFound = true;
                    clickDebugInfo.connectButtonType = connectBtn.tagName;
                    clickDebugInfo.connectButtonHref = connectBtn.getAttribute('href');
                    clickDebugInfo.connectButtonLabel = connectBtn.getAttribute('aria-label');
                    clickDebugInfo.urlBefore = window.location.href;

                    console.log('[LinkedComm] Clicking Connect button...');
                    console.log('[LinkedComm] Connect button type:', clickDebugInfo.connectButtonType,
                                'href:', clickDebugInfo.connectButtonHref,
                                'aria-label:', clickDebugInfo.connectButtonLabel);
                    console.log('[LinkedComm] URL before click:', clickDebugInfo.urlBefore);
                    clickElement(connectBtn);
                    await sleep(2000); // Wait for modal or navigation

                    // Check if page navigated
                    clickDebugInfo.urlAfter = window.location.href;
                    console.log('[LinkedComm] URL after click:', clickDebugInfo.urlAfter);

                    if (clickDebugInfo.urlAfter !== clickDebugInfo.urlBefore) {
                      console.log('[LinkedComm] Page navigated! Now on:', clickDebugInfo.urlAfter);
                      // We're on a new page - look for the form directly
                      await sleep(1000); // Wait for new page to render
                    } else {
                      // Check what's in the DOM after click (if no navigation)
                      const modals = document.querySelectorAll('[role="dialog"], .artdeco-modal');
                      const overlays = document.querySelectorAll('.artdeco-modal__overlay, [class*="overlay"]');
                      clickDebugInfo.modalsAfterClick = modals.length;
                      clickDebugInfo.overlaysAfterClick = overlays.length;

                      console.log('[LinkedComm] After click - Modals found:', clickDebugInfo.modalsAfterClick, 'Overlays:', clickDebugInfo.overlaysAfterClick);

                      // Check Shadow DOM for modals
                      const interopOutlet = document.getElementById('interop-outlet');
                      if (interopOutlet?.shadowRoot) {
                        const shadowModals = interopOutlet.shadowRoot.querySelectorAll('[role="dialog"], .artdeco-modal');
                        clickDebugInfo.shadowModalsAfterClick = shadowModals.length;
                        console.log('[LinkedComm] Shadow DOM modals found:', clickDebugInfo.shadowModalsAfterClick);
                      }
                    }

                    console.log('[LinkedComm] Waiting for Add a note button...');
                    const addNoteBtn = await waitForVisible(findAddNoteButton, 8000);
                    if (!addNoteBtn) {
                      // Capture DOM state for error reporting
                      const allButtons = Array.from(document.querySelectorAll('button'));
                      const buttonInfo = allButtons.slice(0, 20).map(b => ({
                        label: b.getAttribute('aria-label') || '',
                        text: b.textContent?.trim().substring(0, 50) || '',
                        visible: isVisible(b)
                      }));

                      const interopOutlet = document.getElementById('interop-outlet');
                      const shadowButtons = interopOutlet?.shadowRoot ?
                        Array.from(interopOutlet.shadowRoot.querySelectorAll('button')).slice(0, 10).map(b => ({
                          label: b.getAttribute('aria-label') || '',
                          text: b.textContent?.trim().substring(0, 50) || ''
                        })) : [];

                      await reportError({
                        error: 'Add a note button not found - invitation modal may not have opened',
                        step: 'waiting_for_add_note_button',
                        clickDebug: clickDebugInfo,
                        mainDocumentButtons: buttonInfo,
                        shadowDomButtons: shadowButtons,
                        hasShadowRoot: !!interopOutlet?.shadowRoot,
                        totalButtons: allButtons.length
                      });

                      throw new Error('Add a note button not found - invitation modal may not have opened');
                    }

                    console.log('[LinkedComm] Clicking Add a note...');
                    clickElement(addNoteBtn);
                    await sleep(1000); // 1 second after clicking Add a note

                    console.log('[LinkedComm] Waiting for textarea...');
                    const textarea = await waitForVisible(findTextarea, 5000);
                    if (!textarea) throw new Error('Textarea not found');

                    console.log('[LinkedComm] Typing message...');
                    await humanType(textarea, message);

                    console.log('[LinkedComm] Done! Message typed.');
                    return { success: true, message: 'Message typed! Click Send to complete.' };
                  } catch (error) {
                    console.error('[LinkedComm] Error:', error.message);
                    return { success: false, message: error.message };
                  }
                })();
              },
              args: [inviteMessage]
            });

            const result = results?.[0]?.result;
            if (result?.success) {
              showToast(result.message, 'success');
            } else {
              showToast(result?.message || 'Auto-connect failed', 'error');
            }
          } catch (error) {
            console.error('Auto-connect error:', error);
            showToast('Auto-connect failed: ' + error.message, 'error');
          }
          break;
        }

        case 'auto-message': {
          const inMailSubject = payload.inmail_subject || payload.subject || '';
          const inMailBody = payload.message_inmail || payload.inmail_body || payload.inmail_message || '';
          if (!profileUrl) {
            showToast('No LinkedIn URL available', 'error');
            break;
          }
          if (!inMailBody) {
            showToast('No InMail message available', 'error');
            break;
          }

          showToast('Starting auto-message...', 'info');

          try {
            let needsNavigation = true;
            let targetTabId = null;
            const targetSlug = getLinkedInSlug(profileUrl);

            const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const activeSlug = getLinkedInSlug(activeTab?.url);
            if (activeTab && targetSlug && activeSlug === targetSlug) {
              needsNavigation = false;
              targetTabId = activeTab.id;
              linkedInTabId = activeTab.id;
            }

            if (needsNavigation) {
              await openInLinkedInTab(profileUrl);
              targetTabId = linkedInTabId;
              showToast('Waiting for page to load...', 'info');
              await new Promise(resolve => setTimeout(resolve, 4000));
            } else {
              await new Promise(resolve => setTimeout(resolve, 500));
            }

            if (!targetTabId) {
              showToast('Failed to get LinkedIn tab', 'error');
              break;
            }

            linkedInTabId = targetTabId;

            const results = await chrome.scripting.executeScript({
              target: { tabId: linkedInTabId },
              func: (subject, body) => {
                const TYPING_MIN_DELAY = 30;
                const TYPING_MAX_DELAY = 80;

                function randomDelay(min, max) {
                  return Math.floor(Math.random() * (max - min + 1)) + min;
                }

                function sleep(ms) {
                  return new Promise(resolve => setTimeout(resolve, ms));
                }

                function isVisible(el) {
                  if (!el) return false;
                  const style = window.getComputedStyle(el);
                  if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                  if (el.offsetParent === null && style.position !== 'fixed') return false;
                  const rect = el.getBoundingClientRect();
                  return rect.width > 0 && rect.height > 0;
                }

                async function waitForVisible(finder, timeout = 10000) {
                  const startTime = Date.now();
                  while (Date.now() - startTime < timeout) {
                    const element = typeof finder === 'function' ? finder() : document.querySelector(finder);
                    if (element && isVisible(element)) return element;
                    await sleep(150);
                  }
                  return null;
                }

                async function humanType(element, text) {
                  element.focus();
                  for (const char of text) {
                    if (element.tagName === 'INPUT') {
                      element.value += char;
                    } else {
                      const inserted = document.execCommand('insertText', false, char);
                      if (!inserted) {
                        const textTarget = element.querySelector('p') || element;
                        if (textTarget.lastChild && textTarget.lastChild.nodeType === 3) {
                          textTarget.lastChild.textContent += char;
                        } else if (textTarget.lastChild && textTarget.lastChild.nodeName === 'BR') {
                          textTarget.insertBefore(document.createTextNode(char), textTarget.lastChild);
                        } else {
                          textTarget.appendChild(document.createTextNode(char));
                        }
                        const sel = window.getSelection();
                        const range = document.createRange();
                        range.selectNodeContents(textTarget);
                        range.collapse(false);
                        sel.removeAllRanges();
                        sel.addRange(range);
                      }
                    }
                    element.dispatchEvent(new InputEvent('input', {
                      data: char,
                      inputType: 'insertText',
                      bubbles: true
                    }));
                    await sleep(randomDelay(TYPING_MIN_DELAY, TYPING_MAX_DELAY));
                  }
                  element.dispatchEvent(new Event('change', { bubbles: true }));
                }

                function clickElement(element) {
                  element.click();
                }

                function findMessageButton() {
                  const byAriaLabel = document.querySelector('button[aria-label*="Message"]:not(.artdeco-button--muted)');
                  if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;

                  const primaryBtns = document.querySelectorAll('button.artdeco-button--primary:not(.artdeco-button--muted)');
                  for (const btn of primaryBtns) {
                    if (btn.textContent?.trim() === 'Message' && isVisible(btn)) return btn;
                  }
                  return null;
                }

                function findMoreButton() {
                  const byAriaLabel = document.querySelector('button[aria-label="More actions"]');
                  if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
                  const byPartialLabel = document.querySelector('button[aria-label*="More"]');
                  if (byPartialLabel && isVisible(byPartialLabel)) return byPartialLabel;
                  const allBtns = document.querySelectorAll('button');
                  for (const btn of allBtns) {
                    const txt = btn.textContent?.trim();
                    if ((txt === 'More' || txt === 'More…' || txt === 'More...') && isVisible(btn)) return btn;
                  }
                  return null;
                }

                function findMessageInDropdown() {
                  const selectors = ['.artdeco-dropdown__item[aria-label*="Message"]', '[role="menuitem"][aria-label*="Message"]', '[role="button"][aria-label*="Message"]', '.artdeco-dropdown__item'];
                  for (const selector of selectors) {
                    const items = document.querySelectorAll(selector);
                    for (const item of items) {
                      const label = item.getAttribute('aria-label')?.toLowerCase() || '';
                      const text = item.textContent?.trim().toLowerCase();
                      if ((label.includes('message') || text === 'message') && isVisible(item)) return item;
                    }
                  }
                  return null;
                }

                // Find message compose elements (supports both premium bubble and recruiter page)
                // Find visible element - picks the last visible match (most recently opened bubble)
                function findVisible(selector) {
                  const all = document.querySelectorAll(selector);
                  let lastVisible = null;
                  for (const el of all) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                      const style = window.getComputedStyle(el);
                      if (style.display !== 'none' && style.visibility !== 'hidden') {
                        lastVisible = el;
                      }
                    }
                  }
                  return lastVisible;
                }

                function findSubjectInput() {
                  const selectors = [
                    'input[placeholder="Subject (optional)"]',
                    'input[placeholder="Add a subject"]',
                    'input[name="subject"]',
                    '.msg-form__subject input',
                    '.compose-subject__input',
                    'input[data-test-compose-subject-input]',
                    'input[placeholder*="Subject"]'
                  ];
                  for (const sel of selectors) {
                    const el = findVisible(sel);
                    if (el) return el;
                  }
                  return null;
                }

                function findMessageContentEditable() {
                  const selectors = [
                    'div[contenteditable="true"][aria-label="Write a message…"]',
                    'div[aria-label="Write a message…"]',
                    'div.msg-form__contenteditable',
                    '.ql-editor[contenteditable="true"]',
                    'div[data-placeholder="Compose a message"]',
                    'div[aria-label="Compose a message"]',
                    'div[role="textbox"][contenteditable="true"]'
                  ];
                  for (const sel of selectors) {
                    const el = findVisible(sel);
                    if (el) return el;
                  }
                  return null;
                }

                return (async () => {
                  try {
                    console.log('[LinkedComm] Starting auto-message...');
                    console.log('[LinkedComm] Current URL:', window.location.href);
                    await sleep(500);

                    // Check if we're already on recruiter page with composer open
                    const isRecruiterPage = window.location.href.includes('/talent/');
                    if (isRecruiterPage) {
                      console.log('[LinkedComm] On recruiter page, looking for existing composer...');
                    }

                    // Step 1: Find Message button (skip if on recruiter with composer)
                    let messageBtn = null;
                    if (!isRecruiterPage) {
                      messageBtn = findMessageButton();
                      if (!messageBtn) {
                        console.log('[LinkedComm] Message not in primary area, trying More dropdown...');
                        const moreBtn = findMoreButton();
                        if (!moreBtn) throw new Error('Neither Message nor More button found');

                        console.log('[LinkedComm] Clicking More button...');
                        clickElement(moreBtn);
                        await sleep(1000);

                        messageBtn = await waitForVisible(findMessageInDropdown, 5000);
                        if (!messageBtn) throw new Error('Message not found in More dropdown');
                      }

                      console.log('[LinkedComm] Clicking Message button...');
                      clickElement(messageBtn);
                      await sleep(1000);
                    }

                    console.log('[LinkedComm] Waiting for message compose UI...');

                    // Simple wait loop - just check if element exists
                    let contentEditable = null;
                    const maxWait = window.location.href.includes('/talent/') ? 15000 : 8000;
                    const startTime = Date.now();
                    while (Date.now() - startTime < maxWait) {
                      contentEditable = findMessageContentEditable();
                      if (contentEditable) break;
                      await sleep(200);
                    }

                    if (!contentEditable) {
                      throw new Error('Message compose area not found');
                    }

                    if (subject) {
                      await sleep(300);
                      const subjectInput = findSubjectInput();
                      if (subjectInput) {
                        console.log('[LinkedComm] Typing subject...');
                        await humanType(subjectInput, subject);
                        await sleep(500);
                      }
                    }

                    console.log('[LinkedComm] Typing message body...');
                    // Place cursor inside contenteditable
                    contentEditable.focus();
                    const sel = window.getSelection();
                    const range = document.createRange();
                    range.selectNodeContents(contentEditable);
                    range.collapse(false);
                    sel.removeAllRanges();
                    sel.addRange(range);
                    await sleep(300);
                    await humanType(contentEditable, body);

                    console.log('[LinkedComm] Done! Message typed.');
                    return { success: true, message: 'Message typed! Click Send to complete.' };
                  } catch (error) {
                    console.error('[LinkedComm] Error:', error.message);
                    return { success: false, message: error.message };
                  }
                })();
              },
              args: [inMailSubject, inMailBody]
            });

            const result = results?.[0]?.result;
            if (result?.success) {
              showToast(result.message, 'success');
            } else {
              showToast(result?.message || 'Auto-message failed', 'error');
            }
          } catch (error) {
            console.error('Auto-message error:', error);
            showToast('Auto-message failed: ' + error.message, 'error');
          }
          break;
        }

        case 'stop': {
          // Nuclear option: reload the LinkedIn tab to stop all running scripts
          if (linkedInTabId) {
            try {
              await chrome.tabs.reload(linkedInTabId);
              showToast('Stopped - LinkedIn tab reloaded', 'info');
            } catch (e) {
              showToast('No LinkedIn tab to stop', 'warning');
            }
          } else {
            // Try to find and reload any LinkedIn tab
            const linkedInTabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
            if (linkedInTabs.length > 0) {
              await chrome.tabs.reload(linkedInTabs[0].id);
              showToast('Stopped - LinkedIn tab reloaded', 'info');
            } else {
              showToast('No LinkedIn tab found', 'warning');
            }
          }
          break;
        }

        case 'complete-invited':
          if (isLinkedInOutreach) {
            await xanoClient.completeLinkedInOutreach(currentAuthToken, {
              taskId: task.id,
              status: 'done',
              actionType: 'invited',
            });
          } else {
            await xanoClient.completeMessagingTask(currentAuthToken, {
              taskId: task.id,
              status: 'done',
              result: 'invited',
            });
          }
          removeTaskCard(card);
          showToast('Marked as Invited', 'success');
          loadInvitationCounts(xanoClient);
          break;

        case 'complete-messaged':
          if (isLinkedInOutreach) {
            await xanoClient.completeLinkedInOutreach(currentAuthToken, {
              taskId: task.id,
              status: 'done',
              actionType: 'messaged',
            });
          } else {
            await xanoClient.completeMessagingTask(currentAuthToken, {
              taskId: task.id,
              status: 'done',
              result: 'messaged',
            });
          }
          removeTaskCard(card);
          showToast('Marked as Messaged', 'success');
          break;

        case 'complete-review':
          await xanoClient.completeMessagingTask(currentAuthToken, {
            taskId: task.id,
            status: 'done',
            result: 'reviewed_and_approved',
          });
          removeTaskCard(card);
          showToast('Review completed', 'success');
          break;

        case 'skip':
          if (isLinkedInOutreach) {
            await xanoClient.completeLinkedInOutreach(currentAuthToken, {
              taskId: task.id,
              status: 'skipped',
            });
          } else {
            await xanoClient.completeMessagingTask(currentAuthToken, {
              taskId: task.id,
              status: 'skipped',
            });
          }
          removeTaskCard(card);
          showToast('Task skipped');
          break;

        case 'fail':
          if (isLinkedInOutreach) {
            await xanoClient.completeLinkedInOutreach(currentAuthToken, {
              taskId: task.id,
              status: 'failed',
              actionType: 'failed',
            });
          } else {
            await xanoClient.completeMessagingTask(currentAuthToken, {
              taskId: task.id,
              status: 'failed',
              result: 'failed',
            });
          }
          removeTaskCard(card);
          showToast('Task marked as failed');
          break;

        case 'discard-task':
          renderStagePanel(card, task, xanoClient, 'discard');
          break;

        case 'move-to-stage':
          renderStagePanel(card, task, xanoClient);
          break;

        case 'close-stage-panel': {
          const panel = card.querySelector('.stage-panel');
          if (panel) panel.remove();
          break;
        }

        case 'confirm-stage-change': {
          const stageSelect = card.querySelector('.stage-select');
          const notesEl = card.querySelector('.stage-notes');
          const stageId = stageSelect?.value;
          const notes = notesEl?.value?.trim() || '';
          const associationId = task.association?.id;
          if (!stageId) {
            showToast('Please select a stage', 'error');
            break;
          }
          await xanoClient.changeAssociationStage(currentAuthToken, { associationId, stageId: Number(stageId), notes });
          const panel = card.querySelector('.stage-panel');
          if (panel) panel.remove();
          showToast('Moved to stage successfully', 'success');
          break;
        }

        case 'confirm-stage-change-delete': {
          const stageSelect = card.querySelector('.stage-select');
          const notesEl = card.querySelector('.stage-notes');
          const stageId = stageSelect?.value;
          const notes = notesEl?.value?.trim() || '';
          const associationId = task.association?.id;
          if (!stageId) {
            showToast('Please select a stage', 'error');
            break;
          }
          // Change stage first
          await xanoClient.changeAssociationStage(currentAuthToken, { associationId, stageId: Number(stageId), notes });
          // Then skip the task (removes it from queue)
          if (isLinkedInOutreach) {
            await xanoClient.completeLinkedInOutreach(currentAuthToken, {
              taskId: task.id,
              status: 'skipped',
            });
          } else {
            await xanoClient.completeMessagingTask(currentAuthToken, {
              taskId: task.id,
              status: 'skipped',
            });
          }
          removeTaskCard(card);
          showToast('Stage changed and task removed', 'success');
          break;
        }

        case 'delete-task': {
          const personName = task.person?.name || task.person?.first_name || 'this person';
          if (!confirm(`Delete task for ${personName}? This cannot be undone.`)) {
            break;
          }
          await xanoClient.deleteTask(currentAuthToken, task.id);
          removeTaskCard(card);
          showToast('Task deleted', 'success');
          break;
        }
      }
    } catch (error) {
      console.error('Task action failed', error);
      if (error.message === 'AUTH_EXPIRED') {
        showLoginUI();
        showToast('Session expired', 'error');
        return;
      }
      showToast('Action failed: ' + (error.message || 'Unknown error'), 'error');
    } finally {
      btn.disabled = false;
    }
  });
}

function removeTaskCard(card) {
  card.style.opacity = '0.3';
  setTimeout(() => {
    card.remove();
    // Update pending count
    const pendingCountEl = document.getElementById('task-pending-count');
    if (pendingCountEl) {
      const current = parseInt(pendingCountEl.textContent, 10);
      if (!isNaN(current) && current > 0) {
        pendingCountEl.textContent = String(current - 1);
      }
    }
    const totalCountEl = document.getElementById('task-total-count');
    if (totalCountEl) {
      const current = parseInt(totalCountEl.textContent, 10);
      if (!isNaN(current) && current > 0) {
        totalCountEl.textContent = String(current - 1);
      }
    }
  }, 300);
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    // Fallback
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
  }
}

// ---- Task Polling ----
function startTaskPolling(xanoClient) {
  stopTaskPolling();
  taskPollInterval = setInterval(() => {
    loadTasks(xanoClient);
  }, 900000); // 15 minutes
}

function stopTaskPolling() {
  if (taskPollInterval) {
    clearInterval(taskPollInterval);
    taskPollInterval = null;
  }
}

// ---- Task Filters & Pagination ----
async function populateProjectFilter(xanoClient) {
  const projectFilter = document.getElementById('task-project-filter');
  if (!projectFilter || !currentAuthToken || !currentUserId) return;

  try {
    // Get all current filter values to include in counts query
    const typeFilterValue = document.getElementById('task-type-filter')?.value || '';
    const freeInmailFilterValue = document.getElementById('task-free-inmail-filter')?.value || '';
    const connectedFilterValue = document.getElementById('task-connected-filter')?.value || '';

    const countOptions = {
      assigneeId: currentUserId,
      status: 'pending',
    };
    // Pass all filters to get accurate counts
    if (typeFilterValue) {
      countOptions.taskType = typeFilterValue;
    }
    if (freeInmailFilterValue === 'true') {
      countOptions.hasFreeInmail = true;
    } else if (freeInmailFilterValue === 'false') {
      countOptions.hasFreeInmail = false;
    }
    if (connectedFilterValue === 'connected') {
      countOptions.connectedToUserId = currentUserId;
    } else if (connectedFilterValue === 'not_connected') {
      countOptions.connectedToUserId = -currentUserId;
    }

    const counts = await xanoClient.getTaskCounts(currentAuthToken, countOptions);

    const byProject = counts?.by_project || [];
    const totalPending = byProject.reduce((sum, p) => sum + (p.by_status?.pending ?? 0), 0);

    // Clear all existing options first
    while (projectFilter.options.length > 0) {
      projectFilter.remove(0);
    }

    // Add "All Projects" option
    const allOption = document.createElement('option');
    allOption.value = '';
    allOption.textContent = `All Projects (${totalPending})`;
    projectFilter.appendChild(allOption);

    const projectsWithPending = byProject
      .filter(p => (p.by_status?.pending ?? 0) > 0)
      .sort((a, b) => (b.by_status?.pending ?? 0) - (a.by_status?.pending ?? 0));

    projectsWithPending.forEach(project => {
      const option = document.createElement('option');
      option.value = project.project_id;
      const pendingCount = project.by_status?.pending ?? 0;
      option.textContent = `${project.project_name || `Project ${project.project_id}`} (${pendingCount})`;
      projectFilter.appendChild(option);
    });

    // Always reset to "All Projects" when filters change
    projectFilter.value = '';
  } catch (error) {
    console.warn('Failed to fetch project counts for filter:', error);
  }
}

function setupTaskFilters(xanoClient) {
  const projectFilter = document.getElementById('task-project-filter');
  const typeFilter = document.getElementById('task-type-filter');
  const sortFilter = document.getElementById('task-sort-filter');
  const freeInmailFilter = document.getElementById('task-free-inmail-filter');
  const connectedFilter = document.getElementById('task-connected-filter');
  const refreshBtn = document.getElementById('refresh-tasks-btn');
  const prevBtn = document.getElementById('tasks-prev-btn');
  const nextBtn = document.getElementById('tasks-next-btn');

  const reload = () => {
    tasksCurrentPage = 1;
    loadTasks(xanoClient);
  };

  if (projectFilter) {
    projectFilter.addEventListener('change', () => {
      // Default to score sort when a project is selected
      if (projectFilter.value && sortFilter) {
        sortFilter.value = 'score-desc';
      }
      reload();
    });
  }
  if (typeFilter) typeFilter.addEventListener('change', async () => {
    await populateProjectFilter(xanoClient); // Update project counts for selected task type
    reload();
  });
  if (sortFilter) sortFilter.addEventListener('change', reload);
  if (freeInmailFilter) freeInmailFilter.addEventListener('change', async () => {
    await populateProjectFilter(xanoClient); // Update project counts for selected filter
    reload();
  });
  if (connectedFilter) connectedFilter.addEventListener('change', async () => {
    await populateProjectFilter(xanoClient); // Update project counts for selected filter
    reload();
  });
  if (refreshBtn) refreshBtn.addEventListener('click', async () => {
    await populateProjectFilter(xanoClient);
    loadTasks(xanoClient);
    loadInvitationCounts(xanoClient);
  });

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (tasksCurrentPage > 1) {
        tasksCurrentPage--;
        loadTasks(xanoClient);
      }
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (tasksCurrentPage < tasksPageTotal) {
        tasksCurrentPage++;
        loadTasks(xanoClient);
      }
    });
  }

  // Populate the project filter dropdown
  populateProjectFilter(xanoClient);
}

// ---- Progress overlay helpers ----
function showProgress(title, status, count = '') {
  const overlay = document.querySelector('#progress-overlay');
  const titleEl = document.querySelector('#progress-title');
  const statusEl = document.querySelector('#progress-status');
  const countEl = document.querySelector('#progress-count');

  if (overlay) overlay.classList.remove('hidden');
  if (titleEl) titleEl.textContent = title;
  if (statusEl) statusEl.textContent = status;
  if (countEl) countEl.textContent = count;
}

function updateProgress(status, count = '') {
  const statusEl = document.querySelector('#progress-status');
  const countEl = document.querySelector('#progress-count');

  if (statusEl) statusEl.textContent = status;
  if (countEl) countEl.textContent = count;
}

function hideProgress() {
  const overlay = document.querySelector('#progress-overlay');
  if (overlay) overlay.classList.add('hidden');
}

async function saveConnectionsToXanoInBatches(records, { xanoClient, onProgress, batchSize = 5 } = {}) {
  if (!xanoClient) {
    prependActivity('Xano client unavailable; cannot save connections.');
    return 0;
  }

  const sanitizedRecords = Array.isArray(records)
    ? records.filter((record) => record && typeof record === 'object')
    : [];

  if (sanitizedRecords.length === 0) {
    return 0;
  }

  let savedCount = 0;
  let failedCount = 0;
  const total = sanitizedRecords.length;

  for (let i = 0; i < total; i += batchSize) {
    const batch = sanitizedRecords.slice(i, i + batchSize);

    if (onProgress) onProgress(`Saving batch ${Math.floor(i/batchSize) + 1}...`, `${savedCount} / ${total} saved`);

    const results = await Promise.allSettled(
      batch.map(record => xanoClient.createConnection(record))
    );

    results.forEach((result) => {
      if (result.status === 'fulfilled') {
        savedCount++;
      } else {
        failedCount++;
        console.error('Failed to save connection:', result.reason);
      }
    });

    if (onProgress) onProgress(`Saving...`, `${savedCount} / ${total} saved`);
  }

  if (failedCount > 0) {
    prependActivity(`${failedCount} connection(s) failed to save.`);
  }

  return savedCount;
}

async function saveInvitationsToXanoInBatches(records, { xanoClient, memory, onProgress, batchSize = 5 } = {}) {
  if (!xanoClient) {
    prependActivity('Xano client unavailable; cannot save invitations.');
    return 0;
  }

  const sanitizedRecords = Array.isArray(records)
    ? records.filter((record) => record && typeof record === 'object')
    : [];

  if (sanitizedRecords.length === 0) {
    return 0;
  }

  let savedCount = 0;
  let failedCount = 0;
  const total = sanitizedRecords.length;

  for (let i = 0; i < total; i += batchSize) {
    const batch = sanitizedRecords.slice(i, i + batchSize);

    if (onProgress) onProgress(`Saving batch ${Math.floor(i/batchSize) + 1}...`, `${savedCount} / ${total} saved`);

    const results = await Promise.allSettled(
      batch.map(record => xanoClient.createInvitation(record))
    );

    results.forEach((result) => {
      if (result.status === 'fulfilled') {
        savedCount++;
      } else {
        failedCount++;
        console.error('Failed to save invitation:', result.reason);
      }
    });

    if (onProgress) onProgress(`Saving...`, `${savedCount} / ${total} saved`);
  }

  if (failedCount > 0) {
    prependActivity(`${failedCount} invitation(s) failed to save.`);
  }

  return savedCount;
}

function setupTabs() {
  const tabButtons = Array.from(document.querySelectorAll('.tab-button'));
  const tabPanels = Array.from(document.querySelectorAll('.tab-panel'));

  tabButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const targetId = button.dataset.tabTarget;

      tabButtons.forEach((btn) => {
        const isActive = btn === button;
        btn.setAttribute('aria-selected', String(isActive));
      });

      tabPanels.forEach((panel) => {
        const isActive = panel.dataset.tabPanel === targetId;
        panel.classList.toggle('active', isActive);
        panel.setAttribute('aria-hidden', String(!isActive));
      });
    });
  });
}

function setupChatTab(xanoClient) {
  const emptyState = document.getElementById('chat-empty-state');
  const contactCard = document.getElementById('chat-contact');
  const avatarEl = document.getElementById('chat-contact-avatar');
  const nameEl = document.getElementById('chat-contact-name');
  const headlineEl = document.getElementById('chat-contact-headline');
  const sourceEl = document.getElementById('chat-contact-source');
  const profileLink = document.getElementById('chat-contact-profile-link');
  const atsResultEl = document.getElementById('chat-ats-result');
  const atsRetryBtn = document.getElementById('chat-ats-retry-btn');
  const atsFollowBtn = document.getElementById('chat-ats-follow-btn');
  const captureBtn = document.getElementById('chat-capture-btn');
  const captureStatus = document.getElementById('chat-capture-status');
  const messagesContainer = document.getElementById('chat-messages');
  const messagesList = document.getElementById('chat-messages-list');
  const associationsContainer = document.getElementById('chat-associations');
  const associationTabsEl = document.getElementById('chat-association-tabs');
  const stageNameEl = document.getElementById('chat-stage-name');
  const lastNoteEl = document.getElementById('chat-last-note');
  let allAssociations = []; // Store all associations for tab switching
  const openLinkedInMessagingBtn = document.getElementById('open-linkedin-messaging-btn');
  const openRecruiterMessagingBtn = document.getElementById('open-recruiter-messaging-btn');
  // Reply Assistant DOM refs
  const replySection = document.getElementById('chat-reply-section');
  const replyProjectSelect = document.getElementById('chat-reply-project-select');
  const replyInstructions = document.getElementById('chat-reply-instructions');
  const replyBuildBtn = document.getElementById('chat-reply-build-btn');
  const replyResult = document.getElementById('chat-reply-result');
  const replyText = document.getElementById('chat-reply-text');
  const replyCopyBtn = document.getElementById('chat-reply-copy-btn');

  // Cache for projects and stages
  let projectsCache = null;
  let stagesCache = {};

  if (!emptyState || !contactCard) return;

  // Open LinkedIn Messaging button
  if (openLinkedInMessagingBtn) {
    openLinkedInMessagingBtn.addEventListener('click', async () => {
      openLinkedInMessagingBtn.disabled = true;
      openLinkedInMessagingBtn.textContent = 'Opening...';
      try {
        // Navigate to LinkedIn feed first, then click Messaging
        const tab = await chrome.tabs.create({ url: 'https://www.linkedin.com/feed/', active: true });
        // Wait for page to load, then click Messaging link
        setTimeout(async () => {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                // Use stable selectors in order of preference
                const msgLink = document.querySelector('a[data-view-name="navigation-messaging"]')
                  || document.querySelector('a[href*="/messaging/"]')
                  || document.querySelector('a[aria-label*="Messaging"]');
                if (msgLink) msgLink.click();
                else window.location.href = 'https://www.linkedin.com/messaging/';
              },
            });
          } catch (e) {
            console.log('Could not click Messaging, navigating directly');
            chrome.tabs.update(tab.id, { url: 'https://www.linkedin.com/messaging/' });
          }
        }, 2500);
      } catch (error) {
        showToast('Failed to open messaging: ' + error.message, 'error');
      } finally {
        openLinkedInMessagingBtn.disabled = false;
        openLinkedInMessagingBtn.textContent = 'Open LinkedIn Messaging';
      }
    });
  }

  // Open Recruiter Messaging button
  if (openRecruiterMessagingBtn) {
    openRecruiterMessagingBtn.addEventListener('click', async () => {
      openRecruiterMessagingBtn.disabled = true;
      openRecruiterMessagingBtn.textContent = 'Opening...';
      try {
        await chrome.tabs.create({ url: 'https://www.linkedin.com/talent/inbox/0', active: true });
      } catch (error) {
        showToast('Failed to open recruiter inbox: ' + error.message, 'error');
      } finally {
        openRecruiterMessagingBtn.disabled = false;
        openRecruiterMessagingBtn.textContent = 'Open Recruiter Inbox';
      }
    });
  }

  // Helper to get project name from cache or API
  async function getProjectName(projectId) {
    if (!projectsCache) {
      try {
        const projects = await xanoClient.getActiveProjects(currentAuthToken);
        projectsCache = {};
        projects.forEach(p => { projectsCache[p.id] = p.name; });
      } catch (e) {
        console.error('Failed to fetch projects:', e);
        return null;
      }
    }
    return projectsCache[projectId] || null;
  }

  // Helper to get stage name from cache or API
  async function getStageName(projectId, stageId, personType) {
    // Convert person_type to stage_type (API expects plural: candidates/prospects)
    // Normalize to lowercase for case-insensitive matching
    const personTypeLower = (personType || '').toLowerCase();
    let stageType = '';
    if (personTypeLower === 'candidate') stageType = 'candidates';
    else if (personTypeLower === 'prospect') stageType = 'prospects';

    const cacheKey = `${projectId}:${stageType || 'all'}`;
    if (!stagesCache[cacheKey]) {
      try {
        const stages = await xanoClient.getProjectStages(currentAuthToken, { projectId, stageType });
        stagesCache[cacheKey] = {};
        const stageList = Array.isArray(stages) ? stages : (stages?.items || stages?.stages || []);
        stageList.forEach(s => {
          stagesCache[cacheKey][s.id] = s.name;
        });
      } catch (e) {
        console.error('Failed to fetch stages:', e);
        return null;
      }
    }
    return stagesCache[cacheKey]?.[stageId] || null;
  }

  // Hide associations section (does NOT hide reply assistant — that's tied to ATS match)
  function hideAssociations() {
    if (associationsContainer) associationsContainer.classList.add('hidden');
    if (associationTabsEl) associationTabsEl.innerHTML = '';
    if (stageNameEl) stageNameEl.textContent = '-';
    if (lastNoteEl) lastNoteEl.textContent = '-';
    allAssociations = [];
  }

  // Hide and reset reply assistant section
  function hideReplySection() {
    if (replySection) replySection.classList.add('hidden');
    if (replyResult) replyResult.classList.add('hidden');
    if (replyText) replyText.value = '';
    if (replyInstructions) replyInstructions.value = '';
    if (replyProjectSelect) {
      replyProjectSelect.innerHTML = '<option value="">No project context</option>';
    }
  }

  // Display a specific association's details (stage + note)
  async function displayAssociationDetails(assoc, personType) {
    const stageName = await getStageName(assoc.project_id, assoc.current_stage_id, personType);
    if (stageNameEl) stageNameEl.textContent = stageName || `Stage #${assoc.current_stage_id}`;
    if (lastNoteEl) lastNoteEl.textContent = assoc.last_note || 'No notes';
    // Store as the currently selected association
    if (currentChatContact) currentChatContact.association = assoc;
  }

  // Render tabs for all associations
  async function renderAssociationTabs(associations, personType) {
    if (!associationTabsEl) return;
    associationTabsEl.innerHTML = '';

    for (let i = 0; i < associations.length; i++) {
      const assoc = associations[i];
      const projectName = await getProjectName(assoc.project_id);
      const tab = document.createElement('button');
      tab.className = 'chat-association-tab' + (i === 0 ? ' active' : '');
      tab.textContent = projectName || `Project #${assoc.project_id}`;
      tab.title = projectName || `Project #${assoc.project_id}`;
      tab.dataset.index = i;

      tab.addEventListener('click', () => {
        // Update active tab
        associationTabsEl.querySelectorAll('.chat-association-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        // Display this association's details
        displayAssociationDetails(associations[i], personType);
      });

      associationTabsEl.appendChild(tab);
    }
  }

  // Fetch and display associations for a person
  async function fetchAndDisplayAssociations(personType, personId) {
    if (!associationsContainer) return;

    try {
      const associations = await xanoClient.getPersonAssociations(currentAuthToken, { personType, personId });

      if (!associations || associations.length === 0) {
        hideAssociations();
        return;
      }

      // Store all associations
      allAssociations = associations;

      // Render tabs for all associations (project names as tabs)
      await renderAssociationTabs(associations, personType);

      // Display first association's details by default
      await displayAssociationDetails(associations[0], personType);

      associationsContainer.classList.remove('hidden');

      // Populate reply assistant project dropdown and show section
      await populateReplyProjectDropdown(associations);
      if (replySection) replySection.classList.remove('hidden');
    } catch (error) {
      console.error('Failed to fetch associations:', error);
      hideAssociations();
    }
  }

  // Populate reply assistant project dropdown: associated projects first, then all other active projects
  async function populateReplyProjectDropdown(associations) {
    if (!replyProjectSelect) return;
    replyProjectSelect.innerHTML = '<option value="">No project context</option>';

    // Fetch all active projects for names and full list
    let allProjects = [];
    try {
      allProjects = await xanoClient.getActiveProjects(currentAuthToken);
    } catch (e) {
      console.warn('Failed to fetch active projects for reply dropdown:', e);
    }

    // Build name lookup from all projects
    const projectNameMap = {};
    for (const p of allProjects) {
      projectNameMap[p.id] = p.name;
    }

    // Associated project IDs
    const associatedIds = new Set((associations || []).map(a => String(a.project_id)));

    // Section 1: Person's associated projects
    if (associations && associations.length > 0) {
      const groupLabel = document.createElement('option');
      groupLabel.disabled = true;
      groupLabel.textContent = '── Associated Projects ──';
      replyProjectSelect.appendChild(groupLabel);

      for (const assoc of associations) {
        const option = document.createElement('option');
        option.value = assoc.project_id;
        option.textContent = projectNameMap[assoc.project_id] || assoc.project_name || `Project #${assoc.project_id}`;
        replyProjectSelect.appendChild(option);
      }
    }

    // Section 2: All other active projects
    const otherProjects = allProjects.filter(p => !associatedIds.has(String(p.id)));
    if (otherProjects.length > 0) {
      const groupLabel = document.createElement('option');
      groupLabel.disabled = true;
      groupLabel.textContent = '── Other Projects ──';
      replyProjectSelect.appendChild(groupLabel);

      for (const p of otherProjects) {
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = p.name || `Project #${p.id}`;
        replyProjectSelect.appendChild(option);
      }
    }

    // Auto-select if only one associated project
    if (associations && associations.length === 1) {
      replyProjectSelect.value = String(associations[0].project_id);
    }
  }

  // Perform ATS lookup for a contact
  async function performAtsLookup(contact) {
    if (!xanoClient || !currentAuthToken || !atsResultEl) return;

    atsResultEl.textContent = 'Searching...';
    hideAssociations();

    try {
      // Use realProfileUrl if available (after Follow Link), otherwise use profileUrl
      const lookupUrl = contact.realProfileUrl || contact.profileUrl;
      const result = await xanoClient.findLinkedInPerson(currentAuthToken, {
        linkedinUrl: lookupUrl,
        linkedRecruiterProfileId: contact.linkedinId,
        name: contact.name,
        headline: contact.headline,
        source: contact.source,
      });

      if (result.found && result.matches && result.matches.length > 0) {
        const match = result.matches[0];
        console.log('[ATS Lookup] Match object:', match);
        console.log('[ATS Lookup] Match keys:', Object.keys(match));
        const personType = match.person_type === 'candidate' ? 'Candidate' : 'Prospect';
        const elasticId = match.elastic_search_id || match.elastic_search_document_id || match.elasticSearchId || match._id;
        const source = match.person_type === 'candidate' ? 'candidates' : 'prospects';
        const atsProfileUrl = elasticId ? `https://bwats.betterway.dev/profile/${elasticId}?source=${source}#activity` : null;
        const viewLink = atsProfileUrl ? ` <a href="${atsProfileUrl}" target="_blank" class="ats-profile-link" title="View in ATS">View</a>` : '';
        atsResultEl.innerHTML = `<span class="ats-found">${personType}: ${escapeHtml(match.first_name)} ${escapeHtml(match.last_name)}</span>${viewLink}`;
        // Store the match for later use
        currentChatContact.atsMatch = match;
        // Enable capture button now that we have a match
        if (captureBtn) {
          captureBtn.disabled = false;
        }
        // Show reply assistant as soon as ATS match is found
        if (replySection) replySection.classList.remove('hidden');
        // Fetch and display associations (populates project dropdown)
        fetchAndDisplayAssociations(match.person_type, match.person_id);
      } else {
        atsResultEl.textContent = result.reason === 'no_match' ? 'Not found in ATS' : (result.reason || 'Not found');
        // Keep capture button disabled - no match found
        if (captureBtn) {
          captureBtn.disabled = true;
        }
        hideAssociations();
      }
    } catch (error) {
      console.error('ATS lookup failed:', error);
      atsResultEl.textContent = 'Lookup failed';
      // Keep capture button disabled on error
      if (captureBtn) {
        captureBtn.disabled = true;
      }
      hideAssociations();
    }
  }

  // Request current contact from background (which stores it) or fall back to content script
  async function requestCurrentContact() {
    try {
      // First try to get from background (most reliable)
      const bgResponse = await chrome.runtime.sendMessage({ type: 'get-current-messaging-contact' });
      if (bgResponse?.contact) {
        showContact(bgResponse.contact);
        return;
      }

      // Fall back to querying content script directly
      const tabs = await chrome.tabs.query({ url: ['https://www.linkedin.com/messaging/*', 'https://www.linkedin.com/talent/inbox/*'] });
      if (tabs && tabs.length > 0) {
        const response = await chrome.tabs.sendMessage(tabs[0].id, { type: 'get-current-contact' });
        if (response?.contact) {
          showContact(response.contact);
        }
      }
    } catch (error) {
      // Content script may not be ready yet, ignore
      console.log('Could not get current contact:', error.message);
    }
  }

  function renderMessages(messages) {
    if (!messagesList || !messagesContainer) return;
    messagesList.innerHTML = '';
    if (!messages || messages.length === 0) {
      messagesContainer.classList.add('hidden');
      return;
    }
    messages.forEach((msg) => {
      const item = document.createElement('div');
      item.className = 'chat-message-item';
      item.innerHTML = `
        <div class="chat-message-sender">${escapeHtml(msg.sender)}</div>
        <div class="chat-message-body">${escapeHtml(msg.body)}</div>
        ${msg.timestamp ? `<div class="chat-message-time">${escapeHtml(msg.timestamp)}</div>` : ''}
      `;
      messagesList.appendChild(item);
    });
    messagesContainer.classList.remove('hidden');
  }

  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    return parts[0][0].toUpperCase();
  }

  function isSameContact(a, b) {
    if (!a || !b) return false;
    // Normalize linkedinId for comparison (remove trailing slashes, lowercase)
    const normalizeId = (id) => id?.toLowerCase()?.replace(/\/$/, '') || '';
    const normalizeName = (name) => name?.toLowerCase()?.trim()?.replace(/\s+/g, ' ') || '';

    if (a.linkedinId && b.linkedinId) {
      return normalizeId(a.linkedinId) === normalizeId(b.linkedinId);
    }
    // Fallback to name comparison (normalized)
    return normalizeName(a.name) === normalizeName(b.name);
  }

  function showContact(contact) {
    // Skip full reset if same contact (preserves capture status/messages)
    if (isSameContact(currentChatContact, contact)) {
      // Just update basic info that might have changed
      if (contact.avatarUrl && !currentChatContact.avatarUrl) {
        avatarEl.innerHTML = '';
        const img = document.createElement('img');
        img.src = contact.avatarUrl;
        img.alt = contact.name || '';
        avatarEl.appendChild(img);
      }
      return;
    }

    // Clear all previous contact data - start fresh
    currentChatContact = contact;
    // Ensure no stale atsMatch or association from previous contact
    delete currentChatContact.atsMatch;
    delete currentChatContact.association;

    nameEl.textContent = contact.name || 'Unknown';
    headlineEl.textContent = contact.headline || '';
    sourceEl.textContent = contact.source === 'recruiter' ? 'Recruiter' : 'LinkedIn';
    sourceEl.className = 'badge ' + (contact.source === 'recruiter' ? 'badge-candidate' : 'badge-linkedin');

    if (contact.avatarUrl) {
      avatarEl.innerHTML = '';
      const img = document.createElement('img');
      img.src = contact.avatarUrl;
      img.alt = contact.name || '';
      avatarEl.appendChild(img);
    } else {
      avatarEl.textContent = getInitials(contact.name);
    }

    if (contact.profileUrl) {
      profileLink.href = contact.profileUrl;
      profileLink.classList.remove('hidden');
    } else {
      profileLink.classList.add('hidden');
    }

    emptyState.classList.add('hidden');
    contactCard.classList.remove('hidden');
    // Clear capture status and messages completely
    captureStatus.classList.add('hidden');
    captureStatus.className = 'chat-capture-status hidden';
    captureStatus.innerHTML = '';
    if (messagesContainer) messagesContainer.classList.add('hidden');
    if (messagesList) messagesList.innerHTML = '';
    // Hide associations until new lookup completes
    hideAssociations();
    // Disable Update ATS button until ATS lookup confirms match
    if (captureBtn) {
      captureBtn.disabled = true;
      captureBtn.textContent = 'Update ATS';
    }
    // Clear captured chat data
    currentCapturedChat = null;
    // Reset ATS result and perform lookup
    if (atsResultEl) atsResultEl.textContent = 'Searching...';
    performAtsLookup(contact);
    // Auto-capture chat messages
    autoCaptureChat();
  }

  // Auto-capture chat messages when contact is shown (doesn't send to API)
  async function autoCaptureChat() {
    if (!currentChatContact) return;

    try {
      const response = await chrome.runtime.sendMessage({ type: 'capture-chat' });
      if (!response?.ok || !response.messages?.length) {
        // No messages found - that's ok, just don't show anything
        currentCapturedChat = null;
        return;
      }

      // Store captured data for Update ATS button (no validation - user can verify visually)
      currentCapturedChat = {
        messages: response.messages,
        threadUrl: response.threadUrl,
        capturedAt: new Date().toISOString(),
        capturedContact: response.contact, // Store for reference
      };

      // Show messages in the sidebar
      renderMessages(response.messages);
      captureStatus.classList.add('hidden');
    } catch (error) {
      console.error('[Auto-Capture] Failed:', error);
      currentCapturedChat = null;
    }
  }

  function clearContact() {
    currentChatContact = null;
    currentCapturedChat = null;
    emptyState.classList.remove('hidden');
    contactCard.classList.add('hidden');
    captureStatus.classList.add('hidden');
    captureStatus.className = 'chat-capture-status hidden';
    // Clear messages
    if (messagesContainer) messagesContainer.classList.add('hidden');
    if (messagesList) messagesList.innerHTML = '';
    // Reset ATS result
    if (atsResultEl) atsResultEl.textContent = 'Not available';
    // Hide reply assistant
    hideReplySection();
  }

  // Listen for contact updates from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'messaging-contact-update') {
      const contact = message.payload?.contact;
      if (contact) showContact(contact);
    }
    if (message?.type === 'messaging-contact-cleared') {
      clearContact();
    }
  });

  // Also listen via service worker postMessage (for side panel)
  if (navigator.serviceWorker) {
    navigator.serviceWorker.addEventListener('message', (event) => {
      const message = event.data;
      if (message?.type === 'messaging-contact-update') {
        const contact = message.payload?.contact;
        if (contact) showContact(contact);
      }
      if (message?.type === 'messaging-contact-cleared') {
        clearContact();
      }
    });
  }

  // Update ATS button - sends already-captured chat to API
  if (captureBtn) {
    captureBtn.addEventListener('click', async () => {
      if (!currentChatContact?.atsMatch) {
        showToast('No ATS match found. Cannot update.', 'error');
        return;
      }

      if (!currentCapturedChat?.messages?.length) {
        showToast('No chat messages captured. Open a conversation first.', 'error');
        return;
      }

      captureBtn.disabled = true;
      captureBtn.textContent = 'Sending...';

      try {
        const { person_type, person_id } = currentChatContact.atsMatch;
        console.log('[Update ATS] Sending to API:', {
          person_type,
          person_id,
          threadUrl: currentCapturedChat.threadUrl,
          messageCount: currentCapturedChat.messages.length,
        });

        const apiResult = await xanoClient.captureConversation(currentAuthToken, {
          personType: person_type,
          personId: person_id,
          threadUrl: currentCapturedChat.threadUrl,
          conversation: {
            captured_at: currentCapturedChat.capturedAt,
            messages: currentCapturedChat.messages,
          },
        });

        console.log('[Update ATS] API result:', apiResult);
        const tasksLaunched = apiResult.tasks_launched?.length || 0;
        const touchpointsSaved = apiResult.touchpoints_saved || 0;
        const associationsFound = apiResult.associations_found || 0;

        captureStatus.innerHTML = `
          <div><strong>ATS Updated!</strong></div>
          <div>Messages: ${currentCapturedChat.messages?.length || 0}</div>
          <div>Associations found: ${associationsFound}</div>
          <div>Touchpoints saved: ${touchpointsSaved}</div>
          <div>AI tasks launched: ${tasksLaunched}</div>
          ${apiResult.tasks_launched?.map(t => `<div class="chat-task-item">→ ${escapeHtml(t.project_name)} (Task #${t.task_id})</div>`).join('') || ''}
        `;
        captureStatus.className = 'chat-capture-status status-success';
        captureStatus.classList.remove('hidden');
        showToast(`ATS updated! ${tasksLaunched} AI tasks launched.`, 'success');

      } catch (error) {
        console.error('[Update ATS] Failed:', error);
        const errorMsg = error.message || String(error);

        captureStatus.innerHTML = `<div><strong>Update failed</strong></div><div>${escapeHtml(errorMsg)}</div>`;
        captureStatus.className = 'chat-capture-status status-error';
        captureStatus.classList.remove('hidden');
        showToast('ATS update failed', 'error');
      } finally {
        captureBtn.disabled = false;
        captureBtn.textContent = 'Update ATS';
      }
    });
  }

  // Build Reply button handler
  if (replyBuildBtn) {
    replyBuildBtn.addEventListener('click', async () => {
      const instructions = replyInstructions?.value?.trim();
      if (!instructions) {
        showToast('Enter instructions for the reply', 'error');
        return;
      }
      if (!currentChatContact?.atsMatch) {
        showToast('No ATS match found — person must be in the system', 'error');
        return;
      }

      // If chat not captured yet, try capturing now
      if (!currentCapturedChat?.messages?.length) {
        replyBuildBtn.disabled = true;
        replyBuildBtn.textContent = 'Capturing chat...';
        await autoCaptureChat();
        if (!currentCapturedChat?.messages?.length) {
          showToast('No chat messages found. Open a conversation first.', 'error');
          replyBuildBtn.disabled = false;
          replyBuildBtn.textContent = 'Build Reply';
          return;
        }
      }

      replyBuildBtn.disabled = true;
      replyBuildBtn.textContent = 'Thinking...';
      if (replyResult) replyResult.classList.add('hidden');

      try {
        const { person_type, person_id } = currentChatContact.atsMatch;
        const projectId = replyProjectSelect?.value ? parseInt(replyProjectSelect.value) : null;

        const result = await xanoClient.suggestReply(currentAuthToken, {
          personId: person_id,
          personType: person_type,
          instructions: instructions,
          projectId: projectId,
          conversation: { messages: currentCapturedChat.messages },
        });

        if (replyText) replyText.value = result.suggested_reply || 'No reply generated';
        if (replyResult) replyResult.classList.remove('hidden');
        showToast('Reply suggestion ready', 'success');
      } catch (error) {
        console.error('[Reply Assistant] Failed:', error);
        const errorMsg = error.message || String(error);
        if (errorMsg === 'AUTH_EXPIRED') {
          showToast('Session expired. Please log in again.', 'error');
        } else {
          showToast('Reply generation failed: ' + errorMsg, 'error');
        }
      } finally {
        replyBuildBtn.disabled = false;
        replyBuildBtn.textContent = 'Build Reply';
      }
    });
  }

  // Copy Reply button handler
  if (replyCopyBtn) {
    replyCopyBtn.addEventListener('click', () => {
      const text = replyText?.value;
      if (!text) {
        showToast('No reply to copy', 'error');
        return;
      }
      navigator.clipboard.writeText(text).then(() => {
        showToast('Reply copied to clipboard', 'success');
      }).catch(() => {
        // Fallback: select textarea content and copy
        replyText.select();
        document.execCommand('copy');
        showToast('Reply copied to clipboard', 'success');
      });
    });
  }

  // Retry ATS lookup button
  if (atsRetryBtn) {
    atsRetryBtn.addEventListener('click', () => {
      if (currentChatContact) {
        performAtsLookup(currentChatContact);
      }
    });
  }

  // Follow Link button - opens profile URL to get real slug
  if (atsFollowBtn) {
    atsFollowBtn.addEventListener('click', async () => {
      if (!currentChatContact?.profileUrl) {
        showToast('No profile URL available', 'error');
        return;
      }

      atsFollowBtn.disabled = true;
      atsFollowBtn.textContent = 'Opening...';
      if (atsResultEl) atsResultEl.textContent = 'Opening profile...';

      try {
        // Open the profile URL in a new tab
        const tab = await chrome.tabs.create({ url: currentChatContact.profileUrl, active: true });
        if (atsResultEl) atsResultEl.textContent = 'Waiting for redirect...';

        // Wait for the page to load and get the final URL (after redirect)
        const checkUrl = async (attempts = 0) => {
          if (attempts > 10) {
            if (atsResultEl) atsResultEl.textContent = 'Could not get final URL';
            atsFollowBtn.disabled = false;
            atsFollowBtn.textContent = 'Follow Link';
            showToast('Could not get final URL', 'error');
            return;
          }

          await new Promise(r => setTimeout(r, 1500));

          try {
            const updatedTab = await chrome.tabs.get(tab.id);
            if (updatedTab.status === 'complete' && updatedTab.url) {
              const finalUrl = updatedTab.url;
              // Extract the real slug from the final URL
              const slugMatch = finalUrl.match(/linkedin\.com\/in\/([^/?#]+)/);
              if (slugMatch && slugMatch[1]) {
                const realSlug = slugMatch[1];
                // Update the contact with the real profile URL
                currentChatContact.realProfileUrl = finalUrl;
                currentChatContact.realLinkedinSlug = realSlug;

                // Display the resolved URL first
                if (atsResultEl) {
                  atsResultEl.innerHTML = `<span class="ats-url">URL: /in/${escapeHtml(realSlug)}</span>`;
                }
                showToast(`Got real profile: ${realSlug}`, 'success');

                // Re-enable button
                atsFollowBtn.disabled = false;
                atsFollowBtn.textContent = 'Follow Link';

                // Small delay to show the URL, then do lookup
                await new Promise(r => setTimeout(r, 500));

                // Now do the ATS lookup with the new info
                performAtsLookup(currentChatContact);
              } else {
                if (atsResultEl) atsResultEl.textContent = 'No profile slug found in URL';
                atsFollowBtn.disabled = false;
                atsFollowBtn.textContent = 'Follow Link';
              }
            } else {
              // Page still loading, try again
              if (atsResultEl) atsResultEl.textContent = `Waiting for redirect... (${attempts + 1})`;
              checkUrl(attempts + 1);
            }
          } catch (e) {
            // Tab might be closed
            console.log('Tab check failed:', e);
            if (atsResultEl) atsResultEl.textContent = 'Tab closed or error';
            atsFollowBtn.disabled = false;
            atsFollowBtn.textContent = 'Follow Link';
          }
        };

        checkUrl();
      } catch (error) {
        showToast('Failed to open profile: ' + error.message, 'error');
        if (atsResultEl) atsResultEl.textContent = 'Failed to open profile';
        atsFollowBtn.disabled = false;
        atsFollowBtn.textContent = 'Follow Link';
      }
    });
  }

  // Check if already on a messaging page when sidepanel opens
  requestCurrentContact();
}

function setupSettingsForm(memory, xanoClient) {
  const form = document.querySelector('#settings-form');
  const statusElement = document.querySelector('#settings-status');

  if (!form) {
    return;
  }

  const connectionLimitInput = form.querySelector('#connection-limit-input');
  const connectionLimitSaveButton = form.querySelector('#connection-limit-save');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const input = form.querySelector('#username-input');
    const username = input?.value?.trim() ?? '';

    if (!username) {
      reportStatus('Please provide a username before saving.', true, statusElement);
      return;
    }

    try {
      memory.setUsername(username);
      await memory.save();
      reportStatus('Username saved to long-term memory.', false, statusElement);
    } catch (error) {
      console.error('Failed to save username', error);
      reportStatus('Failed to save username. Check console for details.', true, statusElement);
    }
  });

  if (connectionLimitInput) {
    const currentLimit = memory.getConnectionLimit?.();
    if (Number.isFinite(currentLimit) && currentLimit > 0) {
      connectionLimitInput.value = String(currentLimit);
    }
  }

  if (connectionLimitInput && connectionLimitSaveButton) {
    connectionLimitSaveButton.addEventListener('click', async () => {
      const rawValue = connectionLimitInput.value;
      const nextLimit = Number.parseInt(rawValue, 10);

      if (!Number.isFinite(nextLimit) || nextLimit <= 0) {
        reportStatus('Enter a positive number for the connection limit.', true, statusElement);
        return;
      }

      try {
        memory.setConnectionLimit?.(nextLimit);
        await memory.save();
        reportStatus('Connection limit saved.', false, statusElement);
      } catch (error) {
        console.error('Failed to save connection limit', error);
        reportStatus('Failed to save connection limit. Check console for details.', true, statusElement);
      }
    });
  }

  // Setup task filters (now that DOM is ready)
  if (xanoClient) {
    setupTaskFilters(xanoClient);
  }
}

function setupManualExtract(memory, xanoClient) {
  const button = document.querySelector('#manual-extract-button');
  const lastExtractElement = document.querySelector('[data-last-extract="value"]');
  const nextAutoElement = document.querySelector('[data-next-auto="value"]');

  if (!button || !lastExtractElement) {
    return;
  }

  const driver = createConnectionsDriver();

  const updateDisplay = async () => {
    const isoDate = memory.getLastImportConnectionDate?.();
    if (!isoDate) {
      lastExtractElement.textContent = 'Never';
    } else {
      const formatted = formatTimestamp(isoDate);
      lastExtractElement.textContent = formatted;
    }

    if (!nextAutoElement) {
      return;
    }

    try {
      const response = await chrome.runtime.sendMessage({ type: 'request-next-auto-extract' });
      if (response?.ok && response.nextAutoExtractAt) {
        nextAutoElement.textContent = formatTimestamp(response.nextAutoExtractAt);
      } else {
        nextAutoElement.textContent = 'Not scheduled';
      }
    } catch (error) {
      console.error('Failed to obtain next auto extract time.', error);
      nextAutoElement.textContent = 'Unknown';
    }
  };

  updateDisplay();

  const summaryListener = async (message) => {
    if (!message || message.type !== 'connections-extract-summary') {
      return;
    }

    const { payload } = message;
    if (!payload || payload.source !== 'auto') {
      return;
    }

    const timestamp = typeof payload.timestamp === 'number' ? new Date(payload.timestamp) : new Date();

    try {
      await memory.load();
    } catch (error) {
      console.warn('Failed to reload memory snapshot after extract summary.', error);
    }

    await updateDisplay();

    const formatted = formatTimestamp(timestamp);
    const total = Number.isFinite(payload.totalNewConnections) ? payload.totalNewConnections : 0;
    const messageText = `Scheduled extract completed at ${formatted} (connections: ${total})`;
    prependActivity(messageText);
  };

  if (chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener(summaryListener);
    window.addEventListener('unload', () => {
      if (chrome?.runtime?.onMessage) {
        chrome.runtime.onMessage.removeListener(summaryListener);
      }
    });
  }

  button.addEventListener('click', async () => {
    logWithTimestamp('[Linked Communication] Manual extract starting...');
    button.disabled = true;
    button.textContent = 'Extracting...';

    try {
      const result = await driver.runManualExtract();

      if (result && typeof result === 'object' && result.error) {
        if (result.error === 'not_on_connections_page') {
          prependActivity('Please navigate to LinkedIn Connections page first, then scroll to load connections.');
          prependActivity('Go to: linkedin.com/mynetwork/invite-connect/connections/');
        } else if (result.error === 'no_html_captured') {
          prependActivity('Could not capture page content. Make sure the page is fully loaded.');
        } else {
          prependActivity(`Extract failed: ${result.error}`);
        }
        button.disabled = false;
        button.textContent = 'Extract Connections';
        return;
      }

      const records = Array.isArray(result) ? result : (result?.records ?? []);
      const timestamp = new Date();
      const totalConnections = records.length;
      memory.setLastImportConnectionDate?.(timestamp);
      await memory.save();

      try {
        await memory.load();
      } catch (error) {
        console.warn('Failed to reload memory snapshot after manual extract.', error);
      }

      await updateDisplay();

      try {
        await chrome.runtime.sendMessage({
          type: 'manual-extract-completed',
          payload: {
            timestamp: timestamp.getTime(),
            totalNewConnections: totalConnections,
          },
        });
      } catch (error) {
        console.warn('Failed to notify background of manual completion.', error);
      }

      prependActivity(`Captured ${totalConnections} connection(s)`);

      if (totalConnections > 0) {
        showProgress('Saving Connections', 'Starting...', `0 / ${totalConnections}`);
        const savedCount = await saveConnectionsToXanoInBatches(records, { xanoClient, onProgress: updateProgress });
        hideProgress();

        if (savedCount > 0) {
          prependActivity(`Done! Saved ${savedCount} connection(s) to Xano.`);
        } else {
          prependActivity(`Done! All connections already in Xano or failed.`);
        }
      } else {
        prependActivity('No new connections to send to Xano.');
      }

      button.textContent = 'Done!';
      await sleep(800);
    } catch (error) {
      console.error('Manual extract failed', error);
      prependActivity('Manual extract failed. Check console for details.');
      hideProgress();
    } finally {
      button.disabled = false;
      button.textContent = 'Extract Connections';
      hideProgress();
    }
  });
}

function setupManualInvitationExtract(memory, xanoClient) {
  const button = document.querySelector('#manual-invitation-extract-button');
  const lastExtractElement = document.querySelector('[data-last-invitation-extract="value"]');

  if (!button) {
    return;
  }

  let driver;
  try {
    driver = createInvitationsDriver();
  } catch (error) {
    console.error('[Linked Communication][SidePanel] Failed to create InvitationsDriver instance.', error);
    prependActivity('Failed to initialise Invitation driver. See console for details.');
    return;
  }

  const updateDisplay = async () => {
    if (!lastExtractElement) {
      return;
    }

    try {
      await memory.load();

      const isoDate = memory.getLastImportInvitationDate?.();

      if (!isoDate) {
        lastExtractElement.textContent = 'Never';
      } else {
        const formatted = formatTimestamp(isoDate);
        lastExtractElement.textContent = formatted;
      }
    } catch (error) {
      console.error('[Linked Communication][SidePanel] Failed to display invitation timestamp:', error);
      lastExtractElement.textContent = 'Never';
    }
  };

  updateDisplay();

  button.addEventListener('click', async () => {
    logWithTimestamp('[Linked Communication][SidePanel] Manual invitation extract starting...');
    button.disabled = true;
    button.textContent = 'Extracting...';

    try {
      const result = await driver.runManualExtract();

      if (result && typeof result === 'object' && result.error) {
        if (result.error === 'not_on_invitations_page') {
          prependActivity('Please navigate to LinkedIn Sent Invitations page first, then scroll to load invitations.');
          prependActivity('Go to: linkedin.com/mynetwork/invitation-manager/sent/');
        } else if (result.error === 'no_html_captured') {
          prependActivity('Could not capture page content. Make sure the page is fully loaded.');
        } else {
          prependActivity(`Extract failed: ${result.error}`);
        }
        button.disabled = false;
        button.textContent = 'Extract Invitations';
        return;
      }

      const records = Array.isArray(result) ? result : (result?.records ?? []);
      const timestamp = new Date();
      const totalInvitations = records.length;

      memory.setLastImportInvitationDate?.(timestamp);
      await memory.save();

      try {
        await memory.load();
      } catch (error) {
        console.warn('Failed to reload memory snapshot after invitation extract.', error);
      }

      await updateDisplay();

      prependActivity(`Captured ${totalInvitations} invitation(s)`);

      if (totalInvitations > 0) {
        showProgress('Saving Invitations', 'Checking existing...', '');
        const userId = memory?.getUserId?.();

        if (!userId) {
          hideProgress();
          prependActivity('No user_id found. Please log in to Xano in Settings.');
        } else {
          const recordsWithUser = records.map(r => ({ ...r, user_id: userId }));

          let newInvitations = recordsWithUser;
          try {
            const existing = await xanoClient.validateInvitations(
              recordsWithUser.map(r => ({
                user_id: String(userId),
                linkedin_profile: r.Connection_Profile_URL || ''
              }))
            );

            const existingArray = Array.isArray(existing) ? existing : (existing?.data ?? []);
            if (existingArray.length > 0) {
              const existingSet = new Set();
              existingArray.forEach(item => {
                const slug = item.Connection_Profile_URL || item.linkedin_profile || '';
                if (slug) existingSet.add(slug);
              });

              newInvitations = recordsWithUser.filter(r => !existingSet.has(r.Connection_Profile_URL));
              const filtered = recordsWithUser.length - newInvitations.length;
              if (filtered > 0) {
                prependActivity(`Filtered ${filtered} existing invitation(s).`);
              }
            }
          } catch (error) {
            console.warn('Validation failed:', error);
          }

          if (newInvitations.length > 0) {
            updateProgress('Saving to Xano...', `0 / ${newInvitations.length}`);
            const savedCount = await saveInvitationsToXanoInBatches(newInvitations, { xanoClient, memory, onProgress: updateProgress });
            hideProgress();

            if (savedCount > 0) {
              prependActivity(`Done! Saved ${savedCount} invitation(s) to Xano.`);
            } else {
              prependActivity(`Failed to save invitations.`);
            }
          } else {
            hideProgress();
            prependActivity(`All invitations already in Xano.`);
          }
        }
      } else {
        prependActivity('No invitations found to extract.');
      }

      button.textContent = 'Done!';
      await sleep(800);
    } catch (error) {
      console.error('[Linked Communication][SidePanel] Manual invitation extract failed', error);
      prependActivity(`Manual invitation extract failed: ${error.message || 'Check console for details.'}`);
      hideProgress();
    } finally {
      button.disabled = false;
      button.textContent = 'Extract Invitations';
      hideProgress();
    }
  });
}

function setupOpenLinkedInButtons() {
  const openConnectionsBtn = document.querySelector('#open-connections-button');
  const openInvitationsBtn = document.querySelector('#open-invitations-button');

  if (openConnectionsBtn) {
    openConnectionsBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://www.linkedin.com/mynetwork/invite-connect/connections/' });
    });
  }

  if (openInvitationsBtn) {
    openInvitationsBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://www.linkedin.com/mynetwork/invitation-manager/sent/' });
    });
  }
}

function reportStatus(message, isError = false, element = document.querySelector('#settings-status')) {
  if (!element) {
    return;
  }

  element.textContent = message;
  element.classList.toggle('error', Boolean(isError));
}

async function prepareMemory() {
  const memoryExports = await waitForModule(() => window.LinkedCommunicationLongTermMemory);
  const LongTermMemory = memoryExports?.LongTermMemory;

  if (!LongTermMemory) {
    console.error('LongTermMemory module not found on window.');
    reportStatus('Unable to access storage module.', true);
    throw new Error('Memory module unavailable');
  }

  const memory = new LongTermMemory();
  await memory.load();

  const usernameInput = document.querySelector('#username-input');
  if (usernameInput && typeof memory.getUsername === 'function') {
    usernameInput.value = memory.getUsername() ?? '';
  }

  return memory;
}

async function prepareXanoClient() {
  try {
    const xanoExports = await waitForModule(() => window.LinkedCommunicationXanoClient);
    const XanoClient = xanoExports?.XanoClient;
    if (!XanoClient) {
      console.warn('Xano client module not found on window.');
      return null;
    }

    return new XanoClient({});
  } catch (error) {
    console.error('Failed to initialize Xano client', error);
    return null;
  }
}

function createConnectionsDriver() {
  const driverModule = window.LinkedCommunicationConnectionsDriver;
  if (!driverModule?.ConnectionsDriver) {
    throw new Error('ConnectionsDriver not available on window.');
  }

  return new driverModule.ConnectionsDriver();
}

function createInvitationsDriver() {
  const driverModule = window.LinkedCommunicationInvitationsDriver;
  if (!driverModule?.InvitationsDriver) {
    console.error('[Linked Communication][SidePanel] InvitationsDriver module missing on window.', driverModule);
    throw new Error('InvitationsDriver not available on window.');
  }

  logWithTimestamp('[Linked Communication][SidePanel] InvitationsDriver module ready. Constructing instance.');
  const instance = new driverModule.InvitationsDriver();
  logWithTimestamp('[Linked Communication][SidePanel] InvitationsDriver instance created.', instance);
  return instance;
}

async function waitForModule(getter, attempts = 5, delayMs = 50) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const candidate = typeof getter === 'function' ? getter() : getter;
    if (candidate) {
      return candidate;
    }

    if (attempt < attempts - 1) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  return undefined;
}

function formatTimestamp(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return 'Unknown';
  }

  return new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}

function formatShortDate(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';

  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function prependActivity(message) {
  const feed = document.querySelector('#activity-feed');
  if (!feed) {
    return;
  }

  const item = document.createElement('li');
  item.textContent = message;
  feed.prepend(item);
}

function sleep(durationMs) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, durationMs || 0)));
}

function bridgeConsoleToBackground() {
  if (!chrome?.runtime?.sendMessage) {
    return;
  }

  const methods = ['log', 'info', 'warn', 'error'];
  methods.forEach((method) => {
    const original = console[method]?.bind(console) ?? console.log.bind(console);
    console[method] = (...args) => {
      try {
        chrome.runtime.sendMessage({
          type: 'popup-log',
          payload: {
            level: method,
            args,
          },
        });
      } catch (error) {
        // Ignore sendMessage failure and continue to log locally.
      }

      original(...args);
    };
  });
}

function resolveUserId(profile) {
  if (!profile || typeof profile !== 'object') {
    return null;
  }

  const candidates = [
    profile.id,
    profile.user_id,
    profile.userId,
    profile?.data?.id,
    profile?.data?.user_id,
  ];

  const found = candidates.find((value) => typeof value === 'string' || typeof value === 'number');
  if (found === undefined || found === null) {
    return null;
  }

  return String(found);
}

initialize();
