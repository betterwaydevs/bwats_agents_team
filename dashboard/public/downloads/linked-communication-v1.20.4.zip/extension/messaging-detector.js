'use strict';

(function messagingDetector() {
  const LOG_PREFIX = '[LinkedComm][MessagingDetector]';
  const log = (...args) => console.log(LOG_PREFIX, ...args);

  const REGULAR_THREAD_RE = /linkedin\.com\/messaging\/thread\//;
  const RECRUITER_THREAD_RE = /linkedin\.com\/talent\/inbox\//;
  const MESSAGING_RE = /linkedin\.com\/(messaging|talent\/inbox)/;

  const DEBOUNCE_MS = 500;
  const POLL_INTERVAL_MS = 2000;
  const MAX_RETRIES = 3;
  const RETRY_DELAY_MS = 1000;

  let lastReportedContact = null;
  let debounceTimer = null;
  let pollTimer = null;
  let lastUrl = location.href;

  // ---- URL helpers ----
  function isMessagingThread() {
    return REGULAR_THREAD_RE.test(location.href) || RECRUITER_THREAD_RE.test(location.href);
  }

  function isRecruiter() {
    return RECRUITER_THREAD_RE.test(location.href);
  }

  function isMessagingPage() {
    return MESSAGING_RE.test(location.href);
  }

  // ---- Contact extraction ----
  function getVisibleThread() {
    // CRITICAL: LinkedIn keeps MULTIPLE .msg-thread containers in DOM (hidden old threads).
    // We must find the VISIBLE one by checking offsetParent and dimensions.
    const allThreads = document.querySelectorAll('.msg-thread');
    for (const thread of allThreads) {
      // Skip if inside overlay bubbles
      if (thread.closest('.msg-overlay-list-bubble') || thread.closest('.msg-overlay-conversation-bubble')) {
        continue;
      }
      // Check if visible (has layout)
      if (thread.offsetParent !== null && thread.offsetHeight > 0) {
        return thread;
      }
    }
    // Fallback to first non-overlay thread
    for (const thread of allThreads) {
      if (!thread.closest('.msg-overlay-list-bubble') && !thread.closest('.msg-overlay-conversation-bubble')) {
        return thread;
      }
    }
    return null;
  }

  function extractRegularContact() {
    const threadContainer = getVisibleThread();
    if (!threadContainer) {
      log('No visible .msg-thread found');
      return null;
    }

    // Get title bar - it's a SIBLING of .msg-thread, not inside it
    // IMPORTANT: Exclude title bars inside overlay bubbles (.msg-overlay-list-bubble)
    let titleBar = null;
    const allTitleBars = document.querySelectorAll('.msg-title-bar');
    for (const tb of allTitleBars) {
      // Skip if inside an overlay bubble
      if (tb.closest('.msg-overlay-list-bubble') || tb.closest('.msg-overlay-conversation-bubble')) {
        continue;
      }
      titleBar = tb;
      break;
    }

    // Profile link - scoped to title bar
    let profileLinkEl = null;
    if (titleBar) {
      profileLinkEl = titleBar.querySelector('a.msg-thread__link-to-profile')
        || titleBar.querySelector('a[href*="/in/"]');
    }
    const profileLink = profileLinkEl?.href || null;

    // Name from title bar's entity lockup
    let name = null;
    if (titleBar) {
      const h2El = titleBar.querySelector('h2.msg-entity-lockup__entity-title');
      if (h2El) {
        name = h2El.innerText?.trim();
      }
    }

    // Fallback: Try title attribute from profile link (e.g., "Open John Doe's profile")
    if (!name && profileLinkEl) {
      const title = profileLinkEl.getAttribute('title');
      if (title && title.startsWith('Open ')) {
        // "Open John Doe's profile" -> "John Doe"
        name = title.replace(/^Open /, '').replace(/'s? profile$/, '').trim();
      }
    }

    // Clean up any remaining newlines
    if (name) {
      name = name.split('\n')[0].trim();
    }

    if (!name) return null;

    // Headline from title bar
    let headline = null;
    if (titleBar) {
      const headlineEl = titleBar.querySelector('.msg-entity-lockup__entity-info');
      if (headlineEl) {
        headline = headlineEl.innerText?.trim();
      }
    }

    // Avatar - scoped to thread
    const avatarEl = threadContainer.querySelector('img.presence-entity__image');

    return {
      name,
      headline,
      avatarUrl: avatarEl?.src || null,
      profileUrl: profileLink || null,
      linkedinId: profileLink ? profileLink.match(/\/in\/([^/?#]+)/)?.[1] || null : null,
      source: 'regular',
    };
  }

  function extractRecruiterContact() {
    // Profile link from thread header - recruiter uses data-test-link-to-profile-link
    const profileLinkEl = document.querySelector('a[data-test-link-to-profile-link]')
      || document.querySelector('.profile-info__name a')
      || document.querySelector('[data-test-profile-name] a');
    const profileLink = profileLinkEl?.href || null;

    // Name: Try multiple selectors
    let name = null;

    // Try 1: Get text from profile link (most reliable for recruiter)
    if (profileLinkEl) {
      name = profileLinkEl.innerText?.trim();
    }

    // Try 2: lockup title with full name
    if (!name) {
      const nameEl = document.querySelector('[data-test-row-lockup-full-name] .artdeco-entity-lockup__title')
        || document.querySelector('.profile-info__name')
        || document.querySelector('[data-test-profile-name]')
        || document.querySelector('.artdeco-entity-lockup__title');
      name = nameEl?.innerText?.trim() || null;
    }

    // Try 3: Image title attribute
    if (!name) {
      const imgEl = document.querySelector('img.lockup__image');
      if (imgEl) {
        name = imgEl.getAttribute('title');
      }
    }

    // Clean up any remaining newlines
    if (name) {
      name = name.split('\n')[0].trim();
    }
    if (!name) return null;

    // Headline from subtitle
    const headlineEl = document.querySelector('[data-test-row-lockup-headline]')
      || document.querySelector('.profile-info__headline')
      || document.querySelector('[data-test-profile-headline]')
      || document.querySelector('.artdeco-entity-lockup__subtitle');

    // Avatar from profile image
    const avatarEl = document.querySelector('img.lockup__image')
      || document.querySelector('.profile-info__profile-photo img')
      || document.querySelector('.artdeco-entity-lockup__image img');

    // Extract LinkedIn ID - recruiter uses /talent/profile/ACoAAA... format
    let linkedinId = null;
    if (profileLink) {
      // Try talent profile format first
      const talentMatch = profileLink.match(/\/talent\/profile\/([^/?#]+)/);
      if (talentMatch) {
        linkedinId = talentMatch[1];
      } else {
        // Fall back to regular /in/ format
        const inMatch = profileLink.match(/\/in\/([^/?#]+)/);
        linkedinId = inMatch ? inMatch[1] : null;
      }
    }

    return {
      name,
      headline: headlineEl?.innerText?.trim() || null,
      avatarUrl: avatarEl?.src || null,
      profileUrl: profileLink || null,
      linkedinId,
      source: 'recruiter',
    };
  }

  function extractContact() {
    return isRecruiter() ? extractRecruiterContact() : extractRegularContact();
  }

  // ---- Message extraction ----
  // Helper to determine direction based on sender vs contact name
  function getDirection(senderName, contactName) {
    if (!senderName || !contactName) return 'outbound'; // Default to outbound if unknown
    const senderLower = senderName.toLowerCase().trim();
    const contactLower = contactName.toLowerCase().trim();
    // If sender matches contact name (or first name), it's inbound
    const contactFirstName = contactLower.split(' ')[0];
    if (senderLower === contactLower || senderLower.includes(contactLower) || senderLower === contactFirstName) {
      return 'inbound';
    }
    return 'outbound';
  }

  // Helper to ensure timestamp is ISO 8601 format
  function normalizeTimestamp(timestamp) {
    if (!timestamp) return new Date().toISOString();
    // If already ISO format, return as-is
    if (timestamp.includes('T') && timestamp.includes('Z')) return timestamp;
    // Try to parse and convert
    const date = new Date(timestamp);
    if (!isNaN(date.getTime())) return date.toISOString();
    // Return current time as fallback
    return new Date().toISOString();
  }

  function extractRegularMessages(contactName) {
    const threadContainer = getVisibleThread();
    if (!threadContainer) {
      return [];
    }

    // Try multiple selectors for message containers - scoped to thread
    let messageEls = threadContainer.querySelectorAll('.msg-s-event-listitem[data-view-name="message-list-item"]');
    if (messageEls.length === 0) {
      messageEls = threadContainer.querySelectorAll('.msg-s-event-listitem');
    }
    if (messageEls.length === 0) {
      messageEls = threadContainer.querySelectorAll('.msg-s-message-list__event');
    }
    if (messageEls.length === 0) {
      messageEls = threadContainer.querySelectorAll('[data-view-name="message-event"]');
    }

    const messages = [];

    messageEls.forEach((el) => {
      const senderEl = el.querySelector('.msg-s-message-group__name')
        || el.querySelector('.msg-s-event-listitem__name')
        || el.querySelector('[class*="message-group__name"]')
        || el.querySelector('[class*="sender"]');
      const bodyEl = el.querySelector('.msg-s-event-listitem__body')
        || el.querySelector('.msg-s-message-group__message-body')
        || el.querySelector('[class*="message-body"]')
        || el.querySelector('[class*="message__body"]')
        || el.querySelector('p');
      const timeEl = el.querySelector('.msg-s-message-group__timestamp')
        || el.querySelector('time')
        || el.querySelector('[class*="timestamp"]');

      if (bodyEl) {
        const sender = senderEl?.innerText?.trim() || 'Unknown';
        const rawTimestamp = timeEl?.getAttribute('datetime') || timeEl?.innerText?.trim() || null;
        // Use class-based detection: msg-s-event-listitem--other = inbound (from contact)
        const isFromOther = el.classList.contains('msg-s-event-listitem--other');
        messages.push({
          sender,
          body: bodyEl.innerText?.trim() || '',
          timestamp: normalizeTimestamp(rawTimestamp),
          direction: isFromOther ? 'inbound' : 'outbound',
        });
      }
    });

    log('Extracted messages count:', messages.length);
    return messages;
  }

  function extractRecruiterMessages(contactName) {
    // Recruiter uses data-test attributes for message elements
    const messageEls = document.querySelectorAll('section[data-test-message-list-item]');
    const messages = [];

    messageEls.forEach((el) => {
      // Sender name from data-test-message-sender-name
      const senderEl = el.querySelector('[data-test-message-sender-name]');
      // Message body from data-test-rich-message-body or the content div inside
      const bodyEl = el.querySelector('[data-test-rich-message-body]')
        || el.querySelector('[data-test-messaging-attributed-text-renderer-content]');
      // Timestamp from data-test-message-time
      const timeEl = el.querySelector('[data-test-message-time]');

      if (bodyEl) {
        const sender = senderEl?.innerText?.trim() || 'Unknown';
        const rawTimestamp = timeEl?.innerText?.trim() || null;
        messages.push({
          sender,
          body: bodyEl.innerText?.trim() || '',
          timestamp: normalizeTimestamp(rawTimestamp),
          direction: getDirection(sender, contactName),
        });
      }
    });

    log('Extracted recruiter messages count:', messages.length);
    return messages;
  }

  function extractMessages(contactName) {
    return isRecruiter() ? extractRecruiterMessages(contactName) : extractRegularMessages(contactName);
  }

  // ---- Contact extraction with retry ----
  async function extractContactWithRetry() {
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      const contact = extractContact();
      if (contact) return contact;
      if (attempt < MAX_RETRIES - 1) {
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
      }
    }
    return null;
  }

  // ---- Messaging detection & reporting ----
  function isSameContact(a, b) {
    if (!a || !b) return false;
    if (a.linkedinId && b.linkedinId) return a.linkedinId === b.linkedinId;
    return a.name === b.name && a.source === b.source;
  }

  async function detectAndReport() {
    if (!isMessagingThread()) {
      if (lastReportedContact !== null) {
        lastReportedContact = null;
        try {
          chrome.runtime.sendMessage({ type: 'messaging-thread-cleared' });
        } catch (e) {
          log('Failed to send cleared message:', e);
        }
      }
      return;
    }

    const contact = await extractContactWithRetry();
    if (!contact) {
      log('Could not extract contact info after retries.');
      return;
    }

    if (isSameContact(contact, lastReportedContact)) {
      return;
    }

    lastReportedContact = contact;
    const payload = {
      contact,
      threadUrl: location.href,
    };

    log('Thread detected:', payload);
    try {
      chrome.runtime.sendMessage({ type: 'messaging-thread-detected', payload });
    } catch (e) {
      log('Failed to send thread detected:', e);
    }
  }

  function debouncedDetect() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(detectAndReport, DEBOUNCE_MS);
  }

  // ---- SPA navigation interception ----
  function interceptHistoryMethod(method) {
    const original = history[method];
    history[method] = function (...args) {
      const result = original.apply(this, args);
      onUrlChange();
      return result;
    };
  }

  function onUrlChange() {
    const newUrl = location.href;
    if (newUrl === lastUrl) return;
    lastUrl = newUrl;
    debouncedDetect();
  }

  interceptHistoryMethod('pushState');
  interceptHistoryMethod('replaceState');
  window.addEventListener('popstate', onUrlChange);

  // Polling fallback for SPA navigation that bypasses history API
  pollTimer = setInterval(() => {
    onUrlChange();
  }, POLL_INTERVAL_MS);

  // ---- Message listeners ----
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'capture-chat-request') {
      log('Capture request received');
      const contact = extractContact();
      log('Contact:', contact?.name || 'none');
      const messages = extractMessages(contact?.name);
      log('Messages:', messages.length);

      if (messages.length === 0) {
        // Return debug info when no messages found
        sendResponse({
          ok: false,
          error: 'No messages found. Check console for selector debug info.',
          messages: [],
          contact,
          threadUrl: location.href,
          messageCount: 0,
        });
        return true;
      }

      sendResponse({
        ok: true,
        messages,
        contact,
        threadUrl: location.href,
        messageCount: messages.length,
      });
      return true;
    }

    if (message?.type === 'get-current-contact') {
      log('Get current contact request received.');
      if (isMessagingThread()) {
        const contact = extractContact();
        sendResponse({ contact, threadUrl: location.href });
      } else {
        sendResponse({ contact: null });
      }
      return true;
    }

    return false;
  });

  // ---- Initial detection ----
  if (isMessagingPage()) {
    log('Content script loaded on messaging page.');
    debouncedDetect();
  }
})();
