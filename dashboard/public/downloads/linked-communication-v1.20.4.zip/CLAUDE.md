# Claude Code Instructions

## Version Management

**ALWAYS increment the version in `manifest.json` when making any code changes.**

- Use semantic versioning: `MAJOR.MINOR.PATCH`
- Increment PATCH for bug fixes and small changes
- Increment MINOR for new features
- Increment MAJOR for breaking changes

## Project Structure

- `extension/` - Chrome extension source code
- `extension/popup.js` - Popup UI logic
- `extension/sidepanel.js` - Side panel UI logic (keep in sync with popup.js)
- `extension/services/XanoClient.js` - API client for Xano backend
- `manifest.json` - Extension manifest (contains version)

## Code Sync

When modifying UI logic, ensure changes are applied to BOTH:
- `extension/popup.js`
- `extension/sidepanel.js`

These files share similar functionality and should stay in sync.
