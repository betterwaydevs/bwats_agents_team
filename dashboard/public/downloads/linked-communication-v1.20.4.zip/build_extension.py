#!/usr/bin/env python3
"""Package the Linked Communication extension into a distributable ZIP archive.

This script bundles the minimum files Chrome needs (the manifest and the
`extension/` directory) into `dist/linked_communication-<version>.zip`. The
version number is read directly from `manifest.json` so the archive name always
matches the extension build.

Usage:
    python build_extension.py            # writes to dist/linked_communication-<version>.zip
    python build_extension.py --output custom.zip  # custom file name inside dist/
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable
from zipfile import ZIP_DEFLATED, ZipFile

# Directories that should never be packaged.
EXCLUDED_DIR_NAMES = {
    '.git',
    '.idea',
    '.vscode',
    '__pycache__',
    '.DS_Store',
    'node_modules',
    'dist',
}

# Individual files to skip regardless of location.
EXCLUDED_FILE_NAMES = {
    '.DS_Store',
    'Thumbs.db',
}

REPO_ROOT = Path(__file__).resolve().parent
MANIFEST_PATH = REPO_ROOT / 'manifest.json'
DIST_DIR = REPO_ROOT / 'dist'


def is_excluded(path: Path) -> bool:
    """Return True if *path* should be skipped from the archive."""
    for part in path.parts:
        if part in EXCLUDED_DIR_NAMES:
            return True
    return path.name in EXCLUDED_FILE_NAMES


def iter_files(base: Path) -> Iterable[Path]:
    """Yield all files under *base* that are not excluded."""
    for path in base.rglob('*'):
        if path.is_file() and not is_excluded(path.relative_to(REPO_ROOT)):
            yield path


def load_version() -> str:
    try:
        with MANIFEST_PATH.open('r', encoding='utf-8') as fh:
            manifest = json.load(fh)
        version = manifest.get('version')
        if not version:
            raise ValueError('Missing "version" in manifest.json')
        return str(version)
    except FileNotFoundError as exc:
        raise SystemExit('manifest.json not found; cannot determine version.') from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f'Failed to parse manifest.json: {exc}') from exc


def build_zip(output_name: str | None) -> Path:
    version = load_version()
    default_name = f'linked_communication-{version}.zip'
    archive_name = output_name or default_name

    print(f'Building extension version {version}...')
    
    # Validate required files exist
    required_files = [
        'extension/background.js',
        'extension/popup.html',
        'extension/popup.js',
        'extension/content-capture.js',
    ]
    
    for req_file in required_files:
        file_path = REPO_ROOT / req_file
        if not file_path.exists():
            raise SystemExit(f'Required file missing: {req_file}')
    
    print('✓ All required files found')

    DIST_DIR.mkdir(exist_ok=True)
    archive_path = DIST_DIR / archive_name

    file_count = 0
    with ZipFile(archive_path, 'w', ZIP_DEFLATED) as zf:
        # Always include the manifest at the root of the archive.
        zf.write(MANIFEST_PATH, arcname='manifest.json')
        file_count += 1

        # Include everything inside the extension directory.
        extension_root = REPO_ROOT / 'extension'
        if not extension_root.exists():
            raise SystemExit('extension/ directory not found; nothing to package.')

        for file_path in iter_files(extension_root):
            relative_path = file_path.relative_to(REPO_ROOT)
            zf.write(file_path, arcname=str(relative_path))
            file_count += 1
    
    # Get archive size
    size_bytes = archive_path.stat().st_size
    size_kb = size_bytes / 1024
    size_mb = size_kb / 1024
    
    if size_mb >= 1:
        size_str = f'{size_mb:.2f} MB'
    else:
        size_str = f'{size_kb:.2f} KB'
    
    print(f'✓ Packaged {file_count} files ({size_str})')

    return archive_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        '--output',
        '-o',
        metavar='NAME',
        help='Custom archive file name (placed inside the dist/ directory).',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    archive_path = build_zip(args.output)
    print(f'\n✓ Successfully created: {archive_path.relative_to(REPO_ROOT)}')
    print(f'  Ready to upload to Chrome Web Store!')


if __name__ == '__main__':
    main()
