const fs = require('fs');
const path = require('path');

describe('InvitationScraper', () => {
  const fixturePath = path.join(__dirname, 'html', 'invitations.html');
  const htmlFixture = fs.readFileSync(fixturePath, 'utf8');

  let InvitationScraper;
  let InvitationStore;

  beforeAll(() => {
    // eslint-disable-next-line global-require
    ({ InvitationScraper } = require('../src/InvitationScraper'));
    ({ InvitationStore } = require('../src/InvitationStore'));
  });

  it('extracts every invitation from the fixture', () => {
    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(htmlFixture);

    expect(Array.isArray(records)).toBe(true);
    expect(records.length).toBeGreaterThan(0);

    const uniqueSlugs = new Set(records.map((record) => record.Connection_Profile_URL));
    expect(uniqueSlugs.size).toBe(records.length);
    expect(store.size()).toBe(records.length);
  });

  it('parses core fields for a known invitation', () => {
    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(htmlFixture);

    const sample = records.find(
      (record) => record.Connection_Profile_URL === 'carlosrcolon'
    );

    if (!sample) {
      // eslint-disable-next-line no-console
      console.log('Parsed invitations snapshot:', records);
    }

    expect(sample).toEqual(
      expect.objectContaining({
        First_Name: expect.stringMatching(/carlos/i),
        Last_Name: expect.stringMatching(/col[oó]n/i),
        Position: expect.stringContaining('AD-Tech platform'),
        Connection_Profile_URL: 'carlosrcolon',
        Message: expect.stringContaining('BetterWay Devs CEO'),
        Invited_On: expect.stringMatching(/\d{4}-\d{2}-\d{2}/),
      })
    );
  });

  it('reports total count metadata when requested', () => {
    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const result = scraper.scrapeWithMetadata(htmlFixture);

    expect(result).toEqual(
      expect.objectContaining({
        records: expect.any(Array),
        totalCount: expect.any(Number),
      })
    );

    expect(result.records.length).toBe(result.totalCount);
    expect(result.totalCount).toBe(7);
    expect(store.size()).toBe(7);
  });

  it('parses "Sent Today" as today\'s date', () => {
    const htmlWithToday = `
      <div id="workspace">
        <div role="listitem">
          <p><a href="https://www.linkedin.com/in/test-user/">Test User</a></p>
          <p>Software Engineer</p>
          <p>Sent Today</p>
        </div>
      </div>
    `;

    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(htmlWithToday);

    expect(records.length).toBe(1);
    
    const todayDate = new Date().toISOString().slice(0, 10);
    expect(records[0].Invited_On).toBe(todayDate);
  });

  it('defaults to today\'s date when date text cannot be parsed', () => {
    const htmlWithUnknownDate = `
      <div id="workspace">
        <div role="listitem">
          <p><a href="https://www.linkedin.com/in/test-user/">Test User</a></p>
          <p>Software Engineer</p>
          <p>Invited on unparseable-date-format</p>
        </div>
      </div>
    `;

    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(htmlWithUnknownDate);

    expect(records.length).toBe(1);
    
    const todayDate = new Date().toISOString().slice(0, 10);
    expect(records[0].Invited_On).toBe(todayDate);
    expect(records[0].Invited_On).not.toBeNull();
  });

  it('parses numeric relative dates such as "Sent 3 days ago"', () => {
    const html = `
      <div id="workspace">
        <div role="listitem">
          <p><a href="https://www.linkedin.com/in/test-user/">Test User</a></p>
          <p>Software Engineer</p>
          <p>Sent 3 days ago</p>
        </div>
      </div>
    `;

    const pivot = new Date();
    pivot.setDate(pivot.getDate() - 3);
    const expected = pivot.toISOString().slice(0, 10);

    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(html);

    expect(records.length).toBe(1);
    expect(records[0].Invited_On).toBe(expected);
  });

  it('parses word relative dates such as "Sent two weeks ago"', () => {
    const html = `
      <div id="workspace">
        <div role="listitem">
          <p><a href="https://www.linkedin.com/in/test-user/">Test User</a></p>
          <p>Software Engineer</p>
          <p>Sent two weeks ago</p>
        </div>
      </div>
    `;

    const pivot = new Date();
    pivot.setDate(pivot.getDate() - (2 * 7));
    const expected = pivot.toISOString().slice(0, 10);

    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(html);

    expect(records.length).toBe(1);
    expect(records[0].Invited_On).toBe(expected);
  });

  it('falls back to today when date paragraph is missing entirely', () => {
    const html = `
      <div id="workspace">
        <div role="listitem">
          <p><a href="https://www.linkedin.com/in/test-user/">Test User</a></p>
          <p>Software Engineer</p>
        </div>
      </div>
    `;

    const todayDate = new Date().toISOString().slice(0, 10);

    const store = new InvitationStore();
    const scraper = new InvitationScraper(store);
    const records = scraper.scrapeFromHtml(html);

    expect(records.length).toBe(1);
    expect(records[0].Invited_On).toBe(todayDate);
  });
});
