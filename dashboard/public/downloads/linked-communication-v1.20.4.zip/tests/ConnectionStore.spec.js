const { ConnectionStore } = require('../src/ConnectionStore');

describe('ConnectionStore (basic scenarios)', () => {
  const sample = (overrides = {}) => {
    const generatedUserId = `user-${Math.random().toString(36).slice(2, 8)}`;
    const generatedSlug = `slug-${Math.random().toString(36).slice(2, 8)}`;

    return {
      user_id: generatedUserId,
      First_Name: 'Jane',
      Last_Name: 'Doe',
      Connection_Profile_URL: generatedSlug,
      Email_Address: null,
      Company: 'Acme',
      Position: 'Engineer at Acme',
      Connected_On: 'Connected on September 19, 2025',
      ...overrides,
    };
  };

  it('adds a single connection and retrieves it', () => {
    const connection = sample({ user_id: 'user-1', Connection_Profile_URL: 'user-1-slug' });
    const store = new ConnectionStore();

    store.add(connection);

    const result = store.getById('user-1-slug');
    expect(result).toEqual(connection);
    expect(store.size()).toBe(1);
  });

  it('adds multiple connections and retrieves them all', () => {
    const store = new ConnectionStore();
    const connections = [
      sample({ user_id: 'user-1', Connection_Profile_URL: 'user-1-slug' }),
      sample({ user_id: 'user-2', Connection_Profile_URL: 'user-2-slug' }),
      sample({ user_id: 'user-3', Connection_Profile_URL: 'user-3-slug' }),
    ];

    store.addMany(connections);

    expect(store.size()).toBe(3);
    expect(store.getAll()).toEqual(connections);
  });

  it('clears connections and returns to empty state', () => {
    const store = new ConnectionStore();
    store.add(sample({ user_id: 'user-1', Connection_Profile_URL: 'user-1-slug' }));

    store.clear();

    expect(store.size()).toBe(0);
    expect(store.getAll()).toEqual([]);
  });

  it('new store starts empty', () => {
    const store = new ConnectionStore();
    expect(store.size()).toBe(0);
    expect(store.getAll()).toEqual([]);
  });

  it('display logs formatted connections', () => {
    const store = new ConnectionStore();
    const connection = sample({
      user_id: 'user-1',
      First_Name: 'Carlos',
      Last_Name: 'Ortiz',
      Position: 'Software Developer at LinkedIn',
      Connected_On: 'Connected on October 2, 2025',
      Connection_Profile_URL: 'carlos-ortiz',
      Company: 'LinkedIn',
    });

    store.add(connection);

    const groupSpy = jest.spyOn(console, 'group').mockImplementation(() => {});
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const groupEndSpy = jest.spyOn(console, 'groupEnd').mockImplementation(() => {});

    store.display();

    expect(groupSpy).toHaveBeenCalledWith('Linked Communication Connections');
    expect(logSpy).toHaveBeenCalledWith('#1', expect.objectContaining({
      user_id: 'user-1',
      First_Name: 'Carlos',
      Last_Name: 'Ortiz',
      Position: 'Software Developer at LinkedIn',
      Connected_On: 'Connected on October 2, 2025',
      Connection_Profile_URL: 'carlos-ortiz',
      Company: 'LinkedIn',
      Email_Address: null,
    }));
    const jsonCall = logSpy.mock.calls.find((call) => call[0] === 'JSON payload:');
    expect(jsonCall).toBeDefined();
    expect(jsonCall[1]).toEqual([
      expect.objectContaining({
        user_id: 'user-1',
        First_Name: 'Carlos',
        Last_Name: 'Ortiz',
        Position: 'Software Developer at LinkedIn',
        Connected_On: 'Connected on October 2, 2025',
        Connection_Profile_URL: 'carlos-ortiz',
        Company: 'LinkedIn',
        Email_Address: null,
      }),
    ]);
    expect(groupEndSpy).toHaveBeenCalled();

    groupSpy.mockRestore();
    logSpy.mockRestore();
    groupEndSpy.mockRestore();
  });
});
