const fs = require('fs');
const path = require('path');
const { ConnectionStore } = require('../src/ConnectionStore');
const { ConnectionScraper } = require('../src/ConnectionScraper');

describe('ConnectionScraper', () => {
  const fixturePath = path.join(__dirname, 'html', 'connections.html');
  const htmlFixture = fs.readFileSync(fixturePath, 'utf8');

  it('scrapes connections into the store', () => {
    const store = new ConnectionStore({ capacity: 200 });
    const scraper = new ConnectionScraper(store);

    const records = scraper.scrapeFromHtml(htmlFixture);

    expect(records.length).toBeGreaterThan(0);
    expect(store.size()).toBe(records.length);

    const first = records[0];
    expect(first.user_id).toBe('testlinkedinuser');
    expect(first.First_Name).toBeTruthy();
    expect(first.First_Name).not.toBe('Message');
    expect(first.Connection_Profile_URL).toMatch(/[a-z0-9-]+/i);
    expect(first.Email_Address).toBeNull();
  });

  it('parses specific connection fields from fixture', () => {
    const store = new ConnectionStore({ capacity: 200 });
    const scraper = new ConnectionScraper(store);

    const records = scraper.scrapeFromHtml(htmlFixture);

    expect(records).toHaveLength(126);

    const jordy = records.find((record) =>
      record.Connection_Profile_URL === 'jordy-holguin-13768435a'
    );

    if (!jordy) {
      // Provide insight into the parsed records when the assertion fails.
      // eslint-disable-next-line no-console
      console.log('Fixture records snapshot:', records);
    }

    expect(jordy).toEqual(
      expect.objectContaining({
        user_id: 'testlinkedinuser',
        First_Name: 'Jordy',
        Last_Name: 'Holguin',
        Position: 'Software Developer | DevOps | Back-End Developer | AWS-SDK-CDK | Azure | Linux | Docker | Web Scrapping | Node.js',
        Connected_On: 'Connected on August 28, 2025',
        Connection_Profile_URL: 'jordy-holguin-13768435a',
        Email_Address: null,
      })
    );

    const jesus = records.find((record) =>
      record.Connection_Profile_URL === 'jesusdavidprieto'
    );

    if (!jesus) {
      // eslint-disable-next-line no-console
      console.log('Jesús Prieto not found. Available slugs:', records.map(r => r.Connection_Profile_URL));
    }

    expect(jesus).toEqual(
      expect.objectContaining({
        user_id: 'testlinkedinuser',
        First_Name: 'Jesús',
        Last_Name: 'Prieto',
        Position: 'CEO and Founder at Synergy + Founder House | Ecosystem Builder | Community Builder | Notion Ambassador | Entrepreneur',
        Connected_On: 'Connected on October 10, 2025',
        Connection_Profile_URL: 'jesusdavidprieto',
        Email_Address: null,
      })
    );
  });

  it('does not duplicate entries when scraping twice', () => {
    const store = new ConnectionStore({ capacity: 200 });
    const scraper = new ConnectionScraper(store);

    scraper.scrapeFromHtml(htmlFixture);
    scraper.scrapeFromHtml(htmlFixture);
    const slugs = store.getAll().map((record) => record.Connection_Profile_URL);
    const uniqueSlugs = new Set(slugs);

    expect(uniqueSlugs.size).toBe(slugs.length);
  });

  it('extracts clean names without including role or headline text', () => {
    const store = new ConnectionStore();
    const scraper = new ConnectionScraper(store);

    const records = scraper.scrapeFromHtml(htmlFixture);

    const roleKeywords = /\b(Engineer|Developer|Designer|Founder|CEO|Officer|Consultant|Director|President|Manager|Builder|Professional|Technologist|Ambassador|Notion|Synergy|House|Ecosystem|Community|UX|UI)\b/i;

    records.forEach((record) => {
      expect(record.First_Name).toBeTruthy();
      expect(record.Last_Name).toBeTruthy();
      expect(record.First_Name).not.toMatch(roleKeywords);
      expect(record.Last_Name).not.toMatch(roleKeywords);
      expect(record.First_Name.trim()).toBe(record.First_Name);
      expect(record.Last_Name.trim()).toBe(record.Last_Name);
    });
  });
});
