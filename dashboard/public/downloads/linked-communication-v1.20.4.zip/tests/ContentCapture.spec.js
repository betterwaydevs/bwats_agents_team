const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

describe('ContentCapture (Live Scraper)', () => {
  const fixturePath = path.join(__dirname, 'html', 'connections.html');
  const htmlFixture = fs.readFileSync(fixturePath, 'utf8');
  const contentCapturePath = path.join(__dirname, '..', 'extension', 'content-capture.js');
  const contentCaptureCode = fs.readFileSync(contentCapturePath, 'utf8');

  let dom;
  let window;
  let scrapeConnections;

  beforeEach(() => {
    // Create a fresh DOM for each test
    dom = new JSDOM(htmlFixture, {
      url: 'https://www.linkedin.com/mynetwork/invite-connect/connections/',
      runScripts: 'dangerously',
      resources: 'usable',
    });
    window = dom.window;
    global.window = window;
    global.document = window.document;

    // Mock chrome API
    window.chrome = {
      runtime: {
        id: 'test-extension-id',
        sendMessage: jest.fn().mockResolvedValue(undefined),
      },
      storage: {
        local: {
          get: jest.fn().mockResolvedValue({}),
          remove: jest.fn().mockResolvedValue(undefined),
        },
      },
    };

    // Execute content-capture.js using vm.runInContext approach
    const script = window.document.createElement('script');
    script.textContent = contentCaptureCode;
    window.document.body.appendChild(script);

    // Extract the exposed function
    scrapeConnections = window.LinkedCommunicationContentCapture?.scrapeConnections;
  });

  afterEach(() => {
    if (dom) {
      dom.window.close();
    }
  });

  it('exposes scrapeConnections function', () => {
    expect(scrapeConnections).toBeDefined();
    expect(typeof scrapeConnections).toBe('function');
  });

  it('scrapes connections from live HTML', () => {
    const records = scrapeConnections({ ownerId: 1 });

    expect(Array.isArray(records)).toBe(true);
    expect(records.length).toBeGreaterThan(0);

    const first = records[0];
    expect(first).toHaveProperty('user_id');
    expect(first).toHaveProperty('First_Name');
    expect(first).toHaveProperty('Last_Name');
    expect(first).toHaveProperty('Connection_Profile_URL');
    expect(first).toHaveProperty('Position');
    expect(first).toHaveProperty('Connected_On');
  });

  it('parses Jordy Holguin correctly', () => {
    const records = scrapeConnections({ ownerId: 1 });

    const jordy = records.find((record) =>
      record.Connection_Profile_URL === 'jordy-holguin-13768435a'
    );

    expect(jordy).toBeDefined();
    expect(jordy.First_Name).toBe('Jordy');
    expect(jordy.Last_Name).toBe('Holguin');
    expect(jordy.Position).toContain('Software Developer');
  });

  it('parses Jesús Prieto correctly (name is clean)', () => {
    const records = scrapeConnections({ ownerId: 1 });

    const jesus = records.find((record) =>
      record.Connection_Profile_URL === 'jesusdavidprieto'
    );

    if (!jesus) {
      // eslint-disable-next-line no-console
      console.log('Jesús Prieto not found. Available slugs:', records.map(r => r.Connection_Profile_URL).slice(0, 10));
    }

    expect(jesus).toBeDefined();
    expect(jesus.First_Name).toBe('Jesús');
    expect(jesus.Last_Name).toBe('Prieto');
    expect(jesus.Connection_Profile_URL).toBe('jesusdavidprieto');
    expect(jesus.Position).toBe('CEO and Founder at Synergy + Founder House | Ecosystem Builder | Community Builder | Notion Ambassador | Entrepreneur');
    expect(jesus.Connected_On).toBe('Connected on October 10, 2025');
    
    // Verify name doesn't contain headline text
    expect(jesus.First_Name).not.toContain('CEO');
    expect(jesus.First_Name).not.toContain('Founder');
    expect(jesus.Last_Name).not.toContain('Entrepreneur');
  });
});
