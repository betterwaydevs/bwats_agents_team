const { LongTermMemory, InMemoryStorage } = require('../src/LongTermMemory');
const { DEFAULT_MEMORY } = require('../src/config/memoryDefaults');

describe('LongTermMemory', () => {
  class MockStorage {
    constructor() {
      this.store = {};
      this.setItemSpy = jest.fn(async (key, value) => {
        this.store[key] = value;
      });
    }

    async getItem(key) {
      return this.store[key] ?? null;
    }

    async setItem(key, value) {
      await this.setItemSpy(key, value);
    }

    preload(key, value) {
      this.store[key] = JSON.stringify(value);
    }
  }

  it('retrieves stored snapshot from storage', async () => {
    const storage = new MockStorage();
    storage.preload('LongTermMemorySnapshot', {
      username: 'storedUser',
      memoryText: 'stored memory',
      lastImportConnectionDate: '2024-01-05T00:00:00.000Z',
      authToken: 'mock-token',
      userId: 'stored-user-id',
      tokenValidUntil: '2024-01-12T00:00:00.000Z',
    });

    const memory = new LongTermMemory(storage);
    await memory.load();

    expect(memory.getUsername()).toBe('storedUser');
    expect(memory.getMemoryText()).toBe('stored memory');
    expect(memory.getLastImportConnectionDate()).toBe('2024-01-05T00:00:00.000Z');
    expect(memory.getAuthToken()).toBe('mock-token');
    expect(memory.getUserId()).toBe('stored-user-id');
    expect(memory.getTokenValidUntil()).toBe('2024-01-12T00:00:00.000Z');
  });

  it('saves updated snapshot to storage', async () => {
    const storage = new MockStorage();
    const memory = new LongTermMemory(storage);

    memory.setUsername('updatedUser');
    memory.setMemoryText('updated history');
    memory.setLastImportConnectionDate('2025-02-02T12:00:00.000Z');
    memory.setAuthToken('updated-token');
    memory.setUserId('user-123');
    memory.setTokenValidUntil('2025-02-09T12:00:00.000Z');

    await memory.save();

    expect(storage.setItemSpy).toHaveBeenCalledTimes(1);
    const [key, serialized] = storage.setItemSpy.mock.calls[0];
    expect(key).toBe('LongTermMemorySnapshot');
    expect(JSON.parse(serialized)).toEqual({
      username: 'updatedUser',
      memoryText: 'updated history',
      lastImportConnectionDate: '2025-02-02T12:00:00.000Z',
      authToken: 'updated-token',
      userId: 'user-123',
      tokenValidUntil: '2025-02-09T12:00:00.000Z',
      connectionLimit: 20,
      invitationLimit: 5,
    });
  });

  it('clears auth fields when provided null', async () => {
    const storage = new MockStorage();
    const memory = new LongTermMemory(storage);

    memory.setAuthToken('temp-token');
    memory.setUserId('user-1');
    memory.setTokenValidUntil('2025-01-01T00:00:00.000Z');

    memory.setAuthToken(null);
    memory.setUserId(null);
    memory.setTokenValidUntil(null);

    await memory.save();

    const [, serialized] = storage.setItemSpy.mock.calls[0];
    const parsed = JSON.parse(serialized);
    expect(parsed.authToken).toBeNull();
    expect(parsed.userId).toBeNull();
    expect(parsed.tokenValidUntil).toBeNull();
  });
});
