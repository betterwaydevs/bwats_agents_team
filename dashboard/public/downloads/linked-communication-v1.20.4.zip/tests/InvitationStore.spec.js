const { InvitationStore } = require('../src/InvitationStore');

describe('InvitationStore (basic scenarios)', () => {
  const sample = (overrides = {}) => {
    return {
      First_Name: 'Carlos',
      Last_Name: 'Colón',
      Connection_Profile_URL: 'carlosrcolon',
      Position: 'Empowering teams to build scalable AD-Tech platform @ AMG',
      Invited_On: '2025-10-09',
      Message: 'HI Carlos, this is Pablo, BetterWay Devs CEO.',
      ...overrides,
    };
  };

  it('adds a single invitation and retrieves it', () => {
    const invitation = sample();
    const store = new InvitationStore();

    store.add(invitation);

    const result = store.getById('carlosrcolon');
    expect(result).toEqual(expect.objectContaining(invitation));
    expect(store.size()).toBe(1);
  });

  it('adds multiple invitations and retrieves them all', () => {
    const store = new InvitationStore();
    const invitations = [
      sample(),
      sample({ Connection_Profile_URL: 'jhoan-camilo-rivera-florez' }),
      sample({ Connection_Profile_URL: 'luis-fernando-martinez-carvajal-509a14171' }),
    ];

    store.addMany(invitations);

    expect(store.size()).toBe(3);
    expect(store.getAll()).toEqual(
      expect.arrayContaining(invitations.map((inv) => expect.objectContaining(inv)))
    );
  });

  it('clears invitations and returns to empty state', () => {
    const store = new InvitationStore();
    store.add(sample());

    store.clear();

    expect(store.size()).toBe(0);
    expect(store.getAll()).toEqual([]);
  });

  it('new store starts empty', () => {
    const store = new InvitationStore();
    expect(store.size()).toBe(0);
    expect(store.getAll()).toEqual([]);
  });

  it('display logs formatted invitations', () => {
    const store = new InvitationStore();
    const invitation = sample({
      First_Name: 'Carlos',
      Last_Name: 'Colón',
      Position: 'Empowering teams to build scalable AD-Tech platform @ AMG',
      Invited_On: '2025-10-09',
      Connection_Profile_URL: 'carlosrcolon',
      Message: 'HI Carlos, this is Pablo, BetterWay Devs CEO.\nSincerely, Pablo',
    });

    store.add(invitation);

    const groupSpy = jest.spyOn(console, 'group').mockImplementation(() => {});
    const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const groupEndSpy = jest.spyOn(console, 'groupEnd').mockImplementation(() => {});

    store.display();

    expect(groupSpy).toHaveBeenCalledWith('Linked Communication Invitations');
    expect(logSpy).toHaveBeenCalledWith('#1', expect.objectContaining({
      First_Name: 'Carlos',
      Last_Name: 'Colón',
      Position: 'Empowering teams to build scalable AD-Tech platform @ AMG',
      Invited_On: '2025-10-09',
      Connection_Profile_URL: 'carlosrcolon',
      Message: expect.stringContaining('BetterWay Devs CEO'),
    }));

    const jsonCall = logSpy.mock.calls.find((call) => call[0] === 'JSON payload:');
    expect(jsonCall).toBeDefined();
    expect(jsonCall[1]).toEqual([
      expect.objectContaining({
        First_Name: 'Carlos',
        Last_Name: 'Colón',
        Position: 'Empowering teams to build scalable AD-Tech platform @ AMG',
        Invited_On: '2025-10-09',
        Connection_Profile_URL: 'carlosrcolon',
        Message: expect.stringContaining('BetterWay Devs CEO'),
      }),
    ]);

    groupSpy.mockRestore();
    logSpy.mockRestore();
    groupEndSpy.mockRestore();
  });
});
