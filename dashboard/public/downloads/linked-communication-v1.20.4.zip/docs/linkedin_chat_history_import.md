# LinkedIn Chat History Capture - Implementation Summary

## Branch: `feature/linkedin-history-capture`
## Version: 1.19.0

## What Was Done

Added a new feature to detect when the user is on a LinkedIn messaging thread (regular or recruiter), extract contact info, display it in a new "Chat" tab in the sidepanel/popup, and provide a "Capture Chat" button to extract the full conversation.

**ATS API calls (`lookupCandidate`, `captureConversation`) are placeholder stubs** — they log to console and return mock responses. These need real endpoints wired up later.

## Files Created

### `extension/messaging-detector.js`
New content script (~230 lines) injected on LinkedIn messaging pages. IIFE that:
- Detects regular (`/messaging/thread/`) and recruiter (`/talent/inbox/`) URLs
- Intercepts SPA navigation via `pushState`/`replaceState`/`popstate` + 2s polling fallback
- Extracts contact info (name, headline, avatar, profile URL, LinkedIn ID) with DOM selectors for both regular and recruiter views
- Extracts chat messages (sender, body, timestamp) for both views
- Auto-detects thread changes with 500ms debounce; sends `messaging-thread-detected` / `messaging-thread-cleared` to background
- Responds to `capture-chat-request` from background by extracting and returning all messages
- Retries contact extraction 3x with 1s delay (LinkedIn loads async)
- Skips re-reporting if same contact already detected

## Files Modified

### `manifest.json`
- Version bumped `1.18.18` → `1.19.0`
- Added third `content_scripts` entry for `messaging-detector.js` on `/messaging/*` and `/talent/inbox/*`

### `extension/background.js`
Added 3 message handlers in the main `onMessage` listener:
1. **`messaging-thread-detected`** — relays contact info to sidepanel via `runtime.sendMessage` + `broadcastToClients`
2. **`messaging-thread-cleared`** — relays cleared state to sidepanel (same dual-send pattern)
3. **`capture-chat`** — async handler that finds LinkedIn messaging tab, sends `capture-chat-request` to content script, returns messages to sidepanel

### `extension/services/XanoClient.js`
Added 2 stub methods before `#extractExpirySeconds`:
- `lookupCandidate(authToken, { linkedinId, name, source })` — returns `{ found: false, candidate: null, _stub: true }`
- `captureConversation(authToken, { candidate, conversation })` — returns `{ success: true, _stub: true }`

### `extension/sidepanel.html` + `extension/popup.html`
- Added "Chat" tab button in the nav bar
- Added Chat tab panel section with: empty state message, contact card (avatar, name, headline, source badge, profile link), ATS lookup placeholder, "Capture Chat" button, capture status area

### `extension/popup.css`
Added Chat tab styles: `.chat-empty-state`, `.chat-contact`, `.chat-contact-header`, `.chat-contact-avatar`, `.chat-contact-info`, `.chat-contact-name`, `.chat-contact-headline`, `.chat-contact-meta`, `.chat-profile-link`, `.chat-ats-lookup`, `.chat-actions`, `.chat-capture-status`

### `extension/sidepanel.js` + `extension/popup.js` (identical changes)
- Added global: `let currentChatContact = null;`
- Added `setupChatTab()` function (~110 lines) after `setupTabs()`:
  - Listens for `messaging-contact-update` and `messaging-contact-cleared` via both `chrome.runtime.onMessage` and `serviceWorker.message`
  - `showContact(contact)` — updates UI with name, headline, initials/avatar, source badge, profile link
  - `clearContact()` — resets to empty state
  - Capture button click handler: sends `capture-chat` to background, shows success/error status + toast
- Called `setupChatTab()` in `initialize()` after `setupTabs()`

## Message Flow

```
LinkedIn Page (messaging-detector.js)
  → chrome.runtime.sendMessage({ type: 'messaging-thread-detected', payload })
    → background.js receives, relays as 'messaging-contact-update'
      → sidepanel.js / popup.js setupChatTab() listener updates Chat tab UI

User clicks "Capture Chat" in sidepanel
  → chrome.runtime.sendMessage({ type: 'capture-chat' })
    → background.js finds LinkedIn messaging tab
      → chrome.tabs.sendMessage({ type: 'capture-chat-request' })
        → messaging-detector.js extracts messages, returns via sendResponse
      → background.js returns messages to sidepanel via sendResponse
    → sidepanel shows success/error status
```

## What Still Needs Work

1. **DOM selectors** — The selectors in `messaging-detector.js` for contact and message extraction are best-guesses based on known LinkedIn class patterns. They will likely need adjustment after testing against the live LinkedIn DOM.
2. **Real ATS API endpoints** — Replace the stub methods in `XanoClient.js` with actual Xano API calls.
3. **Capture persistence** — Currently the captured messages are returned but not stored anywhere. Wire `captureConversation` to actually save them.
4. **ATS lookup on contact detect** — Currently the Chat tab shows "Not available (stub)". Wire `lookupCandidate` to run when a contact is detected and display real results.

## Testing Checklist

1. Load unpacked extension, navigate to LinkedIn messaging thread — "Chat" tab should show detected contact info
2. Switch threads — contact info should update
3. Navigate away from messaging — Chat tab should show empty state
4. Click "Capture Chat" — should show success toast with message count
5. Check console for `[XanoClient]` stub log messages
6. Test with both `/messaging/thread/` and `/talent/inbox/` URLs
