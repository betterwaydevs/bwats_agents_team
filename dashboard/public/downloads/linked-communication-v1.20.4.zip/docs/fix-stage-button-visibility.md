# Fix: Move to Stage Button Not Showing

## Problem
The "Move to Stage" button is gated on `task.payload.association_id`, but that field is not present in the task data. Since tasks can only be created for associated people (especially outreach tasks), the project ID is sufficient to determine eligibility.

## Root Cause
In `buildTaskActions()` (both `popup.js` and `sidepanel.js`):
```js
if (payload.association_id) {
  line5Html += `<button ... data-action="move-to-stage">Move to Stage</button>`;
}
```
This condition never evaluates to true because `association_id` isn't in the payload.

## Files to Change

### 1. `extension/popup.js` and `extension/sidepanel.js` — Button Visibility

**In `buildTaskActions()`**, change the condition from `payload.association_id` to checking for a project ID:

```js
// BEFORE (popup.js ~line 919, sidepanel.js ~line 921)
if (payload.association_id) {

// AFTER
const hasProject = task._project?.id || task.project?.id || task.project_id;
if (hasProject) {
```

### 2. `extension/popup.js` and `extension/sidepanel.js` — Association ID Lookup

The `changeAssociationStage` API call still needs an `association_id`. Two options:

**Option A: Look up association ID from person + project**
- Add a new XanoClient method to look up the association by person ID + project ID
- Call it when the user clicks "Confirm" in the stage panel
- Endpoint would be something like `GET /association?person_id=X&project_id=Y`

**Option B: Accept project + person IDs in the change-stage API**
- If the backend can resolve the association from project + person, change the API call body to send `project_id` + `person_id` instead of `association_id`

**Option C: The association ID exists but at a different path in the task object**
- Check the full task JSON in DevTools (`console.log(JSON.stringify(task, null, 2))`)
- It might be at `task.project_person_association_id`, `task.person?.association_id`, `task._project?.association_id`, etc.
- If found, update the lookup path in both `renderStagePanel()` and `confirm-stage-change` handler

### 3. `extension/popup.js` and `extension/sidepanel.js` — `renderStagePanel()`

Update the `associationId` extraction (~line 778 popup, ~line 780 sidepanel):

```js
// BEFORE
const associationId = task.payload?.association_id;

// AFTER — adjust based on which option above is chosen
const associationId = task.payload?.association_id
  || task.project_person_association_id
  || task.person?.association_id;
```

Also consider removing (or softening) the early-return error for missing `associationId` if using Option A/B, since it won't be needed upfront.

### 4. `confirm-stage-change` handler

Same `associationId` extraction fix (~line 2144 popup, ~line 2077 sidepanel):

```js
// BEFORE
const associationId = task.payload?.association_id;

// AFTER
const associationId = task.payload?.association_id
  || task.project_person_association_id
  || task.person?.association_id;
```

## Debugging Step
Before implementing, log a task object to find where the association ID lives:
```js
// Temporarily add in attachTaskActionHandlers, right after the function signature:
console.log('Task data:', JSON.stringify(task, null, 2));
```

## Quick Checklist
- [ ] Identify correct path for association ID (or confirm it's absent and needs lookup)
- [ ] Update button visibility condition in `buildTaskActions()` — both files
- [ ] Update `associationId` extraction in `renderStagePanel()` — both files
- [ ] Update `associationId` extraction in `confirm-stage-change` handler — both files
- [ ] If association ID is truly absent, add lookup method to XanoClient or adjust backend
- [ ] Test: button shows on tasks with a project
- [ ] Test: stage change completes successfully
