# Bot Detection Vulnerability Analysis

## Summary
Review of patterns in the extension that could be detected by LinkedIn/Chrome as automated bot behavior rather than genuine user interaction.

---

## HIGH PRIORITY ISSUES

### 1. `isTrusted` Property Missing
**Files:** `popup.js`, `sidepanel.js`, `linkedin-actions.js`

**Problem:** All dispatched events (MouseEvent, KeyboardEvent, InputEvent) have `isTrusted: false` by default. LinkedIn can check `event.isTrusted` to detect synthetic events - real user events always have `isTrusted: true`.

**Detection Risk:** HIGH - LinkedIn can simply check `if (!event.isTrusted) return;` to block all synthetic interactions.

**Fix:** Cannot be fixed via JavaScript alone. The `isTrusted` property is read-only and set by the browser. Possible mitigations:
- Use Chrome Debugger API (`chrome.debugger`) with `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent` - these create trusted events
- Use `chrome.input.ime` API for text input (limited support)

---

### 2. `document.execCommand('insertText')` is Deprecated
**Files:** `popup.js:1376`, `sidepanel.js:1297`

**Problem:** `document.execCommand` is deprecated and may be monitored/blocked. It's a known automation pattern.

**Detection Risk:** MEDIUM-HIGH

**Fix:** Use `InputEvent` with proper `inputType` and modify the DOM directly, or use the Debugger API.

---

### 3. Predictable Timing Patterns
**Files:** Multiple

**Problem:** Timing delays are predictable:
- `TYPING_MIN_DELAY = 30ms`, `TYPING_MAX_DELAY = 80ms` - Very narrow range
- Action delays are fixed: `1000ms` between clicks
- Humans have much more variance (50-300ms typing, 200-2000ms between actions)

**Detection Risk:** MEDIUM - Statistical analysis can detect unnaturally consistent timing.

**Fix:**
```javascript
// Current (detectable)
const TYPING_MIN_DELAY = 30;
const TYPING_MAX_DELAY = 80;

// Better (more human-like)
const TYPING_MIN_DELAY = 50;
const TYPING_MAX_DELAY = 250;
// Add occasional longer pauses (thinking time)
if (Math.random() < 0.1) await sleep(randomDelay(300, 800));
```

---

### 4. Missing Realistic Mouse Movement
**Files:** `popup.js`, `sidepanel.js`

**Problem:** Click events are dispatched directly on target without simulating mouse movement path. Real users move mouse from current position to target with intermediate `mousemove` events.

**Detection Risk:** MEDIUM

**Fix:** Generate intermediate `mousemove` events along a bezier curve path before click.

---

### 5. Global Window Variables Exposed
**Files:** `linkedin-actions.js:123-128`

**Problem:**
```javascript
window.__linkedInAutoConnect = autoConnect;
window.__linkedInAutoConnectMessage = ...;
window.__linkedInAutoConnectResult = ...;
```
LinkedIn can detect these global variables as automation indicators.

**Detection Risk:** MEDIUM

**Fix:** Use `Symbol()` keys or avoid exposing globals entirely. Use message passing instead.

---

## MEDIUM PRIORITY ISSUES

### 6. Event Sequence Incomplete
**Problem:** Real interactions include more events:
- Missing `pointermove`, `pointerdown`, `pointerup` events
- Missing `focusin`, `focusout` events
- Missing `beforeinput` event before `input`

**Fix:** Add complete event sequence:
```javascript
// Before click
element.dispatchEvent(new PointerEvent('pointermove', {...}));
element.dispatchEvent(new PointerEvent('pointerdown', {...}));
// After click
element.dispatchEvent(new PointerEvent('pointerup', {...}));
```

---

### 7. KeyboardEvent Missing Properties
**Files:** `popup.js:1064-1066`, `sidepanel.js:1054-1056`

**Problem:** KeyboardEvents are missing realistic properties:
```javascript
// Current
{ key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }

// Missing: location, repeat, isComposing, ctrlKey, shiftKey, altKey, metaKey
```

**Fix:** Add all keyboard event properties that browsers normally include.

---

### 8. No Scroll Before Click
**Problem:** Users naturally scroll elements into view before clicking. Current code avoids scroll (`preventScroll: true`) which is unnatural for elements not in viewport.

**Fix:** For elements near viewport edge, simulate natural scroll behavior first.

---

### 9. Console Logging Reveals Automation
**Files:** All files with `console.log('[LinkedComm]...')`

**Problem:** LinkedIn could monitor console output for automation signatures.

**Detection Risk:** LOW-MEDIUM

**Fix:** Remove or obfuscate logging in production, or use conditional logging only in development.

---

## LOW PRIORITY ISSUES

### 10. InputEvent Missing `dataTransfer`
For paste operations, real `InputEvent` includes `dataTransfer` property.

### 11. Fixed Viewport Check
`isVisible()` checks exact viewport bounds - real users can click elements partially visible.

### 12. No Touch Event Support
Missing touch events for users who might be on touch devices.

---

## RECOMMENDED FIXES (Priority Order)

1. **Use Chrome Debugger API** for trusted events (HIGH IMPACT)
   ```javascript
   await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
     type: 'mousePressed',
     x: rect.left + rect.width / 2,
     y: rect.top + rect.height / 2,
     button: 'left',
     clickCount: 1
   });
   ```

2. **Increase timing variance** (EASY FIX)
   - Typing: 50-250ms with occasional 300-800ms pauses
   - Actions: 800-2000ms instead of fixed 1000ms

3. **Remove global window variables** (EASY FIX)
   - Use Chrome message passing instead

4. **Remove console logging in production** (EASY FIX)

5. **Add pointer events** to click sequence (MEDIUM EFFORT)

6. **Add mouse movement simulation** before clicks (HIGHER EFFORT)

---

## Chrome Debugger API Example

For truly undetectable automation, use the Debugger API:

```javascript
// Requires "debugger" permission in manifest (already present)

async function trustedClick(tabId, x, y) {
  await chrome.debugger.attach({ tabId }, '1.3');

  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type: 'mousePressed', x, y, button: 'left', clickCount: 1
  });

  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type: 'mouseReleased', x, y, button: 'left', clickCount: 1
  });

  await chrome.debugger.detach({ tabId });
}

async function trustedType(tabId, text) {
  await chrome.debugger.attach({ tabId }, '1.3');

  for (const char of text) {
    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyDown', text: char
    });
    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchKeyEvent', {
      type: 'keyUp', text: char
    });
    await sleep(randomDelay(50, 250));
  }

  await chrome.debugger.detach({ tabId });
}
```

**Note:** Debugger API shows a warning banner "Extension is debugging this browser" which user must accept.

---

## Files Requiring Changes

| File | Priority | Changes Needed |
|------|----------|----------------|
| `popup.js` | HIGH | Timing, events, debugger API |
| `sidepanel.js` | HIGH | Timing, events, debugger API |
| `linkedin-actions.js` | MEDIUM | Remove globals, timing |
| `manifest.json` | - | Already has debugger permission |

